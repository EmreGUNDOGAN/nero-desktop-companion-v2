// Nero paneli: notlar, yapılacaklar, zamanlayıcı ve ayarlar.

(() => {
  const api = window.nero;
  const $ = (id) => document.getElementById(id);

  let state = null;
  let currentTab = 'notes';

  // ---------------------------------------------------------------------------
  // Tema renkleri
  // ---------------------------------------------------------------------------
  const UI_VARS = {
    paper: '--paper', surface: '--surface', ink: '--ink', muted: '--muted', accent: '--accent',
    accentInk: '--accent-ink', secondary: '--secondary', danger: '--danger', line: '--line'
  };
  const DEFAULT_NOTE_COLORS = ['#FBEBC2', '#F8D9D4', '#DDE7D4', '#E6DEF1', '#D9E8EF'];
  let noteColors = DEFAULT_NOTE_COLORS;

  // Her temanın arayüz "kılığı" (skin): yerleşim süsleri ve Nero'nun ağzından yazılar.
  const SKINS = {
    cozy: {
      tabs: { home: 'Bugün', notes: 'Notlar', todos: 'İşler', timer: 'Zaman', settings: 'Ayarlar' },
      newNote: 'yeni not', newNoteSub: '',
      saved: 'kaydedildi', typing: 'yazılıyor…',
      todoPlaceholder: 'Bugün ne yapıyoruz?', listTitle: '',
      todoLeft: (n) => `${n} iş kaldı`, allDone: 'hepsi bitti ♡',
      timerIdle: 'hazır olduğunda', timerRunning: 'odaklan, Nero izliyor', timerPaused: 'mola…',
      cancel: 'Bırak', cancelNote: '', talkMax: 'Çok',
      subs: {},
      moodPrefix: '', moodLabels: null
    },
    latte: {
      tabs: { home: 'Bugün', notes: 'Notlar', todos: 'İşler', timer: 'Zaman', settings: 'Ayarlar' },
      newNote: 'yeni not', newNoteSub: '',
      saved: 'kaydedildi', typing: 'yazılıyor…',
      todoPlaceholder: 'Bugün ne yapıyoruz?', listTitle: 'bugünün listesi',
      todoLeft: (n) => `${n} iş kaldı`, allDone: 'hepsi bitti, bir kahveyi hak ettin',
      timerIdle: 'bir kahve boyu odak', timerRunning: 'Nero izliyor. kaçmak yok.', timerPaused: 'kahve molası…',
      cancel: 'Bırak', cancelNote: '', talkMax: 'Çok',
      subs: {},
      moodPrefix: '', moodLabels: null
    },
    kasaba: {
      tabs: { home: 'Manşet', notes: 'Notlar', todos: 'İşler', timer: 'Zaman', settings: 'Ayarlar' },
      newNote: 'yeni kart', newNoteSub: '',
      saved: 'arşive kaldırıldı', typing: 'daktilo tıkırdıyor…',
      todoPlaceholder: 'Siparişini söyle...', listTitle: 'SİPARİŞ FİŞİ <span>Garson: Nero (isteksiz)</span>',
      todoLeft: (n) => `TOPLAM: ${n} iş, bahşiş yok`, allDone: 'TOPLAM: 0 iş. Mutfak kapandı.',
      timerIdle: 'ocak hazır', timerRunning: 'demleniyor', timerPaused: 'kahve molası',
      cancel: 'Bırak', cancelNote: '', talkMax: 'Çok hızlı',
      subs: {},
      moodPrefix: '',
      moodLabels: {
        content: "Nero'nun keyfi yerinde", happy: 'Nero bugün neşeli, kaynaklar doğruladı', bored: 'Nero sıkıldı, kasaba sessiz',
        sulky: 'Nero küstü, açıklama yapmıyor', lonely: 'Nero yalnız, okurlar endişeli', asleep: 'Nero uyuyor, yarın devam'
      }
    },
    ege: {
      tabs: { home: 'Bugün', badges: 'Rozetler', notes: 'Notlar', todos: 'İşler', timer: 'Sayaç', settings: 'Ayarlar' },
      newNote: 'yeni not', newNoteSub: '',
      saved: 'kaydedildi', typing: 'yazılıyor…',
      todoPlaceholder: 'Güzel bir gün için ne bitecek?', listTitle: '',
      todoLeft: (n) => `${n} iş kaldı. güneş batmadan.`, allDone: 'hepsi bitti. şimdi limonata zamanı.',
      timerIdle: 'daha iyi bir sen mümkün', timerRunning: 'daha iyi bir sen mümkün', timerPaused: 'deniz molası…',
      cancel: 'Bırak', cancelNote: '', talkMax: 'Çok',
      tagline: 'daha yavaş, daha bilinçli.', sticky: 'good days ahead',
      subs: {}, moodPrefix: 'şu an: ', moodLabels: null
    },
    cilek: {
      tabs: { home: 'Bugün', badges: 'Rozetler', notes: 'Notlar', todos: 'İşler', timer: 'Sayaç', settings: 'Ayarlar' },
      newNote: 'yeni not', newNoteSub: '',
      saved: 'kaydedildi', typing: 'yazılıyor…',
      todoPlaceholder: 'Piknikten önce ne bitecek?', listTitle: '',
      todoLeft: (n) => `${n} iş kaldı. çilekler bekliyor.`, allDone: 'hepsi bitti. çilek zamanı.',
      timerIdle: 'bugün yine güzel şeyler mümkün', timerRunning: 'bugün yine güzel şeyler mümkün', timerPaused: 'kısa bir mola…',
      cancel: 'Bırak', cancelNote: '', talkMax: 'Çok',
      tagline: 'küçük molalar, büyük huzur.', sticky: 'good days ahead',
      subs: {}, moodPrefix: 'şu an: ', moodLabels: null
    },
    mum: {
      tabs: { home: 'Bugün', badges: 'Rozetler', notes: 'Notlar', todos: 'İşler', timer: 'Sayaç', settings: 'Ayarlar' },
      newNote: 'yeni not', newNoteSub: '',
      saved: 'kaydedildi', typing: 'yazılıyor…',
      todoPlaceholder: 'Mum sönmeden ne bitecek?', listTitle: '',
      todoLeft: (n) => `${n} iş kaldı. mumlar dayanır mı?`, allDone: 'hepsi bitti. mumları söndürebilirsin.',
      timerIdle: 'aynı rüyalara, daha sakin günlere', timerRunning: 'aynı rüyalara, daha sakin günlere', timerPaused: 'mum molası…',
      cancel: 'Bırak', cancelNote: '', talkMax: 'Çok',
      tagline: 'küçük molalar, büyük huzur.', sticky: 'good things take time',
      subs: {}, moodPrefix: 'şu an: ', moodLabels: null
    },
    yagmur: {
      tabs: { home: 'Bugün', notes: 'Notlar', todos: 'İşler', timer: 'Sayaç', settings: 'Ayarlar' },
      newNote: 'yeni not', newNoteSub: '',
      saved: 'kaydedildi', typing: 'yazılıyor…',
      todoPlaceholder: 'Yağmur dinerken ne bitecek?', listTitle: '',
      todoLeft: (n) => `${n} iş kaldı, yağmur da bitmedi`, allDone: 'hepsi bitti. yağmuru dinle biraz.',
      timerIdle: 'bir kahve, bir plan, daha iyi bir sen', timerRunning: 'bir kahve, bir plan, daha iyi bir sen', timerPaused: 'cama bakma molası…',
      cancel: 'Bırak', cancelNote: '', talkMax: 'Çok',
      tagline: 'yağmur yağar, iş biter.', sticky: 'küçük adımlar büyük günler',
      subs: {}, moodPrefix: 'şu an: ', moodLabels: null
    },
    kar: {
      tabs: { home: 'Bugün', notes: 'Notlar', todos: 'İşler', timer: 'Sayaç', settings: 'Ayarlar' },
      newNote: 'yeni not', newNoteSub: '',
      saved: 'kaydedildi', typing: 'yazılıyor…',
      todoPlaceholder: 'Kar yağarken ne bitecek?', listTitle: '',
      todoLeft: (n) => `${n} iş kaldı, kar da durmadı`, allDone: 'hepsi bitti. sıcak çikolata zamanı.',
      timerIdle: 'aynı gökyüzü altında, daha iyi bir sen mümkün', timerRunning: 'aynı gökyüzü altında, daha iyi bir sen mümkün', timerPaused: 'kar tanelerini sayma molası…',
      cancel: 'Bırak', cancelNote: '', talkMax: 'Çok',
      tagline: 'küçük adımlar, büyük huzur.', sticky: 'sıcak çay, sakin kalp',
      subs: {}, moodPrefix: 'şu an: ', moodLabels: null
    },
    disket: {
      tabs: { home: 'Bugün', notes: 'Notlar', todos: 'İşler', timer: 'Sayaç', settings: 'Ayar' },
      newNote: '+ YENİ.TXT', newNoteSub: '',
      saved: 'kaydedildi (A:)', typing: 'yazılıyor...',
      todoPlaceholder: 'yeni görev yaz...', listTitle: 'YAPILACAK.LST',
      todoLeft: (n) => `${n} görev açık`, allDone: 'tüm görevler tamam. sistem şaşkın.',
      timerIdle: '> hazır_', timerRunning: '> odaklanma modu aktif_', timerPaused: '> duraklatıldı_',
      cancel: 'İptal', cancelNote: '', talkMax: 'Çok',
      delayLabel: (p) => `Yükleniyor: işler %${p} tamam`, delayMode: 'done',
      delayNote: (p) => (p >= 100 ? 'tahmini bitiş: şimdi. vay.' : p >= 50 ? 'tahmini bitiş: bugün, belki' : 'tahmini bitiş: belki yarın'),
      subs: {},
      moodPrefix: 'C:\\NERO> ruh_hali: ',
      moodLabels: {
        content: 'keyfi_yerinde', happy: 'keyifli.exe', bored: 'sıkılıyor...',
        sulky: 'küs (hata 404: ilgi)', lonely: 'bağlantı_koptu', asleep: 'uyku_modu'
      }
    },
    gece: {
      tabs: { home: 'Bugün', badges: 'Rozetler', notes: 'Notlar', todos: 'İşler', timer: 'Zaman', settings: 'Ayarlar' },
      newNote: 'yeni not', newNoteSub: '',
      saved: 'kaydedildi', typing: 'yazılıyor…',
      todoPlaceholder: 'Bu gece ne bitiyor?', listTitle: '',
      todoLeft: (n) => `${n} iş kaldı, gece uzun`, allDone: 'hepsi bitti. artık uyu.',
      timerIdle: 'gece odak modu', timerRunning: 'gece odak modu', timerPaused: 'yıldızlara bakma molası…',
      cancel: 'Bırak', cancelNote: '', talkMax: 'Çok',
      subs: {},
      moodPrefix: '', moodLabels: null
    },
    pazartesi: {
      tabs: { home: 'Bugün', notes: 'Notlar', todos: 'İşler', timer: 'Sayaç', settings: 'Ayarlar' },
      newNote: 'bir not daha', newNoteSub: '(okuyacak mısın?)',
      saved: 'otomatik kaydedildi, sen unutsan da', typing: 'yazıyorsun, izliyorum…',
      todoPlaceholder: 'Yine ne sözü veriyoruz?', listTitle: 'Yapılacaklar <span>(iddialı)</span>',
      todoLeft: (n) => `${n} iş kaldı. Nero şüpheli.`, allDone: 'hepsi bitti?! kontrol edeceğim.',
      timerIdle: 'hadi bakalım', timerRunning: 'kaçarsan görürüm', timerPaused: 'mola mı? hemen mi?',
      cancel: 'Pes et', cancelNote: '(Nero kırılır)', talkMax: 'Çenesi düştü',
      subs: {
        theme: 'kılık değiştirmek serbest',
        talk: '',
        muted: 'Nero susar. Küser ama susar.',
        badge: 'sayaç hep gözünün önünde',
        sound: 'bitince zil çalar, sen de kalkarsın',
        top: 'kaçış yok',
        startup: 'sabah ilk o karşılar',
        lock: 'kıpırdamaz. inatçı.',
        stay: 'masaüstünü gösterince de kaçmaz',
        name: 'roast ederken lazım',
        desk: 'uzun süre yoksan pusuda bekler',
        peek: 'arada bir ekranın ortasında belirir. bö!',
        scene: 'kapatırsan düz renk kalır',
        ambient: 'yağmur, rüzgar, mum çıtırtısı gibi çok kısık sesler',
        quick: 'antivirüs bazı sistemlerde buna şüpheyle bakabilir',
        break: 'omurgan teşekkür edecek',
        summary: 'akşam 7\'den sonra karne verir',
        bday: 'o gün parti şapkası takar',
        reset: '(hafızası silinir, kini kalır)'
      },
      moodPrefix: 'şu an: ',
      moodLabels: {
        content: 'katlanılabilir.', happy: 'neşeli. geçer.', bored: 'sıkılıyor.',
        sulky: 'küs. yüzüne bakmıyor.', lonely: 'terk edilmiş hissediyor.', asleep: 'uyuyor. sessiz ol.'
      }
    }
  };
  let skinName = 'cozy';
  const skin = () => SKINS[skinName] || SKINS.cozy;

  function applyUi(ui = {}) {
    for (const [key, cssVar] of Object.entries(UI_VARS)) {
      if (ui[key]) document.documentElement.style.setProperty(cssVar, ui[key]);
    }
    noteColors = Array.isArray(ui.noteColors) && ui.noteColors.length ? ui.noteColors : DEFAULT_NOTE_COLORS;
    const next = SKINS[ui.skin] ? ui.skin : 'cozy';
    if (next !== skinName || !document.documentElement.dataset.skin) {
      skinName = next;
      document.documentElement.dataset.skin = skinName;
      applySkinText();
      if (state) { renderNotes(); renderTodos(); renderTimer(state.timer); renderMood(state.mood); }
    }
  }

  function applySkinText() {
    const k = skin();
    const FALLBACK_TABS = { home: 'Bugün', badges: 'Rozetler', notes: 'Notlar', todos: 'İşler', timer: 'Zaman', settings: 'Ayarlar' };
    for (const el of document.querySelectorAll('.tl')) el.textContent = k.tabs[el.dataset.k] || FALLBACK_TABS[el.dataset.k];
    $('todo-input').placeholder = k.todoPlaceholder;
    $('list-title').innerHTML = k.listTitle;
    $('timer-cancel').textContent = k.cancel;
    $('cancel-note').textContent = k.cancelNote;
    $('talk-cok').textContent = k.talkMax;
    $('tagline').textContent = k.tagline || '';
    $('sticky-text').textContent = k.sticky || '';
    for (const el of document.querySelectorAll('.sub')) el.textContent = k.subs[el.dataset.sub] || '';
  }

  // Her not kimliğine göre hep aynı renk ve eğimi alır.
  function noteStyle(id) {
    let h = 0;
    for (const ch of String(id)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    return {
      color: noteColors[h % noteColors.length],
      tilt: `${((h >> 4) % 5) - 2}deg`
    };
  }

  // ---------------------------------------------------------------------------
  // Sekmeler
  // ---------------------------------------------------------------------------
  const tabButtons = [...document.querySelectorAll('.tabs [role="tab"]')];
  function selectTab(tab) {
    currentTab = tab;
    document.documentElement.dataset.tab = tab;
    for (const b of tabButtons) b.setAttribute('aria-selected', String(b.dataset.tab === tab));
    for (const v of document.querySelectorAll('.view')) v.hidden = v.id !== `view-${tab}`;
    if (tab === 'todos') setTimeout(() => $('todo-input').focus(), 30);
  }
  tabButtons.forEach((b) => b.addEventListener('click', () => selectTab(b.dataset.tab)));
  $('close').addEventListener('click', () => api.invoke('panel:hide'));
  $('minimize').addEventListener('click', () => api.invoke('panel:minimize'));
  $('pin').addEventListener('click', () => set('panelPinned', !(state && state.settings.panelPinned)));

  // Köşe tutamaçlarından boyutlandırma
  for (const grip of document.querySelectorAll('.grip')) {
    grip.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      grip.setPointerCapture(e.pointerId);
      api.send('panel:resizeStart', grip.dataset.side);
    });
    const end = (e) => {
      try { grip.releasePointerCapture(e.pointerId); } catch (_) { /* yoksay */ }
      api.send('panel:resizeEnd');
    };
    grip.addEventListener('pointerup', end);
    grip.addEventListener('lostpointercapture', () => api.send('panel:resizeEnd'));
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!$('note-editor-view').hidden) closeEditor();
      else api.invoke('panel:hide');
    }
  });

  // ---------------------------------------------------------------------------
  // Ruh hali satırı
  // ---------------------------------------------------------------------------
  const SVGNS = 'http://www.w3.org/2000/svg';
  const HEART = 'M7 12.5S1.2 8.9 1.2 5.1A2.9 2.9 0 0 1 7 3.8a2.9 2.9 0 0 1 5.8 1.3C12.8 8.9 7 12.5 7 12.5z';

  function renderMeter(happiness) {
    const box = $('meter');
    box.textContent = '';
    box.setAttribute('aria-valuenow', String(happiness));

    if (skinName === 'latte') {
      // Keyif kadar dolan bir kahve fincanı
      const level = 23.5 - 11 * (happiness / 100);
      box.innerHTML = `<svg class="cup" viewBox="0 0 30 30" aria-hidden="true">
        <defs><clipPath id="cupclip"><path d="M6.5 11h14.5v7a6.5 6.5 0 0 1-6.5 6.5h-1.5A6.5 6.5 0 0 1 6.5 18z"/></clipPath></defs>
        <path class="steam-line" d="M11 3c-1 2 1 3 0 5M16 3c-1 2 1 3 0 5"/>
        <path class="cup-body" d="M5 10h17v8a7 7 0 0 1-7 7h-3a7 7 0 0 1-7-7z"/>
        <rect class="cup-fill" x="5" y="${level.toFixed(1)}" width="17" height="20" clip-path="url(#cupclip)"/>
        <path class="cup-handle" d="M22 13h2.5a3 3 0 0 1 0 6H22"/>
      </svg><span class="cup-text">keyif %${happiness}</span>`;
      return;
    }

    if (['yagmur', 'kar', 'cilek', 'mum', 'ege'].includes(skinName)) return; // bu temalarda gösterge yok, başlık sahneye ait

    if (skinName === 'kasaba') {
      const up = happiness >= 50;
      box.innerHTML = `<span class="index">keyif endeksi <b class="${up ? 'up' : 'down'}">${up ? '▲' : '▼'}</b> %${happiness}</span>`;
      return;
    }

    if (skinName === 'disket') {
      // Piksel blok çubuk
      const on = Math.round(happiness / 10);
      const blocks = Array.from({ length: 10 }, (_, i) => `<i${i < on ? '' : ' class="off"'}></i>`).join('');
      box.innerHTML = `<span class="px-label">KEYİF</span><span class="px-blocks">${blocks}</span><span class="px-label">%${happiness}</span>`;
      return;
    }

    if (skinName === 'gece') {
      // Keyif arttıkça dolunaya dönen ay
      const shift = (1 - happiness / 100) * 20;
      box.innerHTML = `<svg class="moon" viewBox="0 0 24 24" aria-hidden="true">
        <defs><mask id="moonmask"><rect width="24" height="24" fill="#fff"/><circle cx="${(12 - 20 + shift).toFixed(1)}" cy="10" r="10" fill="#000"/></mask></defs>
        <circle class="moon-bg" cx="12" cy="12" r="10"/>
        <circle class="moon-fg" cx="12" cy="12" r="10" mask="url(#moonmask)"/>
      </svg><span class="moon-text">keyif %${happiness}</span>`;
      return;
    }

    if (skinName === 'pazartesi') {
      // Huysuzluk ölçer: keyif düştükçe ibre kırmızıya döner
      const grump = 100 - happiness;
      const a = Math.PI * (1 - grump / 100);
      const x = 40 + 27 * Math.cos(a);
      const y = 40 - 27 * Math.sin(a);
      box.innerHTML = `<svg class="gauge" viewBox="0 0 80 46" aria-hidden="true">
        <path d="M8 40 A32 32 0 0 1 29 10" stroke="#8EDDC4" stroke-width="9" fill="none"/>
        <path d="M29 10 A32 32 0 0 1 51 10" stroke="#FFFDF6" stroke-width="9" fill="none"/>
        <path d="M51 10 A32 32 0 0 1 72 40" stroke="#FF6F59" stroke-width="9" fill="none"/>
        <path d="M8 40 A32 32 0 0 1 72 40" stroke="var(--ink)" stroke-width="2.5" fill="none"/>
        <path d="M40 40 L${x.toFixed(1)} ${y.toFixed(1)}" stroke="var(--ink)" stroke-width="3.5" stroke-linecap="round"/>
        <circle cx="40" cy="40" r="4.5" fill="var(--ink)"/>
      </svg><span class="gauge-text">huysuzluk ölçer</span>`;
      return;
    }

    const filled = happiness / 20; // 0-5 kalp
    for (let i = 0; i < 5; i++) {
      const part = Math.max(0, Math.min(1, filled - i));
      const svg = document.createElementNS(SVGNS, 'svg');
      svg.setAttribute('viewBox', '0 0 14 14');
      svg.classList.add('heart');
      const clipId = `hc${i}`;
      svg.innerHTML = `<defs><clipPath id="${clipId}"><rect x="0" y="0" width="${(14 * part).toFixed(1)}" height="14"/></clipPath></defs>`
        + `<path class="h-bg" d="${HEART}"/><path class="h-fg" d="${HEART}" clip-path="url(#${clipId})"/>`;
      box.appendChild(svg);
    }
  }

  function renderMood(m) {
    if (!m) return;
    renderMeter(m.happiness);
    const k = skin();
    const key = m.asleep ? 'asleep' : (m.stage === 'content' && m.happiness >= 80 ? 'happy' : m.stage);
    $('mood-label').textContent = k.moodLabels ? `${k.moodPrefix}${k.moodLabels[key]}` : `${k.moodPrefix || ''}${m.label.toLowerCase()}.`;
    let detail = '';
    if (m.asleep) detail = 'sen uzaktayken kestiriyor.';
    else if (m.ignoredMinutes >= 60) {
      const h = Math.floor(m.ignoredMinutes / 60);
      const min = m.ignoredMinutes % 60;
      detail = `${h} saat${min ? ` ${min} dakika` : ''}dır kimse ilgilenmedi.`;
    } else if (m.ignoredMinutes >= 5) detail = `${m.ignoredMinutes} dakikadır sessiz.`;
    else detail = 'az önce ilgilendin, memnun. belli etmiyor.';
    $('mood-detail').textContent = detail;
  }

  // ---------------------------------------------------------------------------
  // Notlar
  // ---------------------------------------------------------------------------
  let editingId = null;
  let saveTimer = null;
  const dateFmt = new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

  function renderNotes() {
    const list = $('notes-list');
    list.textContent = '';
    const notes = state.notes || [];

    const add = document.createElement('li');
    add.className = 'new-note';
    add.tabIndex = 0;
    add.innerHTML = '<span class="plus">+</span><span class="nn"></span><span class="nn-sub"></span>';
    add.querySelector('.nn').textContent = skin().newNote;
    add.querySelector('.nn-sub').textContent = skin().newNoteSub;
    add.addEventListener('click', () => openEditor(null));
    add.addEventListener('keydown', (e) => { if (e.key === 'Enter') openEditor(null); });
    list.appendChild(add);

    for (const note of notes) {
      const lines = note.body.trim().split('\n');
      const look = noteStyle(note.id);
      const li = document.createElement('li');
      li.tabIndex = 0;
      li.style.setProperty('--note', look.color);
      li.style.setProperty('--tilt', look.tilt);
      const title = document.createElement('div');
      title.className = 'note-title';
      title.textContent = lines[0] || 'boş not';
      const preview = document.createElement('div');
      preview.className = 'note-preview';
      preview.textContent = lines.slice(1).join(' ').trim();
      const date = document.createElement('div');
      date.className = 'note-date';
      date.textContent = dateFmt.format(new Date(note.updatedAt));
      li.insertAdjacentHTML('afterbegin',
        '<svg class="clip" viewBox="0 0 16 34" aria-hidden="true"><path d="M5 10V26a4 4 0 0 0 8 0V6a3 3 0 0 0-6 0v19"/></svg>'
        + '<svg class="pin" viewBox="0 0 22 22" aria-hidden="true"><circle cx="11" cy="9" r="7"/><path d="M11 16v5"/></svg>');
      const fname = document.createElement('div');
      fname.className = 'fname';
      fname.textContent = `${fileName(lines[0])}.TXT`;
      li.append(fname, title);
      if (preview.textContent) li.append(preview);
      li.append(date);
      // 3 günden eski ve dokunulmamış notlara Pazartesi temasında damga vurulur
      if (Date.now() - note.updatedAt > 3 * 24 * 3600 * 1000) {
        li.insertAdjacentHTML('beforeend', '<span class="stamp note-stamp" aria-hidden="true">OKUNMADI</span>');
      }
      li.addEventListener('click', () => openEditor(note));
      li.addEventListener('keydown', (e) => { if (e.key === 'Enter') openEditor(note); });
      list.appendChild(li);
    }
  }

  // Disket teması için not başlığından 8 harflik dosya adı
  function fileName(title) {
    const map = { ç: 'C', ğ: 'G', ı: 'I', i: 'I', ö: 'O', ş: 'S', ü: 'U' };
    const clean = String(title || 'NOT').toLocaleLowerCase('tr-TR').replace(/[çğıiöşü]/g, (c) => map[c])
      .toUpperCase().replace(/[^A-Z0-9]/g, '');
    return (clean || 'NOT').slice(0, 8);
  }

  function openEditor(note) {
    editingId = note ? note.id : null;
    $('note-body').value = note ? note.body : '';
    $('note-paper').style.setProperty('--note', noteStyle(note ? note.id : `yeni-${Date.now()}`).color);
    $('note-save-state').textContent = note ? skin().saved : '';
    updateFormHead(note ? note.body : '', note ? note.updatedAt : Date.now());
    $('notes-list-view').hidden = true;
    $('note-editor-view').hidden = false;
    $('note-body').focus();
  }

  const shortDate = new Intl.DateTimeFormat('tr-TR', { day: '2-digit', month: '2-digit' });
  function updateFormHead(body, at) {
    $('form-subject').textContent = (body.trim().split('\n')[0] || '…').slice(0, 40);
    $('form-date').textContent = shortDate.format(new Date(at));
  }

  async function saveNote() {
    clearTimeout(saveTimer);
    const body = $('note-body').value;
    if (!editingId && !body.trim()) return;
    const saved = await api.invoke('notes:save', { id: editingId, body });
    editingId = saved.id;
    $('note-save-state').textContent = skin().saved;
  }

  async function closeEditor() {
    await saveNote();
    $('note-editor-view').hidden = true;
    $('notes-list-view').hidden = false;
    editingId = null;
  }

  $('note-back').addEventListener('click', closeEditor);
  $('note-body').addEventListener('input', () => {
    $('note-save-state').textContent = skin().typing;
    updateFormHead($('note-body').value, Date.now());
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveNote, 700);
  });
  $('note-delete').addEventListener('click', async () => {
    clearTimeout(saveTimer);
    if (editingId) await api.invoke('notes:delete', editingId);
    editingId = null;
    $('note-editor-view').hidden = true;
    $('notes-list-view').hidden = false;
  });

  // ---------------------------------------------------------------------------
  // Yapılacaklar
  // ---------------------------------------------------------------------------
  const CHECK_SVG = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2 6.5l2.6 2.6L10 3.5"/></svg>';

  function renderTodos() {
    if (document.querySelector('.todo-text[contenteditable="true"]')) return; // düzenleme sürerken bozma
    const list = $('todo-list');
    list.textContent = '';
    const todos = state.todos || [];
    $('todos-empty').hidden = todos.length > 0;
    $('todo-footer').hidden = todos.length === 0;
    const open = todos.filter((t) => !t.done).length;
    $('todo-count').textContent = open ? skin().todoLeft(open) : skin().allDone;
    // Pazartesi: açık iş oranından uydurma "erteleme ihtimali". Disket: yükleme çubuğu gibi tamamlanma oranı.
    const k = skin();
    $('delay').hidden = todos.length === 0;
    if (k.delayMode === 'done') {
      const done = todos.length ? Math.round(((todos.length - open) / todos.length) * 100) : 0;
      $('delay-label').textContent = k.delayLabel(done);
      $('delay-pct').textContent = '';
      $('delay-fill').style.width = `${done}%`;
      $('delay-note').textContent = k.delayNote(done);
    } else {
      const pct = todos.length ? Math.max(3, Math.min(97, Math.round((open / todos.length) * 100) - 3)) : 0;
      $('delay-label').textContent = 'Erteleme ihtimali';
      $('delay-pct').textContent = `%${pct}`;
      $('delay-fill').style.width = `${pct}%`;
      $('delay-note').textContent = '';
    }
    $('todo-clear').hidden = !todos.some((t) => t.done);

    // Bitmemişler üstte
    const sorted = [...todos].sort((a, b) => Number(a.done) - Number(b.done));
    for (const todo of sorted) {
      const li = document.createElement('li');
      li.classList.toggle('done', todo.done);

      const check = document.createElement('button');
      check.className = 'check';
      check.type = 'button';
      check.setAttribute('aria-label', todo.done ? 'Bitmedi olarak işaretle' : 'Bitti olarak işaretle');
      check.innerHTML = CHECK_SVG;
      check.addEventListener('click', () => api.invoke('todos:toggle', todo.id));

      const text = document.createElement('span');
      text.className = 'todo-text';
      text.textContent = todo.text;
      text.title = 'Düzenlemek için çift tıkla';
      text.addEventListener('dblclick', () => startRename(text, todo));

      const del = document.createElement('button');
      del.className = 'todo-del';
      del.type = 'button';
      del.setAttribute('aria-label', 'Sil');
      del.textContent = '×';
      del.addEventListener('click', () => api.invoke('todos:delete', todo.id));

      // Hatırlatma: saat varsa küçük bir etiket; yoksa üstüne gelince çıkan saat düğmesi
      const bell = document.createElement('label');
      bell.className = `todo-bell${todo.remindAt ? ' set' : ''}`;
      bell.title = todo.remindAt ? 'Hatırlatmayı kaldırmak için saati sil' : 'Hatırlatma ekle';
      const at = todo.remindAt ? new Date(todo.remindAt) : null;
      bell.innerHTML = '<svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="11" r="6.5"/><path d="M10 7.5V11l2.2 1.6"/></svg>';
      const tInput = document.createElement('input');
      tInput.type = 'time';
      tInput.setAttribute('aria-label', 'Hatırlatma saati');
      if (at) tInput.value = `${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}`;
      tInput.addEventListener('change', () => api.invoke('todos:setReminder', todo.id, tInput.value));
      bell.appendChild(tInput);
      if (todo.done) bell.hidden = true;

      li.append(check, text, bell, del);
      if (todo.done) li.insertAdjacentHTML('beforeend', '<span class="stamp todo-stamp" aria-hidden="true">OLDU BU İŞ</span>');
      list.appendChild(li);
    }
  }

  function startRename(el, todo) {
    el.contentEditable = 'true';
    el.focus();
    document.getSelection().selectAllChildren(el);
    const finish = (commit) => {
      el.contentEditable = 'false';
      el.removeEventListener('blur', onBlur);
      el.removeEventListener('keydown', onKey);
      const value = el.textContent.trim();
      if (commit && value && value !== todo.text) api.invoke('todos:rename', todo.id, value);
      else el.textContent = todo.text;
    };
    const onBlur = () => finish(true);
    const onKey = (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      if (e.key === 'Escape') { e.stopPropagation(); finish(false); }
    };
    el.addEventListener('blur', onBlur);
    el.addEventListener('keydown', onKey);
  }

  $('todo-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = $('todo-input');
    const text = input.value.trim();
    if (!text) return;
    const time = $('todo-time').value;
    input.value = '';
    $('todo-time').value = '';
    await api.invoke('todos:add', text, time);
  });
  $('todo-clear').addEventListener('click', () => api.invoke('todos:clearDone'));

  // ---------------------------------------------------------------------------
  // Zamanlayıcı
  // ---------------------------------------------------------------------------
  const RING = 2 * Math.PI * 86;
  let chosenMinutes = 25;

  function fmt(ms) {
    const total = Math.ceil(ms / 1000);
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    const mm = String(m).padStart(2, '0');
    const ss = String(s).padStart(2, '0');
    return h ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
  }

  function renderTimer(t) {
    if (!t) return;
    const idle = t.status === 'idle';
    $('timer-setup').hidden = !idle;
    $('timer-start').hidden = !idle;
    $('timer-pause').hidden = t.status !== 'running';
    $('timer-resume').hidden = t.status !== 'paused';
    $('timer-cancel').hidden = idle;
    $('cancel-note').hidden = idle;

    if (idle) {
      $('timer-digits').textContent = fmt(chosenMinutes * 60000);
      $('timer-status').textContent = skin().timerIdle;
      $('ring-fill').style.strokeDashoffset = String(RING);
      $('lcd-fill').style.width = '0%';
    } else {
      $('lcd-fill').style.width = `${Math.round(Math.min(1, t.progress) * 100)}%`;
      $('timer-digits').textContent = fmt(t.remainingMs);
      $('timer-status').textContent = t.status === 'paused'
        ? skin().timerPaused
        : (t.label || skin().timerRunning);
      $('ring-fill').style.strokeDashoffset = String(RING * (1 - Math.min(1, t.progress)));
    }
  }

  function choose(minutes) {
    chosenMinutes = Math.max(1, Math.min(600, Math.round(Number(minutes) || 25)));
    $('timer-custom').value = chosenMinutes;
    for (const b of document.querySelectorAll('#presets button')) {
      b.classList.toggle('on', Number(b.dataset.min) === chosenMinutes);
    }
    if (!state || state.timer.status === 'idle') $('timer-digits').textContent = fmt(chosenMinutes * 60000);
  }

  document.querySelectorAll('#presets button').forEach((b) => b.addEventListener('click', () => choose(b.dataset.min)));
  $('timer-custom').addEventListener('change', (e) => choose(e.target.value));
  $('timer-start').addEventListener('click', () => api.invoke('timer:start', chosenMinutes, $('timer-label').value.trim()));
  $('timer-pause').addEventListener('click', () => api.invoke('timer:pause'));
  $('timer-resume').addEventListener('click', () => api.invoke('timer:resume'));
  $('timer-cancel').addEventListener('click', () => api.invoke('timer:cancel'));

  // ---------------------------------------------------------------------------
  // Ayarlar
  // ---------------------------------------------------------------------------
  const set = (key, value) => api.invoke('settings:set', key, value);

  function renderSettings() {
    const s = state.settings;
    const select = $('set-theme');
    select.textContent = '';
    for (const t of state.themes) {
      const opt = document.createElement('option');
      opt.value = t.id;
      opt.textContent = `${t.name}${t.source === 'user' ? ' (eklenen)' : ''}${t.broken ? ' - bozuk' : ''}`;
      opt.disabled = t.broken;
      opt.selected = t.id === state.currentThemeId;
      select.appendChild(opt);
    }
    const current = state.themes.find((t) => t.id === state.currentThemeId);
    const errors = current?.errors || [];
    $('theme-errors').hidden = errors.length === 0;
    $('theme-errors').textContent = errors.length ? `Bu temada sorun var:\n${errors.join('\n')}` : '';

    const pct = Math.round(s.scale * 100);
    $('set-scale').value = pct;
    $('scale-out').textContent = `${pct}%`;
    for (const b of document.querySelectorAll('#set-talk button')) {
      b.setAttribute('aria-checked', String(b.dataset.value === s.talkativeness));
    }
    $('set-muted').checked = s.muted;
    $('set-badge').checked = s.showTimerBadge;
    $('set-sound').checked = s.sound;
    $('set-top').checked = s.alwaysOnTop;
    $('set-lock').checked = s.lockPosition;
    $('set-stay').checked = s.stayVisible !== false;
    $('set-desk').checked = s.desktopJokes !== false;
    $('set-peek').checked = s.peekVisits !== false;
    $('set-fx').checked = s.weatherFx !== false;
    $('set-scene').checked = s.sceneBg !== false;
    $('set-ambient').checked = !!s.ambientSound;
    $('set-quick').checked = !!s.quickCapture;
    $('quick-hint').textContent = s.quickCapture ? 'Ctrl + Alt + Boşluk ile aç' : 'Açtığında Ctrl + Alt + Boşluk ile bir not ya da iş ekleyebilirsin.';
    document.documentElement.classList.toggle('no-scene', s.sceneBg === false);
    document.documentElement.classList.toggle('no-fx', s.weatherFx === false);
    $('set-water').value = String(s.waterEvery || 0);
    $('set-break').value = String(s.breakEvery || 0);
    $('set-summary').checked = s.daySummary !== false;
    $('set-autoupdate').checked = s.autoUpdate !== false;
    const [bm, bd] = (s.birthday || '-').split('-');
    $('set-bday-month').value = bm || '';
    $('set-bday-day').value = bd || '';
    if (document.activeElement !== $('set-name')) $('set-name').value = s.userName || '';
    $('pin').setAttribute('aria-pressed', String(!!s.panelPinned));
    $('pin').title = s.panelPinned ? 'Sabitlemeyi kaldır' : 'Sabitle: Nero\'ya tıklayınca kapanmasın';
    $('set-startup').checked = s.launchAtStartup;
    $('char-hide').textContent = s.hidden ? 'Nero\'yu göster' : 'Nero\'yu gizle';
    $('app-version').textContent = `v${state.version}`;
    $('version').textContent = `Nero ${state.version}, Stenwick'ten sevgilerle`;
  }

  $('set-theme').addEventListener('change', (e) => set('themeId', e.target.value));
  $('set-scale').addEventListener('input', (e) => { $('scale-out').textContent = `${e.target.value}%`; });
  $('set-scale').addEventListener('change', (e) => set('scale', Number(e.target.value) / 100));
  document.querySelectorAll('#set-talk button').forEach((b) => b.addEventListener('click', () => set('talkativeness', b.dataset.value)));
  $('set-muted').addEventListener('change', (e) => set('muted', e.target.checked));
  $('set-badge').addEventListener('change', (e) => set('showTimerBadge', e.target.checked));
  $('set-sound').addEventListener('change', (e) => set('sound', e.target.checked));
  $('set-top').addEventListener('change', (e) => set('alwaysOnTop', e.target.checked));
  $('set-lock').addEventListener('change', (e) => set('lockPosition', e.target.checked));
  $('set-stay').addEventListener('change', (e) => set('stayVisible', e.target.checked));
  $('set-desk').addEventListener('change', (e) => set('desktopJokes', e.target.checked));
  $('set-peek').addEventListener('change', (e) => set('peekVisits', e.target.checked));
  $('set-fx').addEventListener('change', (e) => set('weatherFx', e.target.checked));
  $('set-scene').addEventListener('change', (e) => set('sceneBg', e.target.checked));
  $('set-ambient').addEventListener('change', (e) => set('ambientSound', e.target.checked));
  $('set-quick').addEventListener('change', (e) => set('quickCapture', e.target.checked));
  $('set-water').addEventListener('change', (e) => set('waterEvery', Number(e.target.value)));
  $('set-break').addEventListener('change', (e) => set('breakEvery', Number(e.target.value)));
  $('set-summary').addEventListener('change', (e) => set('daySummary', e.target.checked));
  $('set-autoupdate').addEventListener('change', (e) => set('autoUpdate', e.target.checked));
  const saveBday = () => {
    const m = $('set-bday-month').value;
    const d = $('set-bday-day').value;
    set('birthday', m && d ? `${m}-${d}` : '');
  };
  $('set-bday-month').addEventListener('change', saveBday);
  $('set-bday-day').addEventListener('change', saveBday);
  $('set-name').addEventListener('change', (e) => set('userName', e.target.value));
  $('set-startup').addEventListener('change', (e) => set('launchAtStartup', e.target.checked));
  $('themes-reload').addEventListener('click', () => api.invoke('themes:reload'));
  $('themes-folder').addEventListener('click', () => api.invoke('themes:openFolder'));
  $('themes-guide').addEventListener('click', () => api.invoke('themes:openGuide'));
  $('mood-reset').addEventListener('click', () => api.invoke('mood:reset'));
  $('char-hide').addEventListener('click', () => set('hidden', !state.settings.hidden));
  $('app-quit').addEventListener('click', () => api.invoke('app:quit'));

  // ---------------------------------------------------------------------------
  // Ana sayfa
  // ---------------------------------------------------------------------------
  const WEEKDAYS = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
  const longDate = new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'long', weekday: 'long' });

  function minutesText(min) {
    if (min < 60) return `${min} dk`;
    const h = Math.floor(min / 60);
    const m = min % 60;
    return m ? `${h} sa ${m} dk` : `${h} saat`;
  }

  const BADGE_PAGE = 20;
  let badgesExpanded = false;

  function renderBadges() {
    const list = state.achievements || [];
    const got = list.filter((a) => a.unlockedAt).length;
    $('badge-count').textContent = `${got} / ${list.length}`;
    const grid = $('badge-grid');
    grid.textContent = '';
    // Kazanılanlar önce, en yeni en başta
    const sorted = [...list].sort((a, b) => (b.unlockedAt || 0) - (a.unlockedAt || 0));
    const shown = badgesExpanded ? sorted : sorted.slice(0, BADGE_PAGE);
    for (const a of shown) {
      const li = document.createElement('li');
      li.className = `badge${a.unlockedAt ? ' on' : ''}`;
      const icon = document.createElement('span');
      icon.className = 'badge-icon';
      icon.textContent = a.unlockedAt ? a.icon : '?';
      const name = document.createElement('span');
      name.className = 'badge-name';
      name.textContent = a.title;
      // Kilitli rozetin de adı ve nasıl kazanılacağı görünür
      const desc = document.createElement('span');
      desc.className = 'badge-desc';
      desc.textContent = a.unlockedAt ? new Date(a.unlockedAt).toLocaleDateString('tr-TR') : a.desc;
      li.append(icon, name, desc);
      grid.appendChild(li);
    }
    const rest = sorted.length - shown.length;
    const more = $('badges-more');
    more.hidden = sorted.length <= BADGE_PAGE;
    more.textContent = badgesExpanded ? 'Daha azını göster' : `Kalan ${rest} rozeti göster`;
  }

  $('badges-more').addEventListener('click', () => { badgesExpanded = !badgesExpanded; renderBadges(); });

  function renderUpdate() {
    const u = state.update || {};
    const banner = $('update-banner');
    const showBanner = (u.status === 'ready' && !u.dismissed) || u.status === 'onquit';
    banner.hidden = !showBanner;
    if (u.status === 'ready') {
      $('update-text').textContent = `Yeni sürüm hazır: v${u.version}`;
      $('update-now').hidden = false; $('update-onquit').hidden = false; $('update-dismiss').hidden = false;
    } else if (u.status === 'onquit') {
      $('update-text').textContent = `Nero kapanınca v${u.version} kurulacak.`;
      $('update-now').hidden = false; $('update-onquit').hidden = true; $('update-dismiss').hidden = true;
    }
    const labels = {
      dev: 'Geliştirme sürümünde güncelleme yok.',
      idle: 'Henüz denetlenmedi.',
      checking: 'Denetleniyor…',
      latest: `En güncel sürümdesin (v${state.version}).`,
      downloading: `v${u.version} indiriliyor… %${u.percent || 0}`,
      ready: `v${u.version} hazır, kurulmayı bekliyor.`,
      onquit: `v${u.version} Nero kapanınca kurulacak.`,
      error: 'Denetlenemedi. İnternet bağlantını kontrol et.',
      mismatch: 'İndirilen dosya doğrulanamadı. Yayındaki kurulum dosyası ile latest.yml aynı sürüme ait değil.'
    };
    $('update-status').textContent = labels[u.status] || '';
  }

  $('update-now').addEventListener('click', () => api.invoke('update:install'));
  $('update-onquit').addEventListener('click', () => api.invoke('update:onQuit'));
  $('update-dismiss').addEventListener('click', () => api.invoke('update:dismiss'));
  $('update-check').addEventListener('click', () => api.invoke('update:check'));
  $('data-export').addEventListener('click', () => api.invoke('data:export'));
  $('data-import').addEventListener('click', () => api.invoke('data:import'));
  $('data-backups').addEventListener('click', () => api.invoke('data:openBackups'));

  function renderRitual() {
    const done = !!state.dayMode;
    $('ritual').hidden = done;
    if (done) {
      const label = { sakin: 'sakin', uretken: 'üretken', kendime: 'kendine iyi davrandığın' }[state.dayMode];
      $('hello-date').textContent = `${longDate.format(new Date()).toLocaleLowerCase('tr-TR')} · ${label} bir gün`;
    }
  }

  for (const b of document.querySelectorAll('.ritual-opts .pill')) {
    b.addEventListener('click', async () => renderAll(await api.invoke('day:mode', b.dataset.mode)));
  }

  function renderRest() {
    const on = !!state.rest;
    $('rest-screen').hidden = !on;
    if (!on) return;
    const st = state.stats;
    $('rest-summary').textContent = st
      ? `Bugün ${st.today.todos} iş bitirdin ve ${minutesText(st.today.focus)} odaklandın. Gerisi yarının sorunu.`
      : 'Gerisi yarının sorunu.';
  }

  $('rest-night').addEventListener('click', () => api.invoke('rest:goodnight'));
  $('rest-continue').addEventListener('click', async () => renderAll(await api.invoke('rest:exit')));

  function renderDesk() {
    const d = state.desk;
    if (!d) return;
    $('desk-next').textContent = d.next ? `sıradaki: ${d.next.hoursLeft} saat kaldı` : 'hepsi açıldı';
    const grid = $('desk-grid');
    grid.textContent = '';
    for (const item of d.items) {
      const li = document.createElement('li');
      li.className = `desk-item${item.unlockedAt ? ' on' : ''}`;
      li.title = item.unlockedAt ? item.title : `${item.title} — ${item.hours} saat odaklanınca açılır`;
      li.textContent = item.unlockedAt ? item.icon : '?';
      grid.appendChild(li);
    }
  }

  function renderLetter() {
    const letter = state.home?.letter;
    $('letter-card').hidden = !letter || letter.week === dismissedLetterWeek;
    if (letter) $('letter-text').textContent = letter.text;
  }
  // Kapatma bilgisi bellekte tutulur; bir sonraki açılışta mektup tekrar görünse de zararsız.
  let dismissedLetterWeek = null;
  $('letter-close').addEventListener('click', () => { dismissedLetterWeek = state.home?.letter?.week || null; renderLetter(); });

  function renderMoodLog() {
    const log = state.home?.moodLog || [];
    const strip = $('mood-strip');
    strip.textContent = '';
    for (const d of log) {
      const dot = document.createElement('span');
      dot.className = `mood-dot${d.cls ? ` ${d.cls}` : ' empty'}`;
      if (d.label) dot.title = `${new Date(d.date).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' })}: ${d.label}`;
      strip.appendChild(dot);
    }
    $('moodlog-hint').textContent = 'üstüne gel, gör';
  }

  function renderArchive() {
    const a = state.home?.archive;
    $('archive-card').hidden = !a || a.total === 0;
    if (!a) return;
    $('archive-count').textContent = `${a.total} iş`;
    const list = $('archive-list');
    list.textContent = '';
    for (const item of a.recent) {
      const li = document.createElement('li');
      li.textContent = item.text;
      list.appendChild(li);
    }
  }

  $('jar-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = $('jar-input');
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    await api.invoke('jar:add', text);
  });
  function renderJar() { $('jar-count').textContent = `${state.jarCount || 0} anı`; }

  function renderHome() {
    const st = state.stats;
    if (!st) return;
    const h = new Date().getHours();
    const greet = h >= 5 && h < 12 ? 'Günaydın' : h >= 12 && h < 17 ? 'İyi günler' : h >= 17 && h < 22 ? 'İyi akşamlar' : 'İyi geceler';
    const name = (state.settings.userName || '').trim();
    $('hello').textContent = name ? `${greet}, ${name}` : greet;
    $('mm-issue').textContent = `Sayı ${st.daysTogether}`;
    $('mm-date').textContent = new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'long', weekday: 'long' }).format(new Date());
    $('hello-date').textContent = longDate.format(new Date()).toLocaleLowerCase('tr-TR');

    if (state.home) {
      $('home-jab').textContent = state.home.jab;
      $('quote-t').textContent = state.home.quote?.t || '';
      $('quote-nero').textContent = state.home.quote?.nero || '';
    }

    $('st-today-todos').textContent = st.today.todos;
    $('st-today-focus').textContent = minutesText(st.today.focus);
    $('st-streak').textContent = st.streak;
    $('st-days').textContent = st.daysTogether;

    const max = Math.max(30, ...st.week.map((d) => d.focus));
    const bars = $('week-bars');
    bars.textContent = '';
    st.week.forEach((d, i) => {
      const bar = document.createElement('div');
      bar.className = `bar${i === st.week.length - 1 ? ' today' : ''}`;
      bar.title = `${d.focus} dk odak, ${d.todos} iş`;
      const col = document.createElement('i');
      col.style.height = `${Math.max(4, Math.round((d.focus / max) * 86))}px`;
      const label = document.createElement('span');
      label.textContent = WEEKDAYS[d.weekday];
      bar.append(col, label);
      bars.appendChild(bar);
    });
    $('week-total').textContent = minutesText(st.week.reduce((a, d) => a + d.focus, 0));

    $('tt-todos').textContent = st.totals.todos;
    $('tt-focus').textContent = minutesText(st.totals.focusMin);
    $('tt-done').textContent = st.totals.timersDone;
    $('tt-quit').textContent = st.totals.timersQuit;
    $('tt-notes').textContent = st.totals.notes;
    $('tt-best').textContent = `${st.bestStreak} gün`;
    $('tt-pets').textContent = `${st.totals.pets || 0} kere`;
    $('q-focus').textContent = `${state.settings.lastTimerMinutes || 25} dk odaklan`;
  }

  $('home-refresh').addEventListener('click', async () => renderAll(await api.invoke('home:refresh')));
  $('q-focus').addEventListener('click', () => {
    api.invoke('timer:start', state?.settings.lastTimerMinutes || 25, '');
    selectTab('timer');
  });
  $('q-todo').addEventListener('click', () => selectTab('todos'));
  $('q-note').addEventListener('click', () => { selectTab('notes'); openEditor(null); });

  // ---------------------------------------------------------------------------
  // Durum
  // ---------------------------------------------------------------------------
  function renderAll(next) {
    state = next;
    applyUi(state.ui);
    renderMood(state.mood);
    renderNotes();
    renderTodos();
    renderTimer(state.timer);
    renderSettings();
    renderHome();
    renderBadges();
    renderUpdate();
    renderRitual();
    renderRest();
    renderDesk();
    renderLetter();
    renderMoodLog();
    renderArchive();
    renderJar();
  }

  api.on('state', renderAll);
  api.on('timer', (t) => { if (state) state.timer = t; renderTimer(t); });
  api.on('panel:tab', (tab) => selectTab(tab));
  api.on('theme', (payload) => applyUi(payload.manifest.ui));

  document.documentElement.dataset.skin = skinName;
  applySkinText();
  api.invoke('state:get').then(renderAll);
  choose(25);
  selectTab('home');
})();
