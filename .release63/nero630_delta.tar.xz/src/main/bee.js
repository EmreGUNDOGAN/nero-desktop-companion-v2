// Arıcılık mini oyunu: oyun mantığı.
// Nero'nun ana sürecinde çalışır; Arıcılık görülmedikten sonraki ilk 3 saat ilerler, sonra tamamen durur.
// Durum JsonStore ile %APPDATA%\Nero\bee.json dosyasında tutulur.

const VILLAGE = require('./village-data');
const HOUR_MS = 60 * 60 * 1000;
const DAY_GAME_MS = 15 * 60 * 1000;      // 1 oyun günü = 1x hızda 15 gerçek dakika
const DAYS_PER_SEASON = 15;               // bir oyun ayı/mevsim dönemi = 15 gün
const SEASONS = ['ilkbahar', 'yaz', 'sonbahar', 'kis'];
const SEASON_NAMES = { ilkbahar: 'İlkbahar', yaz: 'Yaz', sonbahar: 'Sonbahar', kis: 'Kış' };
const UNATTENDED_CAP_MS = 3 * HOUR_MS;   // Arıcılık 3 saat görülmezse oyun tamamen duraklar
const BASE_KG_PER_BEE_HOUR = 0.5;        // 1 arı, +%0 çiçekle saatte 0.5 kg (uzun vadeli tempo)
// 5.3.0: satın alma fiyatları %25 indirildi
const HIVE_COST = 900;
const START_COINS = 200;
const FLOWER_LIFE_DAYS = 30;             // çiçekler 2 oyun ayı/mevsim dönemi sonra solar
const OUT_OF_SEASON = 0.25; // opposite-season contribution; adjacent seasons use 0.5              // mevsimi dışındaki çiçek
const WINTER_FACTOR = 0.1;               // kışın (şurup 2. aşamada)
const ISLAND_RADIUS = 8;
const FESTIVAL_KEYS = ['-5,1', '-5,2', '-6,1', '-6,2', '-4,2'];
const WINTER_SYRUP_FACTOR = 0.35;        // kışın şurubu olan kovan biraz daha üretir
const SYRUP_COST = 45;
const SYRUP_KG = 15;
const BREED_EVERY_DAYS = 2;
const WORK_MS = 5000;                    // arıcının kovanda çalışma süresi
const WALK_MS_PER_TILE = 700;

const SEASON_PRICE = { ilkbahar: 1, yaz: 0.85, sonbahar: 1, kis: 1.35 };
const STORAGE_UPGRADES = [
  { cap: 100, cost: 340 }, { cap: 200, cost: 900 }, { cap: 400, cost: 2250 },
  { cap: 800, cost: 4000 }, { cap: 1500, cost: 7500 }, { cap: 2500, cost: 12000 },
  { cap: 4000, cost: 20000 }, { cap: 6000, cost: 30000 }, { cap: 10000, cost: 50000 }
];
const HISTORY_DAYS = 7;
const ORDER_EVERY_REAL_MS = 5 * 60 * 1000; // gerçek zamanla 5 dakikada bir sipariş (oyun hızından bağımsız)
const ORDER_CATCHUP_MAX = 3;              // uzun aradan sonra tek açılışta en fazla 3 normal sipariş birikir
const ORDER_EVERY_MS = ORDER_EVERY_REAL_MS;
const ORDER_MAX = 5;
const ORDER_SWAP_COST = 19;
const ORDER_PENALTY = 0.2;
// Rakiplerin satış, yatırım ve risk davranışı; aynı dünya koşullarını kullanırlar.
const RIVALS = [
  { id: 'ali', name: 'Temkinli Ali', style: 'Temkinli' },
  { id: 'kaya', name: 'Riskçi Kaya', style: 'Riskçi' },
  { id: 'nur', name: 'Dengeli Nur', style: 'Dengeli' }
];
const RIVAL_STYLE = {
  ali: { sellShare: .8, sellAt: 0, invest: .3, investAt: 400, flowerBuff: .08, syrupChance: 1, sick: .02 },
  nur: { sellShare: .6, sellAt: 1, invest: .5, investAt: 300, flowerBuff: .18, syrupChance: .8, sick: .03 },
  kaya: { sellShare: 1, sellAt: 1.15, invest: .8, investAt: 200, flowerBuff: .45, syrupChance: .5, sick: .06 }
};
// 32 bit tam sayı işlemleriyle kararlı, rakip/gün bazlı rastgelelik.
function rivalRandom(day, id) {
  let n = (Math.imul(day + 1, 374761393) ^ Math.imul(id.charCodeAt(0), 668265263)) >>> 0;
  return () => { n ^= n << 13; n ^= n >>> 17; n ^= n << 5; return (n >>> 0) / 4294967296; };
}
const HISTORY_NW = 60;                  // net değer geçmişi (istatistik ekranı 7/14/tümü)

// Hava durumu: her gün mevsime göre seçilir, üretimi etkiler
const WEATHER = {
  gunesli: { name: 'Güneşli', icon: '☀️', mult: 1.1 },
  bulutlu: { name: 'Bulutlu', icon: '⛅', mult: 1.0 },
  yagmurlu: { name: 'Yağmurlu', icon: '🌧️', mult: 0.6 },
  karli: { name: 'Karlı', icon: '🌨️', mult: 1.0 }
};
// Mevsime göre hava: yaz hep güneşli; sonbahar bulutlu/yağmurlu; ilkbahar karışık; kış yağmurlu/karlı
const WEATHER_ODDS = {
  ilkbahar: [['gunesli', 0.45], ['bulutlu', 0.3], ['yagmurlu', 0.25]],
  yaz: [['gunesli', 1]],
  sonbahar: [['bulutlu', 0.55], ['yagmurlu', 0.45]],
  kis: [['karli', 0.6], ['yagmurlu', 0.4]]
};

// Günlük görevler (gerçek güne bağlı, her gün 3 görev)
const QUEST_TYPES = [
  'harvest', 'harvestFlower', 'sell', 'deliver', 'candle', 'plant',
  'harvest2Hives', 'harvest3Hives', 'harvestSingle10', 'harvest2Types', 'harvest3Types', 'harvestPremium',
  'sell2Transactions', 'sell2Types', 'sellFlower', 'saleIncome', 'winterSell',
  'acceptOrder', 'deliver2', 'deliverNoPenalty', 'deliverPerson', 'deliverRegular',
  'buyBee', 'buy3Bees', 'syrup1', 'syrup2Hives', 'cureHive', 'changeBreed', 'queenUpgrade', 'hiveUpgrade', 'placeHive',
  'plant2', 'plantFlower', 'reviveFlower', 'plant2Types', 'sellCandles', 'candle2', 'claim2', 'merchantBuy', 'merchantSell'
];
const LABEL_DESIGNS = { klasik: 'Klasik', cicekli: 'Çiçekli', petek: 'Petek', sade: 'Sade' };
const LABEL_BONUS = 0.05;          // etiketli kavanoz: müdavimler %5 fazla öder
const HISTORY_KEEP = 60;                // günlük istatistik geçmişi
const SICK_CHANCE = 0.03;          // kış dışında, kovan başına günlük hastalanma ihtimali
const SICK_MULT = 0.7;             // hasta kovan %30 daha az üretir
const MEDICINE_COST = 90;
const SICK_IMMUNE_YEARS = 1;              // hastalık bittiğinde 1 oyun yılı bağışıklık başlar
const SICK_MIN_BEES = 4;                   // hastalık kovanı 4 arının altına düşüremez
const SICK_DEATH_DIVISOR = 3;              // vaka başına başlangıç arılarının yaklaşık üçte biri ölebilir
const BEE_PRICE_BASE_NUMBER = 7;           // ilk kovanda satın alınan ilk arı: 7. arı
const BEE_PRICE_BASE = 34;
const BEE_PRICE_STEP = 7;
const REVIVE_RATE = 0.1;                  // solan çiçeği canlandırmak: tohum fiyatının %10'u
const REJECT_REL = 0.2;                   // reddetmek ilişkiyi %2 azaltır (1 teslim = %10)
const NOTIF_KEEP = 20;

// Köylü mektupları: birkaç oyun gününde bir; yaklaşık üçte biri küçük hediye içerir
const LETTER_EVERY = [3, 5];
const LETTER_KEEP = 30;
// Belirli köylülere özel mektuplar; diğerleri rolüne göre genel mektuplardan seçer
const LETTERS_BY_NAME = {
  'Ayşe Teyze': ['Torunum doğdu! Mahalleye lokum dağıtıyorum, sana da ayırdım.', 'Eski bir tarif defteri buldum. Bal kurabiyesi var içinde, bir gün yaparım.', 'Pencereye yeni saksılar koydum. Arıların uğrarsa ayıp olmaz.'],
  'Mehmet Usta': ['Kovanlarının kapakları gıcırdıyorsa söyle, bir bakarım.', 'Bisikletimi tamir ettim. Artık yokuşları sadece ben değil o da sevmiyor.'],
  'Küçük Elif': ['Sana arı resmi çizdim! Kanatları biraz büyük oldu ama o uçabiliyor.', 'Okulda arıları anlattım. Herkes senin kovanlarını merak etti.', 'Bugün bir arı elime kondu ve ısırmadı. Arkadaş olduk sanırım.'],
  'Hacer Nine': ['Kapının önünde oturup arılarını izledim. Eskiden de böyle çalışırdık.', 'Ihlamur çayı demledim. Balın olsa daha güzel olurdu, haber veriyorum.'],
  'Muhtar Rıza': ['Köy toplantısında adın geçti. İyi anlamda, merak etme.', 'Muhtarlık panosuna senin balını astık. Herkes soruyor.'],
  'Balıkçı Kemal': ['Bu sabah gölde dev bir sazan gördüm. Tutamadım ama gördüm, o da bir şey.', 'Ağlarımı onarırken arılarının vızıltısı iyi geldi.'],
  'Kasabalı Cem': ['Kasabada senin balını anlattım. Bir arkadaşım ziyarete gelmek istiyor.', 'Köy hayatına alışıyorum. Sessizlik bazen fazla sessiz.'],
  'Öğretmen Selin': ['Öğrencilerim bal hakkında kompozisyon yazdı. En iyisi "Arılar yorulmaz mı?" diye bitiyordu.', 'Kütüphaneye arıcılık kitabı sipariş ettim. Bitince sana da veririm.'],
  'Doktor Aslı': ['Ballı ıhlamur boğaza iyi gelir. Reçete değil, tavsiye.', 'Köyde bu kış kimse hastalanmadı. Senin balının payı var bence.'],
  'Arıcı Hasan': ['Kovanlarının sesi iyi geliyor, bu işi seviyorsun belli.', 'Gençken bir kovanım oğul verdi, üç gün peşinden koştum. Sen koşma, izle.'],
  'Ressam Deniz': ['Arılarını resmettim. Bir tanesi fırçama kondu, imzası da resimde.', 'Gün batımında kovanların çok güzel görünüyor. Işık sende.'],
  'Kerim Dede ve Kedileri': ['Kedilerden biri bu sabah kovanının oraya gitmiş. Arılar kovalayınca geri döndü, gururu kırıldı.', 'Yedinci kedi yavruladı. Sekiz oldular. Hesap tutamıyorum artık.']
};
const LETTERS_GENERIC = [
  'Bugün pencereden arılarını izledim. Çok çalışkanlar, biraz kıskandım.',
  'Kahvaltıda senin balını yedik. Çocuklar kavanozu sıyırdı.',
  'Köyde yağmurdan sonra her yer mis gibi çiçek kokuyor.',
  'Geçen gün yolda karşılaştık ama selam veremedim, telaşlıydım. Selam olsun!',
  'Bahçemdeki çiçekler bu yıl çok güzel açtı. Arıların uğrarsa ikram ederim.',
  'Akşam yürüyüşünde kovanlarının oradan geçtim. Vızıltı insanı dinlendiriyor.'
];

// Ayarlar (oyun içi): görüntü, ses, bildirim tercihleri
const GAME_SETTINGS_DEFAULT = {
  graphics: 'dengeli', night: true, seasonalAppearance: true, sfx: true, ambient: true, notificationSound: true,
  audio: {
    coin: true, harvest: true, place: true, plant: true, paper: true, success: true, error: true,
    birds: true, bees: true, rain: true, wind: true, crickets: true,
    notifyOrders: true, notifyHive: true, notifyMerchant: true, notifySpecial: true
  },
  notify: { full: true, due: true, sick: true, winter: true, rival: true, merchant: true, letter: true }
};

// Gezgin satıcı: Seyyah Yakup
const MERCHANT_EVERY = [6, 9];            // 6-9 oyun gününde bir gelir
const MERCHANT_STAY = 2;                  // 2 oyun günü kalır
const MERCHANT_MAX_BUY = 2;               // bir ziyarette en fazla 2 farklı ürün (her birinden 1)
const MERCHANT_ITEMS = {
  surup: { name: 'Ballı Şurup', icon: '🍯', desc: 'Seçilen kovan 1 oyun günü %50 fazla üretir.', target: 'hive' },
  kralice: { name: 'İndirimli Kraliçe', icon: '👑', desc: 'Seçilen kovanın sıradaki kraliçe yükseltmesini %30 indirimli yapar.', target: 'hiveQueen', dynamicPrice: true },
  tohum: { name: 'Tohum Paketi', icon: '🌱', desc: 'Papatya–Lavanta havuzundan 3 rastgele hediye tohum.', target: null },
  dortMevsim: { name: 'Dört Mevsim Tohumu', icon: '🌸', desc: 'Seçilen tarh 30 gün mevsim dışı ceza almaz.', target: 'flower', dynamicPrice: true },
  suru: { name: 'Arı Sürüsü', icon: '🐝', desc: 'Seçilen kovana +3 arı.', target: 'hiveRoom3', dynamicPrice: true },
  sut: { name: 'Arı Sütü', icon: '🥛', desc: 'Seçilen kovan 3 gün boyunca her gün +1 arı doğurur; kışta da çalışır.', target: 'hive' },
  kit: { name: 'Bakım Kiti', icon: '🩺', desc: 'Hasta kovanı anında iyileştirir ve bağışıklığı başlatır.', target: 'hiveSick' },
  sandik: { name: 'Depo Sandığı', icon: '📦', desc: 'Kalıcı +10 kg depo kapasitesi; toplam en fazla 3.', target: null },
  mum: { name: 'Balmumu Çuvalı', icon: '🕯️', desc: '+1 kg balmumu.', target: null },
  kislikSurup: { name: 'Kışlık Şurup Fıçısı', icon: '🍯', desc: 'Seçilen kovana +45 kg kış erzakı ekler.', target: 'hive' },
  propolis: { name: 'Propolis Kalkanı', icon: '🛡️', desc: 'Seçilen kovanda 10 gün hastalanma ihtimalini %50 azaltır.', target: 'hive' },
  vitamin: { name: 'Arı Vitamini', icon: '💊', desc: 'Seçilen kovan 5 gün +%15 üretim sağlar.', target: 'hive' },
  yalitim: { name: 'Kovan Yalıtımı', icon: '❄️', desc: 'Seçilen kovanda bir sonraki kış şurup tüketimini %50 azaltır.', target: 'hive' },
  irkKupon: { name: 'Irk Değişim Kuponu', icon: '🧬', desc: 'Seçtiğin kovanda tek seferlik ırk değişimi yapar.', target: 'hiveBreed' },
  nakil: { name: 'Arı Nakil Kutusu', icon: '📦', desc: 'İki kovan arasında en fazla 3 arı taşı.', target: 'hiveTransfer' },
  polenKeki: { name: 'Polen Keki', icon: '🌼', desc: 'Seçilen kovanda 5 gün doğal üreme aralığını yarıya indirir.', target: 'hive' },
  acilKis: { name: 'Acil Kış Paketi', icon: '🧯', desc: 'Seçilen kovanda şurup yokluğundan doğacak bir sonraki arı kaybını bir kez engeller.', target: 'hive' },
  cicekBesini: { name: 'Çiçek Besini', icon: '🌿', desc: 'Seçilen tarh 5 gün +%25 üretim sağlar.', target: 'flower' },
  omurGubre: { name: 'Ömür Uzatıcı Gübre', icon: '🌱', desc: 'Seçilen tarhın ömrüne +10 oyun günü ekler.', target: 'flower', dynamicPrice: true },
  yenidenEkim: { name: 'Yeniden Ekim Kuponu', icon: '♻️', desc: 'Solmuş bir tarhı ücretsiz canlandırır.', target: 'flowerWilted' },
  nadirTohum: { name: 'Nadir Tohum Sandığı', icon: '🎁', desc: 'İki yüksek değerli hediye tohum içerir.', target: null },
  mevsimTohum: { name: 'Mevsim Tohum Kutusu', icon: '🌦️', desc: 'Mevcut mevsime uygun 3 hediye tohum içerir.', target: null },
  polenKarisim: { name: 'Özel Polen Karışımı', icon: '🌺', desc: 'Seçilen kovanda çiçek bonuslarını 5 gün %25 güçlendirir.', target: 'hive' },
  eldiven: { name: 'Arıcı Eldiveni', icon: '🧤', desc: 'Sonraki 3 başarılı hasatta balmumu +%50.', target: null },
  balmumuPresi: { name: 'Balmumu Presi', icon: '🕯️', desc: 'Sonraki 5 mum 0,5 kg yerine 0,3 kg balmumu tüketir.', target: null },
  mumKalibi: { name: 'Usta Mum Kalıbı', icon: '🏷️', desc: 'Sonraki 5 mum satışında satış fiyatı +%35.', target: null },
  depoKupon: { name: 'Depo Yükseltme Kuponu', icon: '📦', desc: 'Bir sonraki standart depo yükseltmesi %20 ucuz olur.', target: null, dynamicPrice: true },
  pazarMuhru: { name: 'Pazar Mührü', icon: '💰', desc: 'Bir sonraki pazar satışında en fazla 10 kg bal +%15 fiyatla satılır.', target: null },
  fiyatSabitle: { name: 'Fiyat Sabitleme Fişi', icon: '🔒', desc: 'Seçilen balın mevcut pazar fiyatını 1 oyun günü sabitler.', target: 'honey' },
  pazarTahmin: { name: 'Pazar Tahmin Kartı', icon: '🔮', desc: 'Ertesi gün 3 bal türünün fiyat yönünü önceden gösterir.', target: null },
  siparisKum: { name: 'Sipariş Kum Saati', icon: '⏳', desc: 'Seçilen kabul edilmiş siparişe +1 oyun günü ekler.', target: 'acceptedOrder' },
  siparisMuhru: { name: 'Sipariş Mührü', icon: '🏅', desc: 'Seçilen sipariş başarıyla tamamlanırsa ödemesi +%12 olur.', target: 'order', dynamicPrice: true },
  dostlukJeton: { name: 'Dostluk Jetonu', icon: '💛', desc: 'Bir sonraki başarılı köylü siparişine +10 ilişki puanı verir.', target: null },
  oncelikKart: { name: 'Öncelikli Teslim Kartı', icon: '📮', desc: 'Bir sonraki başarılı köylü siparişine +4 ilişki puanı verir.', target: null },
  festivalCila: { name: 'Festival Cilası', icon: '🏆', desc: 'Bir sonraki turnuvanın Bal Kalitesi puanına +20.', target: null },
  festivalGuvence: { name: 'Festival Güvencesi', icon: '🛡️', desc: 'Kupa alamazsan gönderdiğin balın %60’ı geri gelir.', target: null },
  seyyahFis: { name: 'Seyyah Satış Fişi', icon: '💎', desc: 'Bu ziyarette Yakup’a sattığın en fazla 10 kg bala ek +%10 ödeme.', target: null },
  stokDegisim: { name: 'Stok Değişim Jetonu', icon: '🔄', desc: 'Yakup’un henüz alınmamış bir teklifini bir kez yeniden çeker.', target: 'merchantStock' }
};

// Köylü hikâyeleri: ilişki %50'yi geçince açılır, 3 adım; son ödül küçük ve kalıcı (en fazla %5)
const STORIES = [
  { id: 'hasan', who: 'Arıcı Hasan', title: 'Ustalık yolu', bonus: 'prodAll', value: 0.03, bonusText: 'Tüm bal üretimi +%3',
    steps: [{ t: 'maxBees', n: 20, text: 'Bir kovanı 20 arıya çıkar' }, { t: 'harvestKg', f: 'kestane', n: 10, text: '10 kg kestane balı hasat et' }, { t: 'festivalCup', n: 1, text: 'Mevsim turnuvasında derece al' }] },
  { id: 'ayse', who: 'Ayşe Teyze', title: 'Eski tarifler', bonus: 'candle', value: 0.05, bonusText: 'Mum fiyatı +%5',
    steps: [{ t: 'deliverKg', f: 'papatya', n: 15, text: '15 kg papatya balı teslim et' }, { t: 'candles', n: 3, text: '3 mum yap' }, { t: 'deliverOrders', f: 'kisfundasi', n: 1, text: 'Bir kış fundası siparişini tamamla' }] },
  { id: 'kemal', who: 'Balıkçı Kemal', title: 'Göl kıyısında', bonus: 'yonca', value: 0.05, bonusText: 'Yonca balı fiyatı +%5',
    steps: [{ t: 'nearWater', n: 1, text: 'Göle bitişik bir kareye tarh ek' }, { t: 'harvestKg', f: 'yonca', n: 30, text: '30 kg yonca balı hasat et' }, { t: 'orders', n: 5, text: '5 sipariş teslim et' }] },
  { id: 'elif', who: 'Küçük Elif', title: 'Arı okulu', bonus: 'quest', value: 0.05, bonusText: 'Günlük görev ödülleri +%5',
    steps: [{ t: 'planted', f: 'aycicegi', n: 1, text: 'Ayçiçeği ek' }, { t: 'hiveNamed', n: 1, text: 'Bir kovana isim ver' }, { t: 'quests', n: 10, text: '10 günlük görev tamamla' }] },
  { id: 'selin', who: 'Öğretmen Selin', title: 'Bal Defteri', bonus: 'market', value: 0.02, bonusText: 'Pazar satışları +%2',
    steps: [{ t: 'pages', n: 4, text: 'Bal Defteri\'nde 4 sayfa aç' }, { t: 'label', n: 1, text: 'Kavanoz etiketi tasarla' }, { t: 'soldTypes', n: 3, text: '3 farklı baldan sat' }] },
  { id: 'riza', who: 'Muhtar Rıza', title: 'Köyün sesi', bonus: 'orderPay', value: 0.03, bonusText: 'Köylü siparişleri +%3 ödeme',
    steps: [{ t: 'village', n: 13, text: 'Köyü 13 yerleşimciye ulaştır' }, { t: 'muhtarlik', n: 1, text: 'Bir köy isteğini tamamla' }, { t: 'friends', n: 3, text: '3 köylüyle %50 ilişki kur' }] },
  { id: 'asli', who: 'Doktor Aslı', title: 'Sağlıklı kovanlar', bonus: 'medicine', value: 0.1, bonusText: 'İlaç %10 ucuz',
    steps: [{ t: 'syrup', n: 3, text: '3 kez şurup ver' }, { t: 'cured', n: 1, text: 'Hasta bir kovanı iyileştir' }, { t: 'cleanWinter', n: 1, text: 'Bir kışı arı kaybetmeden geçir' }] },
  { id: 'kerim', who: 'Kerim Dede ve Kedileri', title: 'Kedi dostu', bonus: 'sick', value: 0.05, bonusText: 'Hastalanma ihtimali %5 az',
    steps: [{ t: 'deliverTo', n: 3, text: 'Ona 3 sipariş teslim et' }, { t: 'deliverKg', f: 'kisfundasi', n: 5, text: '5 kg kış fundası balı teslim et' }, { t: 'relation', n: 80, text: 'Onunla %80 ilişkiye ulaş' }] }
];
const CLUSTER_BONUS = 0.15;        // aynı türden en az 3 tarh yan yanaysa
const AWAY_SUMMARY_MS = 20 * 60 * 1000; // 5.5.0: dönüş özeti 20 gerçek dakikadan sonra

// 1) Odak bonusu: Nero'da odaklandıkça arılar da coşar
const FOCUS_BOOST = 0.25;                 // +%25 üretim
const FOCUS_BOOST_MS = 60 * 60 * 1000;    // odak seansı başına 1 gerçek saat (üst üste eklenir, en fazla 4 saat)
const TODO_REWARD = 10;                   // Nero'da bitirilen her iş: +10 jeton

// 2) Müdavim köylüler
const HEART_EVERY = 2;                    // her 2 teslimde +1 kalp
const HEART_MAX = 5;
const HEART_BONUS = 0.02;                 // 5.5.0: kalp başına +%2 ödeme

// 3) Dekorlar (kare kaplamaz, karenin kenarına konur)
const DECOR = {
  cit:    { name: 'Çit', cost: 30, desc: 'Tarhların etrafına sevimli bir çit.' },
  bank:   { name: 'Bank', cost: 90, desc: 'Arıları seyretmek için.' },
  fener:  { name: 'Fener', cost: 115, desc: 'Akşamları sıcak bir ışık.' },
  kemer:  { name: 'Çiçekli kemer', cost: 225, desc: 'Adanın girişine romantik bir kemer.' },
  cesme:  { name: 'Çeşme', cost: 300, desc: 'Yanındaki tarhlar +%5 üretir.', bonus: 0.05 },
  kupa:   { name: 'Turnuva kupası', cost: 0, desc: 'Mevsim turnuvasında kazanıldı.', prize: true }
};

// Her mevsimin son üç gününde katılım, sonraki mevsimin ilk gününde sonuç.
const FESTIVAL_OPEN_DAY = DAYS_PER_SEASON - 3;
const FESTIVAL_MAX_KG = 10;
const FESTIVAL_PRIZES = [{ coins: 750, cup: 'altın' }, { coins: 500, cup: 'gümüş' }, { coins: 250, cup: 'bronz' }];

// 5) Arı ırkları
const BREEDS = {
  anadolu: { name: 'Anadolu arısı', desc: 'Çalışkan: +%10 üretim, ama hastalığa daha açık.', prod: 1.1, sick: 1.5, breedDays: 2, winter: 1 },
  kafkas:  { name: 'Kafkas arısı', desc: 'Soğuğa dayanıklı: kışın yarı yarıya az kayıp.', prod: 1.0, sick: 1.0, breedDays: 2, winter: 2 },
  italyan: { name: 'İtalyan arısı', desc: 'Hızlı çoğalır: her gün yeni arı, biraz daha az üretim.', prod: 0.95, sick: 1.0, breedDays: 1, winter: 1 }
};
const BREED_CHANGE_COST = 225;

// 6) Balmumu ve mum
const WAX_PER_KG = 0.025;                 // her 1 kg hasatta 25 g balmumu
const CANDLE_WAX = 0.5;                   // 1 mum = 0.5 kg balmumu
const CANDLE_PRICE = 45;

const CUSTOMERS = ['Ayşe Teyze', 'Mehmet Usta', 'Küçük Elif', 'Fırıncı Leyla', 'Kasabalı Cem', 'Hacer Nine', 'Muhtar Rıza',
  'Pastacı Nur', 'Öğretmen Selin', 'Balıkçı Kemal', 'Doktor Aslı', 'Bakkal Hüseyin'];

const QUEEN_NAMES = ['Genç Kraliçe', 'Sağlıklı Kraliçe', 'Güçlü Kraliçe', 'Olgun Kraliçe', 'Asil Kraliçe', 'Efsane Kraliçe'];
// Sıra: önce arı, sonra kovan, sonra yine arı. Arı üst sınırı 20.
const UPGRADES = [
  { type: 'queen', capBees: 12, cost: 340 },
  { type: 'hive', capKg: 30, cost: 565 },
  { type: 'queen', capBees: 14, cost: 900 },
  { type: 'hive', capKg: 40, cost: 1350 },
  { type: 'queen', capBees: 16, cost: 2025 },
  { type: 'hive', capKg: 60, cost: 2925 },
  { type: 'queen', capBees: 18, cost: 4275 },
  { type: 'queen', capBees: 20, cost: 6300 },
  { type: 'hive', capKg: 80, cost: 6750 }
];

const FLOWERS = {
  yonca:    { name: 'Yonca',    seed: 45,  buff: 0.02, price: 8,  seasons: ['ilkbahar'], color: '#C9E6A0', petal: '#FFFFFF' },
  papatya:  { name: 'Papatya',  seed: 90,  buff: 0.04, price: 12, seasons: ['yaz'], color: '#F0DE7A', petal: '#FFFFFF' },
  aycicegi: { name: 'Ayçiçeği', seed: 190, buff: 0.06, price: 18, seasons: ['yaz'],             color: '#F5C851', petal: '#F7C22E' },
  kekik:    { name: 'Kekik',    seed: 340, buff: 0.10, price: 26, seasons: ['ilkbahar'], color: '#D8A6E0', petal: '#C98BD6' },
  lavanta:  { name: 'Lavanta',  seed: 600, buff: 0.13, price: 38, seasons: ['sonbahar'],        color: '#B79BE0', petal: '#9C7BD6' },
  kisfundasi:  { name: 'Kış Fundası', seed: 975, buff: 0.17, price: 55, seasons: ['kis'],             color: '#9FD6C9', petal: '#F3EBAE' },
  kestane:  { name: 'Kestane',  seed: 1650, buff: 0.22, price: 80, seasons: ['sonbahar'],        color: '#B98A5A', petal: '#E8D9A0' }
};

// Eksenel altıgen koordinatları: bir karenin 6 komşusu
const DIRS = [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]];
const key = (q, r) => `${q},${r}`;
const parse = (k) => k.split(',').map(Number);
const hexDist = (q, r) => (Math.abs(q) + Math.abs(r) + Math.abs(q + r)) / 2;

function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

function migrateWinterHeather(value) {
  if (Array.isArray(value)) return value.map(migrateWinterHeather);
  if (value && typeof value === 'object') {
    for (const [key, old] of Object.entries(value)) {
      if (key === 'ihlamur') {
        const replacement = migrateWinterHeather(old);
        const previous = value.kisfundasi;
        value.kisfundasi = previous == null ? replacement : typeof previous === 'number' && typeof replacement === 'number'
          ? previous + replacement : previous;
        delete value.ihlamur;
      } else value[key] = migrateWinterHeather(old);
    }
    return value;
  }
  return value === 'ihlamur' ? 'kisfundasi' : value;
}

// Başlangıç adası: merkez 7 kare sahip; çevresi satın alınabilir; birkaç göl karesi.
function makeIsland() {
  const tiles = {};
  const water = new Set(['-3,1', '-3,2', '-2,2', '3,-3', '4,-3', '3,-2', '-1,-3', '0,-4']);
  for (let q = -ISLAND_RADIUS; q <= ISLAND_RADIUS; q++) {
    for (let r = -ISLAND_RADIUS; r <= ISLAND_RADIUS; r++) {
      if (hexDist(q, r) > ISLAND_RADIUS) continue;
      const k = key(q, r);
      const owned = hexDist(q, r) <= 1;
      tiles[k] = {
        q, r,
        kind: water.has(k) ? 'water' : 'grass',
        owned: owned && !water.has(k),
        item: null // { type: 'hive', id } | { type: 'flower', flower } | { type: 'house' }
      };
    }
  }
  // Ağaçlar: sahip olunmayan bazı çim karelerde süs
  const decor = ['-4,2', '2,-4', '4,-1', '-2,-2', '1,3', '-4,4', '3,1', '-1,4', '4,-4', '-5,3', '0,5', '5,-2'];
  for (const k of decor) if (tiles[k] && tiles[k].kind === 'grass' && !tiles[k].owned && !FESTIVAL_KEYS.includes(k)) tiles[k].tree = true;
  for (const k of FESTIVAL_KEYS) if (tiles[k] && tiles[k].kind === 'grass') {
    tiles[k].kind = 'festival'; tiles[k].owned = false; tiles[k].tree = false;
  }
  tiles['-2,1'].kind = 'storage';
  return tiles;
}

function newHive(id, name, bees, invested) {
  return { breed: 'anadolu', id, name, bees, capBees: 10, capKg: 20, honey: {}, level: 0, queens: 0, syrup: 0, beesBought: 0, invested, breedDay: 0, sickDeaths: 0 };
}

function freshState() {
  const tiles = makeIsland();
  tiles['0,0'].item = { type: 'house' };
  const hiveId = uid();
  tiles['1,0'].item = { type: 'hive', id: hiveId };
  tiles['1,-1'].item = { type: 'flower', flower: 'yonca' };
  tiles['0,1'].item = { type: 'flower', flower: 'papatya' };
  return {
    v: 1,
    coins: START_COINS,
    speed: 1,              // 0 = duraklatıldı
    gameMs: 0,             // toplam oyun zamanı
    tilesBought: 0,
    lastSeenAt: Date.now(),
    tiles,
    hives: {
      [hiveId]: newHive(hiveId, 'Kovan 1', 6, 0)
    },
    storage: {},           // bal türü -> kg
    storageBaseCap: 50,
    storageCap: 50,
    keeper: { queue: [], job: null },
    market: null,
    orders: { list: [], nextAt: ORDER_EVERY_MS },
    rivals: null,
    nwHistory: [],
    weather: 'gunesli',
    tutorialDone: false,
    counters: { produced: 0, born: 0, ordersIn: 0, died: 0 },
    away: null,
    focusBoostUntil: 0,
    focusDaily: { day: '', earnedMs: 0 },
    questRefresh: null,
    merchantEffects: {},
    marketLocks: {},
    customers: {},
    vouchers: {},
    wax: 0,
    candles: 0,
    festival: { entry: null, cups: [], lastYear: 0 }
  };
}

class BeeGame {
  constructor(store) {
    this.store = store;
    const s = store.get();
    this.state = s && s.v === 1 && s.tiles ? s : freshState();
    // Expand old saves without overwriting the player's land or structures.
    if (!this.state.islandExpanded61) {
      const expanded = makeIsland();
      for (const [k, t] of Object.entries(expanded)) if (!this.state.tiles[k]) this.state.tiles[k] = t;
      for (const k of FESTIVAL_KEYS) {
        const t = this.state.tiles[k];
        if (t && !t.owned && !t.item) { t.kind = 'festival'; t.tree = false; t.decor = null; }
      }
      if (this.state.village?.slots) for (const n of Object.keys(this.state.village.slots))
        this.state.village.slots[n] = this.villageSlot(Number(n));
      if (this.state.merchant) this.state.merchant.slot = null;
      this.state.islandExpanded61 = true;
    }
    const restoredPlacement = this.state.undoPlacement;
    if (restoredPlacement) { // restarting closes the undo window and commits the placement
      const t = this.state.tiles[restoredPlacement.key];
      if (t?.item) delete t.item.undoPending;
      if (restoredPlacement.kind === 'hive' && this.state.hives[restoredPlacement.id])
        delete this.state.hives[restoredPlacement.id].undoPending;
      this.state.undoPlacement = null;
    }
    if (!this.state.winterHeatherMigrated) {
      migrateWinterHeather(this.state);
      this.state.winterHeatherMigrated = true;
    }
    // On existing saves, preserve any player-placed item and use an adjacent free site.
    const storeTile = ['-2,1', '-2,0', '-1,2'].find((k) => {
      const t = this.state.tiles[k]; return t && t.kind !== 'water' && t.kind !== 'festival' && !t.item;
    });
    if (storeTile) {
      for (const t of Object.values(this.state.tiles)) if (t.kind === 'storage' && t !== this.state.tiles[storeTile]) t.kind = 'grass';
      this.state.tiles[storeTile].kind = 'storage';
      this.state.tiles[storeTile].owned = false;
    }
    this.state.keeper = this.state.keeper || { queue: [], job: null };
    if (!this.state.keeper.job) this.state.keeper.carrying = false;
    if (!Number.isInteger(this.state.hivesPurchased)) this.state.hivesPurchased = Math.max(0, Object.keys(this.state.hives).length - 1);
    for (const h of Object.values(this.state.hives)) {
      Object.assign(h, { level: 0, queens: 0, syrup: 0, beesBought: 0, invested: 0, breedDay: 0, sickDeaths: 0, ...h });
      if (h.sick) {
        h.sickStartBees = h.sickStartBees || h.bees;
        h.sickDeaths = h.sickDeaths || 0;
        h.immuneUntil = 0;
      } else if (h.immuneUntil) {
        h.immuneUntil = Math.min(h.immuneUntil, this.dayIndex() + DAYS_PER_SEASON * 4 * SICK_IMMUNE_YEARS);
      }
    }
    this.state.weather = this.state.weather || 'gunesli';
    this.state.counters = this.state.counters || { produced: 0, born: 0, ordersIn: 0, died: 0 };
    if (this.state.tutorialDone === undefined) this.state.tutorialDone = true; // eski kayıtlarda tanıtım gösterilmez
    for (const t of Object.values(this.state.tiles)) {
      if (t.item && t.item.type === 'flower' && t.item.plantedDay === undefined) t.item.plantedDay = this.dayIndex();
    }
    Object.assign(this.state, {
      focusBoostUntil: 0, focusDaily: { day: '', earnedMs: 0 }, questRefresh: null, merchantEffects: {}, marketLocks: {},
      customers: {}, vouchers: {}, wax: 0, candles: 0,
      festival: { entry: null, cups: [], lastYear: 0 }, ...this.state
    });
    if (this.state.festival.entry && this.state.festival.entry.seasonIndex == null)
      this.state.festival.entry.seasonIndex = Math.floor(this.dayIndex() / DAYS_PER_SEASON);
    this.state.focusDaily = this.state.focusDaily || { day: '', earnedMs: 0 };
    this.state.merchantEffects = this.state.merchantEffects || {};
    this.state.marketLocks = this.state.marketLocks || {};
    for (const h of Object.values(this.state.hives)) if (!h.breed) h.breed = 'anadolu';
    Object.assign(this.state, {
      farmName: 'Nero Çiftliği', quests: null, questsDone: 0, milestones: {}, history: [],
      label: null, ledger: { honey: {}, harvests: 0, ordersDone: 0, candlesMade: 0, bestSale: null, maxBees: 0 },
      ezgiWelcomeClaimed: false, ezgiWelcomePending: false,
      ...this.state
    });
    this.state.counters.earned = this.state.counters.earned || 0;
    if (!this.state.village) {
      // Eski kayıtlar: teslim edilen siparişlerden kabaca bir başlangıç miktarı çıkar
      const est = (this.state.ledger && this.state.ledger.ordersDone ? this.state.ledger.ordersDone : 0) * 6;
      this.state.village = { deliveredKg: est, arrived: [], slots: {}, special: {} };
    }
    this.checkVillage(true);
    if (this.state.village.arrived.includes(7) && this.state.ezgiWelcomeClaimed !== true) this.state.ezgiWelcomePending = true;
    if (!this.state.merchant) this.state.merchant = { nextDay: this.dayIndex() + 3, active: false, stock: [], bought: [], sandik: 0 };
    const crateBonus = (this.state.merchant.sandik || 0) * 10;
    if (this.state.storageBaseCap == null) this.state.storageBaseCap = Math.max(50, (this.state.storageCap || 50) - crateBonus);
    this.state.storageCap = this.state.storageBaseCap + crateBonus;
    if (!this.state.stories) this.state.stories = {};
    if (!this.state.letters) this.state.letters = [];
    if (this.state.nextLetterDay == null) this.state.nextLetterDay = this.dayIndex() + 2;
    const gs = this.state.gameSettings || {};
    this.state.gameSettings = {
      ...GAME_SETTINGS_DEFAULT, ...gs,
      audio: { ...GAME_SETTINGS_DEFAULT.audio, ...(gs.audio || {}) },
      notify: { ...GAME_SETTINGS_DEFAULT.notify, ...(gs.notify || {}) }
    };
    const L0 = this.state.ledger;
    Object.assign(L0, { deliveredKgBy: {}, deliveredOrdersBy: {}, deliveredTo: {}, syrupGiven: 0, cured: 0, cleanWinters: 0, muhtarlikDone: 0, ...L0 });
    if (this.state.festival.seasonStartOrders == null) this.state.festival.seasonStartOrders = L0.ordersDone;
    if (this.state.festival.seasonStartDeaths == null) this.state.festival.seasonStartDeaths = this.state.counters.died || 0;
    this.state.winterDeaths = this.state.winterDeaths || 0;
    this.state.counters.soldBy = this.state.counters.soldBy || {};   // bal türüne göre toplam satış (istatistik: "Ne sattın?")
    this.dayStart = { produced: this.state.counters.produced, earned: this.state.counters.earned, soldBy: { ...this.state.counters.soldBy } };
    // Eski kayıtlarda mevsime uymayan hava kalmışsa (ör. kışın güneş) düzelt
    const season0 = this.calendar().season;
    if (!WEATHER_ODDS[season0].some(([w]) => w === this.state.weather)) this.rollWeather(season0, true);
    this.alertSeen = {};
    this.events = [];
    this.lastDay = this.dayIndex();
    if (!this.state.market) this.state.market = this.newMarket();
    if (!this.state.orders) this.state.orders = { list: [], nextAt: this.state.gameMs + ORDER_EVERY_MS };
    if (this.state.orders.nextAtReal && this.state.orders.nextAtReal > Date.now() + ORDER_EVERY_REAL_MS) this.state.orders.nextAtReal = Date.now() + ORDER_EVERY_REAL_MS;
    if (!this.state.rivals) {
      const base = this.netWorth();
      this.state.rivals = RIVALS.map((r, i) => ({ id: r.id, nw: Math.round(base * (0.85 + i * 0.12)), history: [], last: 0 }));
      this.state.nwHistory = [];
    }
    for (const r of this.state.rivals) {
      const style = RIVAL_STYLE[r.id];
      if (!style) continue;
      if (!r.farm) {
        // Önceki kayıtların sıralama değeri mümkün olduğunca korunur.
        const hives = Math.max(1, Math.floor((r.nw || 0) / 1800));
        const bees = 4;
        r.farm = { coins: Math.max(0, (r.nw || 0) - hives * (HIVE_COST * .5 + bees * 5)),
          hives, bees, honey: 0, syrupDays: 0, buff: style.flowerBuff };
      }
    }
    // Eski sürümde rakiplere oyun günü başına sekiz saatlik üretim yazılıyordu.
    // Bu şişmiş kayıtları bir kez oyuncunun mevcut çiftlik ölçeğine taşı.
    if (!this.state.rivalDayRateFixed) {
      const mine = this.netWorth();
      const myHives = Object.values(this.state.hives);
      for (const [i, r] of this.state.rivals.entries()) {
        if (!r.farm || r.nw <= Math.max(10000, mine * 3)) continue;
        const f = r.farm;
        const old = r.nw;
        f.hives = Math.min(f.hives, myHives.length + 1);
        f.bees = Math.min(f.bees, Math.max(6, ...myHives.map((h) => h.bees + 2)));
        f.honey = Math.min(f.honey, f.hives * 2);
        const target = Math.round(mine * [0.95, 1.2, 1.1][i]);
        f.coins = Math.max(0, target - f.honey * this.price('yonca') - f.hives * (HIVE_COST * .5 + f.bees * 5));
        r.nw = Math.round(f.coins + f.honey * this.price('yonca') + f.hives * (HIVE_COST * .5 + f.bees * 5));
        r.history = (r.history || []).map((value) => Math.max(0, Math.round(value * r.nw / old)));
        r.last = 0;
      }
      this.state.rivalDayRateFixed = true;
    }
    if (restoredPlacement) {
      if (restoredPlacement.kind === 'hive' && this.state.hives[restoredPlacement.id])
        this.questEvent('placeHive', { hiveId: restoredPlacement.id });
      else if (restoredPlacement.kind === 'flower') this.questEvent('plant', { flower: restoredPlacement.flower });
    }
    this.lastTickAt = Date.now();
    this.save();
  }

  save() { this.store.set(this.state); }

  dayIndex() { return Math.floor(this.state.gameMs / DAY_GAME_MS); }

  // --- Takvim -------------------------------------------------------------
  calendar() {
    const day = Math.floor(this.state.gameMs / DAY_GAME_MS);
    const seasonIdx = Math.floor(day / DAYS_PER_SEASON) % 4;
    const season = SEASONS[seasonIdx];
    return {
      day: (day % DAYS_PER_SEASON) + 1,
      daysPerMonth: DAYS_PER_SEASON,
      yearDays: DAYS_PER_SEASON * 4,
      year: Math.floor(day / (DAYS_PER_SEASON * 4)) + 1,
      season,
      seasonName: SEASON_NAMES[season],
      dayProgress: (this.state.gameMs % DAY_GAME_MS) / DAY_GAME_MS
    };
  }

  // --- Üretim ---------------------------------------------------------------
  // Kovanın komşu karelerindeki çiçekler
  flowersNear(hiveTileKey) {
    const [q, r] = parse(hiveTileKey);
    const out = [];
    for (const [dq, dr] of DIRS) {
      const t = this.state.tiles[key(q + dq, r + dr)];
      if (t && t.owned && t.item && t.item.type === 'flower' && !t.item.wilted && !t.item.undoPending) out.push(t.item.flower);
    }
    return out;
  }

  flowerTilesNear(hiveTileKey) {
    const [q, r] = parse(hiveTileKey);
    const out = [];
    for (const [dq, dr] of DIRS) {
      const k2 = key(q + dq, r + dr);
      const t = this.state.tiles[k2];
      if (t && t.owned && t.item && t.item.type === 'flower' && !t.item.wilted && !t.item.undoPending) out.push({ flower: t.item.flower, key: k2 });
    }
    return out;
  }

  // Aynı türden tarhlar birbirine değiyorsa ve grup en az 3 tarhsa bonus
  clusterBonus(flowerKey) {
    const start = this.state.tiles[flowerKey];
    if (!start || !start.item || start.item.type !== 'flower') return 0;
    const type = start.item.flower;
    const seen = new Set([flowerKey]);
    const stack = [flowerKey];
    while (stack.length && seen.size < 3) {
      const [q, r] = parse(stack.pop());
      for (const [dq, dr] of DIRS) {
        const k2 = key(q + dq, r + dr);
        const t = this.state.tiles[k2];
        if (!seen.has(k2) && t && t.owned && t.item && t.item.type === 'flower' && t.item.flower === type) { seen.add(k2); stack.push(k2); }
      }
    }
    return seen.size >= 3 ? CLUSTER_BONUS : 0;
  }

  hiveTileKey(hiveId) {
    for (const [k, t] of Object.entries(this.state.tiles)) {
      if (t.item && t.item.type === 'hive' && t.item.id === hiveId) return k;
    }
    return null;
  }

  winterFeedNeed(hive, day = this.dayIndex()) {
    const insulated = day >= (hive.insulationFromDay || Infinity) && day < (hive.insulationUntilDay || -Infinity);
    return insulated ? 0.5 : 1;
  }

  // Bal türüne göre satış sayacı (pazar + sipariş + satıcı)
  countSold(f, kg) { const s = this.state.counters.soldBy; s[f] = (s[f] || 0) + kg; }
  // Verilen andan bu yana bal türüne göre satılan kg
  soldSince(base = {}) {
    return Object.fromEntries(Object.entries(this.state.counters.soldBy || {})
      .map(([f, kg]) => [f, Math.round((kg - (base[f] || 0)) * 10) / 10]).filter(([, kg]) => kg > 0));
  }

  feedDays(hive, day = this.dayIndex()) {
    return Math.max(0, Math.floor((Number(hive.syrup) || 0) / this.winterFeedNeed(hive, day)));
  }

  // Bal türü başına saatlik üretim (kg/saat, 1x hızda)
  hiveRates(hiveId) {
    const hive = this.state.hives[hiveId];
    const k = this.hiveTileKey(hiveId);
    if (!hive || !k) return {};
    const near = this.flowerTilesNear(k);
    if (!near.length) return {};
    const season = this.calendar().season;
    const rates = {};
    const weather = WEATHER[this.state.weather] || WEATHER.bulutlu;
    const share = (hive.bees * BASE_KG_PER_BEE_HOUR) / near.length;
    const day = this.dayIndex();
    const seasonWeight = (flower, tile) => {
      if (day < (tile?.item?.allSeasonUntil || 0)) return 1;
      const distance = Math.abs(SEASONS.indexOf(season) - SEASONS.indexOf(FLOWERS[flower].seasons[0]));
      return distance === 0 ? 1 : distance === 2 ? 0.25 : 0.5;
    };
    const pollenBuff = day < (hive.pollenMixUntilDay || 0) ? 1.25 : 1;
    const flowerBuff = near.reduce((total, { flower, key: tileKey }) =>
      total + FLOWERS[flower].buff * seasonWeight(flower, this.state.tiles[tileKey]), 0) * pollenBuff;
    for (const { flower: f, key: fk } of near) {
      const def = FLOWERS[f];
      const breed = BREEDS[hive.breed] || BREEDS.anadolu;
      const focus = Date.now() < (this.state.focusBoostUntil || 0) ? 1 + FOCUS_BOOST : 1;
      const flowerFeed = day < ((this.state.tiles[fk].item || {}).feedUntilDay || 0) ? 1.25 : 1;
      const vitamin = day < (hive.vitaminUntilDay || 0) ? 1.15 : 1;
      const winnerBuff = (this.state.festival?.cups || []).some((cup) => cup.cup === 'altın'
        && cup.season === season && cup.year === this.calendar().year - 1) ? 1.2 : 1;
      let mult = (1 + flowerBuff) * winnerBuff * weather.mult * (hive.sick ? SICK_MULT : 1) * (1 + this.clusterBonus(fk) + this.fountainBonus(fk))
        * breed.prod * focus * vitamin * flowerFeed * (1 + this.fx('prodBonus') + this.storyFx('prodAll'))
        * (day < (hive.boostUntilDay || 0) ? 1.5 : 1);
      // Çiçeğin mevsim uyumu her mevsimde hem bal katkısına hem buff hesabına uygulanır.
      // Kışın buna ek olarak kovanın beslenme kaynaklı genel kış çarpanı devreye girer.
      mult *= seasonWeight(f, this.state.tiles[fk]);
      if (season === 'kis') {
        const fed = hive.fedDay === day || hive.syrup >= this.winterFeedNeed(hive, day);
        mult *= fed ? WINTER_SYRUP_FACTOR : WINTER_FACTOR;
      }
      rates[f] = (rates[f] || 0) + share * mult;
    }
    return rates;
  }

  hiveTotal(hive) { return Object.values(hive.honey).reduce((a, b) => a + b, 0); }

  // Gerçek zaman ilerledikçe çağrılır
  tick(now = Date.now(), speedCap = null) {
    if (this.state.undoPlacement && now >= this.state.undoPlacement.expiresAt) this.commitPlacement();
    const realDt = Math.max(0, Math.min(now - this.lastTickAt, 60 * 1000));
    this.lastTickAt = now;

    // Son görülmeden 3 gerçek saat sonra yalnız üretim değil, tüm oyun simülasyonu donar.
    if (now - this.state.lastSeenAt >= UNATTENDED_CAP_MS) {
      if (!this.state.pauseStartedAt) {
        this.state.pauseStartedAt = this.state.lastSeenAt + UNATTENDED_CAP_MS;
        this.save();
      }
      return false;
    }

    const keeperChanged = this.processKeeper(now);
    const selectedSpeed = this.state.speed;
    const speed = speedCap == null ? selectedSpeed : Math.min(selectedSpeed, speedCap);
    if (!speed || !realDt) return keeperChanged;

    const gameDt = realDt * speed;
    this.state.gameMs += gameDt;
    const today = this.dayIndex();
    while (this.lastDay < today) { this.lastDay += 1; this.onNewDay(this.lastDay); }
    this.processOrders();
    this.checkStories();

    const hours = gameDt / HOUR_MS;
    for (const hive of Object.values(this.state.hives)) {
      if (hive.undoPending) continue;
      const rates = this.hiveRates(hive.id);
      let room = hive.capKg - this.hiveTotal(hive);
      if (room <= 0) continue;
      const total = Object.values(rates).reduce((a, b) => a + b, 0) * hours;
      if (total <= 0) continue;
      const scale = Math.min(1, room / total);
      for (const [f, rate] of Object.entries(rates)) {
        hive.honey[f] = (hive.honey[f] || 0) + rate * hours * scale;
      }
      this.state.counters.produced += total * scale;
    }
    return true;
  }

  markSeen() {
    const now = Date.now();
    if (this.state.pauseStartedAt) {
      const pausedFor = Math.max(0, now - this.state.pauseStartedAt);
      const job = this.state.keeper && this.state.keeper.job;
      if (job && pausedFor) {
        if (job.startAt) job.startAt += pausedFor;
        if (job.arriveAt) job.arriveAt += pausedFor;
        if (job.doneAt) job.doneAt += pausedFor;
      }
      if (this.state.orders && this.state.orders.nextAtReal) {
        const remaining = Math.max(0, this.state.orders.nextAtReal - this.state.pauseStartedAt);
        this.state.orders.nextAtReal = now + remaining;
      }
      this.state.pauseStartedAt = null;
    }
    this.state.lastSeenAt = now;
  }

  // --- Hastalık ---------------------------------------------------------------
  sicknessDeathLimit(h) {
    const start = Math.max(SICK_MIN_BEES, Number(h.sickStartBees) || h.bees || SICK_MIN_BEES);
    const roundedThird = Math.max(1, Math.round(start / SICK_DEATH_DIVISOR));
    return Math.max(0, Math.min(start - SICK_MIN_BEES, roundedThird));
  }

  recoverHive(h, dayIdx, notify = true) {
    h.sick = false;
    h.immuneUntil = dayIdx + DAYS_PER_SEASON * 4 * SICK_IMMUNE_YEARS;
    h.sickSince = null;
    h.sickStartBees = null;
    h.sickDeaths = 0;
    if (notify) this.events.push({ msg: `🛡️ ${h.name} hastalığı atlattı. 1 oyun yılı bağışık.` });
  }

  // --- Günlük olaylar: üreme, kış kaybı -------------------------------------
  onNewDay(dayIdx) {
    this.merchantDay(dayIdx);
    if (dayIdx >= this.state.nextLetterDay) this.sendLetter(dayIdx);
    const seasonToday = SEASONS[Math.floor(dayIdx / DAYS_PER_SEASON) % 4];
    if (seasonToday === 'sonbahar' && dayIdx % DAYS_PER_SEASON === DAYS_PER_SEASON - 2
      && this.state.winterAlertSeason !== Math.floor(dayIdx / DAYS_PER_SEASON)) {
      this.state.winterAlertSeason = Math.floor(dayIdx / DAYS_PER_SEASON);
      const hungry = this.winterHungryHives();
      if (hungry.length) this.events.push({ msg: `❄️ Kış geliyor: ${hungry.length} kovanda erzak yok. Tümüne şurup ver?`,
        go: { to: 'winterSyrup' }, err: true });
    }
    const seasonYesterday = SEASONS[Math.floor((dayIdx - 1) / DAYS_PER_SEASON) % 4];
    if (seasonYesterday === 'kis' && seasonToday !== 'kis') {
      if (!this.state.winterDeaths) this.state.ledger.cleanWinters += 1;
      this.state.winterDeaths = 0;
    }
    for (const h of Object.values(this.state.hives)) {
      if ((h.milkDays || 0) > 0 && h.bees < h.capBees) { h.bees += 1; h.milkDays -= 1; this.state.counters.born += 1; this.events.push({ msg: `🥛 ${h.name}: arı sütü sayesinde yeni bir arı doğdu.` }); }
      else if ((h.milkDays || 0) > 0) h.milkDays -= 1;
    }
    const c = this.state.counters;
    this.state.history = [...(this.state.history || []), {
      day: dayIdx - 1,
      produced: Math.round((c.produced - this.dayStart.produced) * 10) / 10,
      earned: Math.round(c.earned - this.dayStart.earned),
      sold: this.soldSince(this.dayStart.soldBy)
    }].slice(-HISTORY_KEEP);
    this.dayStart = { produced: c.produced, earned: c.earned, soldBy: { ...c.soldBy } };
    this.rollMarket();
    const season = SEASONS[Math.floor(dayIdx / DAYS_PER_SEASON) % 4];
    this.rollWeather(season);
    if (dayIdx % DAYS_PER_SEASON === 0 && dayIdx > 0) this.judgeFestival(dayIdx);
    this.rollRivals(dayIdx);
    for (const t of Object.values(this.state.tiles)) {
      if (t.item && t.item.type === 'flower' && !t.item.wilted && dayIdx - (t.item.plantedDay || 0) >= FLOWER_LIFE_DAYS + this.fx('flowerLife')) {
        t.item.wilted = true;
        this.events.push({ msg: `🥀 Bir ${FLOWERS[t.item.flower].name} tarhı soldu. Yeniden ekmen gerekiyor.`, err: true });
      }
    }
    for (const h of Object.values(this.state.hives)) {
      const k = this.hiveTileKey(h.id);
      if (!k) continue;
      const wasSick = !!h.sick;
      // Hastalık: 2 günde bir kayıp olabilir; tek vakada en fazla başlangıç nüfusunun yaklaşık üçte biri ölür.
      if (h.sick) {
        const limit = this.sicknessDeathLimit(h);
        if (h.bees <= SICK_MIN_BEES || (h.sickDeaths || 0) >= limit) {
          this.recoverHive(h, dayIdx);
        } else if ((dayIdx - h.sickSince) % 2 === 1 && h.bees > SICK_MIN_BEES) {
          h.bees -= 1;
          h.sickDeaths = (h.sickDeaths || 0) + 1;
          this.state.counters.died += 1;
          this.events.push({ msg: `${h.name}: hasta kovanda bir arı öldü.`, err: true });
          if (h.bees <= SICK_MIN_BEES || h.sickDeaths >= limit) this.recoverHive(h, dayIdx);
        }
      } else if (season !== 'kis' && h.bees > SICK_MIN_BEES && dayIdx >= (h.immuneUntil || 0) && Math.random() < SICK_CHANCE * (BREEDS[h.breed] || BREEDS.anadolu).sick * (1 - this.fx('sickReduce') - this.storyFx('sick')) * (dayIdx < (h.propolisUntilDay || 0) ? 0.5 : 1)) {
        h.sick = true;
        h.sickSince = dayIdx;
        h.sickStartBees = h.bees;
        h.sickDeaths = 0;
        h.immuneUntil = 0;
        this.events.push({ msg: `🤒 ${h.name} hastalandı! Üretim düştü, ilaç ver.`, err: true });
      }
      if (season === 'kis') {
        const need = this.winterFeedNeed(h, dayIdx);
        const fullyFed = h.syrup >= need;
        if (fullyFed) {
          h.syrup = Math.max(0, h.syrup - need);
          h.fedDay = dayIdx;
        } else {
          // Yarım erzak sonraki güne "hayalet stok" olarak taşınmaz.
          if (h.syrup > 0) h.syrup = 0;
          h.fedDay = null;
          if (h.bees > 1 && dayIdx % (BREEDS[h.breed] || BREEDS.anadolu).winter === 0) {
            if (h.winterShield) { h.winterShield = 0; this.events.push({ msg: `🧯 ${h.name}: Acil Kış Paketi bir arı kaybını engelledi.` }); }
            else { h.bees -= 1; this.state.counters.died += 1; this.state.winterDeaths = (this.state.winterDeaths || 0) + 1; this.events.push({ msg: `${h.name}: kışın aç kalan bir arı öldü. Şurup ver!`, err: true }); }
          }
        }
      } else if (!wasSick && h.bees < h.capBees && this.flowersNear(k).length && dayIdx - h.breedDay >= Math.max(1, (BREEDS[h.breed] || BREEDS.anadolu).breedDays * (dayIdx < (h.pollenCakeUntilDay || 0) ? 0.5 : 1))) {
        h.bees += 1;
        h.breedDay = dayIdx;
        this.state.counters.born += 1;
        this.events.push({ msg: `${h.name}: yeni bir arı doğdu 🐝` });
      }
    }
    this.save();
  }

  // --- 1) Nero'dan gelen odak ve iş ödülleri ----------------------------------
  focusCompleted(minutes) {
    if (!minutes || minutes < 10) return null;
    const now = Date.now();
    const day = this.todayKey();
    if (!this.state.focusDaily || this.state.focusDaily.day !== day) this.state.focusDaily = { day, earnedMs: 0 };
    const dailyMax = 4 * FOCUS_BOOST_MS;
    const dailyLeft = Math.max(0, dailyMax - this.state.focusDaily.earnedMs);
    if (!dailyLeft) {
      this.events.push({ msg: '🔥 Bugünkü 4 saatlik odak bonusu limitine ulaştın.' });
      this.save();
      return false;
    }
    const requested = FOCUS_BOOST_MS * (minutes / 25) + this.fx('focusExtraMin') * 60000;
    const activeRemaining = Math.max(0, (this.state.focusBoostUntil || 0) - now);
    const activeRoom = Math.max(0, 4 * FOCUS_BOOST_MS - activeRemaining);
    const granted = Math.max(0, Math.min(requested, dailyLeft, activeRoom));
    if (!granted) {
      this.events.push({ msg: '🔥 Odak bonusu şu an 4 saatlik aktif tavanda. Süre azaldığında yeniden ekleyebilirsin.' });
      this.save();
      return false;
    }
    const base = Math.max(now, this.state.focusBoostUntil || 0);
    this.state.focusBoostUntil = base + granted;
    this.state.focusDaily.earnedMs += granted;
    const grantedMin = Math.round(granted / 60000);
    const earnedMin = Math.round(this.state.focusDaily.earnedMs / 60000);
    this.events.push({ msg: `🔥 ${minutes} dakika odaklandın: Arıcılığa ${grantedMin} dk bonus eklendi. Bugün ${earnedMin}/240 dk.` });
    this.save();
    return true;
  }

  todoCompleted() {
    this.state.coins += TODO_REWARD;
    this.events.push({ msg: `✅ Nero'da bir iş bitirdin: +${TODO_REWARD} 🪙` });
    this.save();
  }

  // --- 2) Müdavim köylüler --------------------------------------------------------
  bond(who, extraRelationPoints = 0) {
    const c = this.state.customers[who] || { delivered: 0, hearts: 0 };
    c.delivered += 1 + Math.max(0, Number(extraRelationPoints) || 0) / 10;
    let hearts = Math.min(HEART_MAX, Math.floor(c.delivered / HEART_EVERY));
    if (this.fx('firstHeart') && c.delivered >= 1) hearts = Math.max(1, hearts);
    if (hearts > c.hearts) {
      c.hearts = hearts;
      this.events.push({ msg: `💛 ${who} ile aranız ısınıyor (${hearts}/${HEART_MAX} kalp). Siparişleri artık daha iyi ödüyor.` });
      if (hearts === 2 || hearts === 4) {
        const keys = Object.keys(FLOWERS);
        const f = keys[Math.min(keys.length - 1, 2 + Math.floor(Math.random() * (keys.length - 2)))];
        this.state.vouchers[f] = (this.state.vouchers[f] || 0) + 1;
        this.events.push({ msg: `✉️ ${who} bir teşekkür mektubu ve hediye gönderdi: 1 ${FLOWERS[f].name} tohumu 🎁` });
      }
    }
    this.state.customers[who] = c;
  }

  // --- 3) Dekorlar ----------------------------------------------------------------
  fountainBonus(flowerKey) {
    const [q, r] = parse(flowerKey);
    for (const [dq, dr] of [[0, 0], ...DIRS]) {
      const t = this.state.tiles[key(q + dq, r + dr)];
      if (t && t.decor === 'cesme') return DECOR.cesme.bonus;
    }
    return 0;
  }

  placeDecor(k, id) {
    const t = this.state.tiles[k];
    const d = DECOR[id];
    if (!d || d.prize) return this.fail('Bu dekor satılmıyor.');
    if (!t || !t.owned || t.kind !== 'grass') return this.fail('Dekor sadece adandaki karelere konur.');
    if (t.decor) return this.fail('Bu karede zaten bir dekor var.');
    const cost = this.decorCost(id);
    if (this.state.coins < cost) return this.fail(`Yeterli jeton yok (${cost} gerekli).`);
    this.state.coins -= cost;
    t.decor = id;
    this.save();
    return { ok: true, msg: `${d.name} yerleştirildi (-${cost} 🪙).` };
  }

  removeDecor(k) {
    const t = this.state.tiles[k];
    if (!t || !t.decor) return this.fail('Burada dekor yok.');
    const d = DECOR[t.decor];
    const back = Math.floor((d ? d.cost : 0) / 2);
    this.state.coins += back;
    t.decor = null;
    this.save();
    return { ok: true, msg: `Dekor kaldırıldı (+${back} 🪙).` };
  }

  // --- 4) Mevsim turnuvaları ---------------------------------------------------
  festivalOpen() { return this.dayIndex() % DAYS_PER_SEASON >= FESTIVAL_OPEN_DAY; }

  enterFestival(flower, kg) {
    if (!this.festivalOpen()) return this.fail('Turnuvaya katılım mevsimin son 3 gününde açılır.');
    if (this.state.festival.entry) return this.fail('Bu mevsim zaten katıldın.');
    const have = this.state.storage[flower] || 0;
    const amount = Math.min(FESTIVAL_MAX_KG, Number(kg) || 0, have);
    if (!FLOWERS[flower] || amount < 1) return this.fail('Turnuvaya en az 1 kg bal göndermelisin.');
    this.state.storage[flower] = have - amount;
    if (this.state.storage[flower] < 0.001) delete this.state.storage[flower];
    const fx = this.state.merchantEffects || {};
    const polish = fx.festivalPolish ? 1.05 : 1;
    const insured = !!fx.festivalInsurance;
    fx.festivalPolish = false;
    fx.festivalInsurance = false;
    this.state.festival.entry = { flower, kg: amount, insured, polish, seasonIndex: Math.floor(this.dayIndex() / DAYS_PER_SEASON) };
    this.save();
    return { ok: true, msg: `${SEASON_NAMES[this.calendar().season]} turnuvasına ${amount.toFixed(1)} kg ${FLOWERS[flower].name} balı gönderdin${polish > 1 ? ' · Festival Cilası: Bal Kalitesi +20' : ''}. Sonuç gelecek mevsimde!` };
  }

  judgeFestival(dayIdx) {
    const f = this.state.festival;
    const seasonIndex = Math.floor((dayIdx - 1) / DAYS_PER_SEASON);
    if (f.lastSeasonIndex != null && f.lastSeasonIndex >= seasonIndex) return;
    f.lastSeasonIndex = seasonIndex;
    const year = Math.floor(seasonIndex / 4) + 1;
    const season = SEASONS[seasonIndex % 4];
    const entry = f.entry;
    f.entry = null;
    const seasonOrders = Math.max(0, (this.state.ledger.ordersDone || 0) - (f.seasonStartOrders || 0));
    const seasonDeaths = Math.max(0, (this.state.counters.died || 0) - (f.seasonStartDeaths || 0));
    f.seasonStartOrders = this.state.ledger.ordersDone || 0;
    f.seasonStartDeaths = this.state.counters.died || 0;
    const limit = (n, max) => Math.max(0, Math.min(max, Math.round(n)));
    const seasonDays = (this.state.history || []).filter((x) => x.day >= dayIdx - DAYS_PER_SEASON && x.day < dayIdx);
    const produced = seasonDays.reduce((sum, x) => sum + (x.produced || 0), 0);
    const hives = Object.values(this.state.hives);
    const healthy = hives.filter((h) => !h.sick).length / Math.max(1, hives.length);
    const relations = Object.values(this.state.customers).map((c) => c.hearts || 0);
    const me = entry?.seasonIndex === seasonIndex ? { name: 'Sen', me: true, categories: {
      quality: limit(110 + entry.kg * 15 + FLOWERS[entry.flower].price * 2 + (FLOWERS[entry.flower].seasons.includes(season) ? 45 : 0)
        + (entry.polish > 1 ? 20 : 0) + this.fx('festivalBonus') * 100, 400),
      mastery: limit(60 + healthy * 130 + hives.reduce((sum, h) => sum + (h.bees || 0), 0) * 2.5 - seasonDeaths * 12, 250),
      production: limit(produced * 7 + produced / Math.max(1, hives.length) * 4, 200),
      reputation: limit(seasonOrders * 16 + relations.reduce((sum, x) => sum + x * 5, 0), 150)
    } } : null;
    const rivals = this.state.rivals.map((r) => {
      const farm = r.farm || {};
      const random = rivalRandom(seasonIndex, r.id);
      return { name: RIVALS.find((x) => x.id === r.id).name, categories: {
        quality: limit(90 + (farm.seasonProduction || 0) * 0.7 + (farm.buff || 0) * 100 + random() * 85, 400),
        mastery: limit(65 + (farm.bees || 0) * 2.8 + (farm.syrupDays || 0) * 2 + random() * 55, 250),
        production: limit((farm.seasonProduction || 0) * 1.8 + (farm.hives || 1) * 12 + random() * 50, 200),
        reputation: limit((r.nw || 0) / 70 + random() * 55, 150)
      } };
    });
    const all = [...(me ? [me] : []), ...rivals].map((x) => ({ ...x, score: Object.values(x.categories).reduce((a, b) => a + b, 0) }))
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name, 'tr'));
    const place = me ? all.findIndex((x) => x.me) + 1 : null;
    for (const r of this.state.rivals) if (r.farm) r.farm.seasonProduction = 0;
    f.results = [...(f.results || []), { year, season, place, all }].slice(-40);
    all.forEach((x, i) => {
      if (x.me || i > 2) return;
      const rival = this.state.rivals.find((r) => RIVALS.find((d) => d.id === r.id)?.name === x.name);
      if (rival) rival.cups = { ...(rival.cups || {}), [FESTIVAL_PRIZES[i].cup]: ((rival.cups || {})[FESTIVAL_PRIZES[i].cup] || 0) + 1 };
    });
    if (!me) {
      this.events.push({ msg: `🎪 ${SEASON_NAMES[season]} turnuvası bitti. Bu kez katılmadın; sonuçları Kupalar'da görebilirsin.`, go: { to: 'cups' } });
      return;
    }
    const prize = FESTIVAL_PRIZES[place - 1];
    if (prize) {
      this.state.coins += prize.coins;
      f.cups.push({ year, season, place, cup: prize.cup, flower: entry.flower, score: all.find((x) => x.me).score });
      this.state.counters.earned += prize.coins;
      this.milestone('ilk_kupa', 'İlk festival kupanı kazandın');
      this.events.push({ msg: `🏆 ${SEASON_NAMES[season]} turnuvasında ${place}. oldun! ${prize.cup[0].toUpperCase() + prize.cup.slice(1)} kupa ve +${prize.coins} 🪙`, go: { to: 'cups' } });
    } else {
      let refund = 0;
      if (entry.insured) { refund = Math.round(entry.kg * 0.6 * 10) / 10; this.state.storage[entry.flower] = (this.state.storage[entry.flower] || 0) + refund; }
      this.events.push({ msg: `🎪 ${SEASON_NAMES[season]} turnuvasında ${place}. oldun. Birinci: ${all[0].name}.${refund ? ` Festival Güvencesi ${refund.toFixed(1)} kg balı geri getirdi.` : ' Bir sonraki mevsimde yeniden dene!'}`, err: true, go: { to: 'cups' } });
    }
  }

  changeBreed(hiveId, breed) {
    const h = this.state.hives[hiveId];
    if (!h || !BREEDS[breed]) return this.fail('Geçersiz seçim.');
    if (h.breed === breed) return this.fail('Bu kovan zaten bu ırktan.');
    if (this.state.coins < BREED_CHANGE_COST) return this.fail(`Yeterli jeton yok (${BREED_CHANGE_COST} gerekli).`);
    this.state.coins -= BREED_CHANGE_COST;
    h.breed = breed;
    h.invested += BREED_CHANGE_COST;
    this.questEvent('breedChange', { hiveId, breed });
    this.save();
    return { ok: true, msg: `${h.name} artık ${BREEDS[breed].name} kraliçesiyle.` };
  }

  makeCandle() {
    const fx = this.state.merchantEffects || {};
    const waxNeed = (fx.waxPressUses || 0) > 0 ? 0.3 : CANDLE_WAX;
    if (this.state.wax + 1e-6 < waxNeed) return this.fail(`Mum için ${Math.round(waxNeed * 1000)} g balmumu gerekli (${Math.round(this.state.wax * 1000)} g var).`);
    this.state.wax -= waxNeed;
    if ((fx.waxPressUses || 0) > 0) fx.waxPressUses -= 1;
    this.state.candles += 1;
    this.state.ledger.candlesMade += 1;
    this.questEvent('candleMake');
    this.save();
    return { ok: true, msg: `🕯️ Bir mum yaptın${waxNeed < CANDLE_WAX ? ' · Balmumu Presi kullanıldı' : ''}.` };
  }

  candlePrice() {
    const season = this.calendar().season;
    return Math.round(CANDLE_PRICE * (season === 'kis' ? 1.4 : 1) * (this.state.market.mult.yonca || 1) * (1 + this.fx('candleBonus') + this.storyFx('candle')));
  }

  sellCandles() {
    if (this.state.candles < 1) return this.fail('Satacak mum yok.');
    const fx = this.state.merchantEffects || {};
    const n = this.state.candles;
    const base = this.candlePrice();
    const boosted = Math.min(n, fx.candleMoldUses || 0);
    const gain = Math.round((n - boosted) * base + boosted * base * 1.35);
    fx.candleMoldUses = Math.max(0, (fx.candleMoldUses || 0) - boosted);
    this.state.candles = 0;
    this.state.coins += gain;
    this.state.counters.earned += gain;
    this.questEvent('candleSell', { count: n, gain });
    this.save();
    return { ok: true, msg: `${n} mum satıldı (+${gain} 🪙)${boosted ? ` · ${boosted} mumda Usta Mum Kalıbı bonusu` : ''}.` };
  }

  sendLetter(day) {
    this.state.nextLetterDay = day + LETTER_EVERY[0] + Math.floor(Math.random() * (LETTER_EVERY[1] - LETTER_EVERY[0] + 1));
    const people = this.state.village.arrived.map((n) => VILLAGE[n - 1]).filter((e) => e.type === 'koylu');
    if (!people.length) return;
    const p = people[Math.floor(Math.random() * people.length)];
    const own = LETTERS_BY_NAME[p.name];
    const pool = own && Math.random() < 0.75 ? own : LETTERS_GENERIC;
    const text = pool[Math.floor(Math.random() * pool.length)];
    let gift = null;
    const r = Math.random();
    if (r < 0.2) gift = { coins: 10 + Math.floor(Math.random() * 3) * 10 };
    else if (r < 0.3) gift = { wax: 0.1 };
    else if (r < 0.34) gift = { seed: ['papatya', 'aycicegi', 'kekik'][Math.floor(Math.random() * 3)] };
    const letter = { id: uid(), from: p.name, role: p.role, text, gift, day, read: false, claimed: false };
    this.state.letters = [...this.state.letters, letter].slice(-LETTER_KEEP);
    this.events.push({ msg: `✉️ ${p.name} sana bir mektup gönderdi${gift ? ' (içinde küçük bir hediye var)' : ''}.`, go: { to: 'letters' } });
  }

  readLetter(id) {
    const l = this.state.letters.find((x) => x.id === id);
    if (!l) return this.fail('Mektup bulunamadı.');
    l.read = true;
    let msg = '';
    if (l.gift && !l.claimed) {
      l.claimed = true;
      if (l.gift.coins) { this.state.coins += l.gift.coins; msg = `+${l.gift.coins} 🪙`; }
      if (l.gift.wax) { this.state.wax += l.gift.wax; msg = '+100 g balmumu'; }
      if (l.gift.seed) { this.state.vouchers[l.gift.seed] = (this.state.vouchers[l.gift.seed] || 0) + 1; msg = `1 ${FLOWERS[l.gift.seed].name} tohumu 🎁`; }
    }
    this.save();
    return { ok: true, msg: msg ? `${l.from} hediyesi: ${msg}` : '' };
  }

  claimEzgiWelcome() {
    if (!this.ezgiUnlocked()) return this.fail('Çiçekçi Ezgi henüz kasabaya yerleşmedi.');
    if (this.state.ezgiWelcomeClaimed) return this.fail('Ezgi’nin hoş geldin hediyesini zaten aldın.');
    const flower = this.ezgiChoice() || Object.keys(FLOWERS)[0];
    this.state.vouchers[flower] = (this.state.vouchers[flower] || 0) + 1;
    this.state.ezgiWelcomeClaimed = true;
    this.state.ezgiWelcomePending = false;
    this.save();
    return { ok: true, msg: `🌷 Ezgi’nin hoş geldin hediyesi: 1 ${FLOWERS[flower].name} tohumu 🎁` };
  }

  // --- Oyun ayarları ---------------------------------------------------------------
  setGameSetting(keyName, value) {
    const s = this.state.gameSettings;
    if (keyName === 'graphics' && ['yuksek', 'dengeli', 'hafif'].includes(value)) s.graphics = value;
    else if (['night', 'seasonalAppearance', 'sfx', 'ambient', 'notificationSound'].includes(keyName)) s[keyName] = !!value;
    else if (keyName.startsWith('audio.') && keyName.slice(6) in s.audio) s.audio[keyName.slice(6)] = !!value;
    else if (keyName.startsWith('notify.') && keyName.slice(7) in s.notify) s.notify[keyName.slice(7)] = !!value;
    else return this.fail('Geçersiz ayar.');
    this.save();
    return { ok: true, msg: '' };
  }

  // --- Toplu işlemler ----------------------------------------------------------
  syrupAllCost() { return this.syrupCost() * Object.keys(this.state.hives).length; }

  giveSyrupAll() {
    const hives = Object.values(this.state.hives);
    const cost = this.syrupAllCost();
    if (this.state.coins < cost) return this.fail(`Yeterli jeton yok (${cost} gerekli).`);
    this.state.coins -= cost;
    for (const h of hives) { h.syrup += SYRUP_KG; this.state.ledger.syrupGiven += 1; }
    this.save();
    return { ok: true, msg: `${hives.length} kovana şurup verildi: +${SYRUP_KG} kg kış erzakı (-${cost} 🪙).` };
  }

  winterHungryHives() {
    const firstWinterDay = (Math.floor(this.dayIndex() / (DAYS_PER_SEASON * 4)) * 4 + 3) * DAYS_PER_SEASON;
    return Object.values(this.state.hives).filter((h) => h.syrup < this.winterFeedNeed(h, firstWinterDay));
  }

  giveWinterSyrup() {
    const hungry = this.winterHungryHives();
    if (!hungry.length) return this.fail('Kışın ilk günü için erzağı eksik kovan yok.');
    const cost = hungry.length * this.syrupCost();
    if (this.state.coins < cost) return this.fail(`Jeton yetersiz: ${cost} 🪙 gerekli. Hiçbir kovana şurup verilmedi.`);
    this.state.coins -= cost;
    for (const h of hungry) { h.syrup += SYRUP_KG; this.state.ledger.syrupGiven += 1; }
    this.save();
    return { ok: true, msg: `${hungry.length} kovana şurup verildi (-${cost} 🪙).` };
  }

  // Kabul edilmiş ve depodan hemen karşılanabilen siparişlerin hepsini teslim et
  deliverReady() {
    const ready = this.state.orders.list.filter((o) => o.status === 'accepted');
    let n = 0;
    let gain = 0;
    for (const o of ready) {
      const before = this.state.coins;
      const r = this.deliverOrder(o.id);
      if (r.ok) { n += 1; gain += this.state.coins - before; }
    }
    if (!n) return this.fail('Depodan hemen teslim edilebilecek kabul edilmiş sipariş yok.');
    return { ok: true, msg: `${n} sipariş teslim edildi (+${gain} 🪙).` };
  }

  // --- Nero'dan durum ipuçları --------------------------------------------------------
  hints() {
    const out = [];
    const used = Object.values(this.state.storage).reduce((a, b) => a + b, 0);
    if (used >= this.state.storageCap * 0.9) out.push({ id: 'storage', text: `Depo %${Math.round((used / this.state.storageCap) * 100)} dolu. Satmazsan arıcı hasat edemeyecek.`, go: { to: 'market' } });
    for (const h of Object.values(this.state.hives)) {
      const k = this.hiveTileKey(h.id);
      if (k && !this.flowersNear(k).length) out.push({ id: `nof:${h.id}`, text: `Yanında hiç çiçek olmayan bir kovan var: ${h.name}. Bal üretmiyor.`, go: { to: 'hive', id: h.id } });
    }
    const ready = this.state.orders.list.filter((o) => (this.state.storage[o.flower] || 0) + 1e-6 >= o.kg).length;
    if (ready) out.push({ id: `ready:${ready}`, text: `${ready} siparişin depodan hemen karşılanabilir.`, go: { to: 'orders' } });
    const wilted = Object.values(this.state.tiles).filter((t) => t.item && t.item.type === 'flower' && t.item.wilted).length;
    if (wilted) out.push({ id: `wilt:${wilted}`, text: `${wilted} tarh soldu. Tohumun %10'una canlandırabilirsin.` });
    if (this.calendar().season === 'sonbahar' && this.calendar().day >= 12 && Object.values(this.state.hives).some((h) => h.syrup < 1)) {
      out.push({ id: 'prewinter', text: 'Kış yaklaşıyor ve bazı kovanlarda erzak yok. Toplu şurup verebilirsin.', go: { to: 'hives' } });
    }
    return out;
  }

  // --- Gezgin satıcı: Seyyah Yakup ---------------------------------------------
  merchantDay(day) {
    const m = this.state.merchant;
    if (m.active && day >= m.until) {
      m.active = false;
      m.stock = [];
      m.nextDay = day + MERCHANT_EVERY[0] + Math.floor(Math.random() * (MERCHANT_EVERY[1] - MERCHANT_EVERY[0] + 1));
      this.events.push({ msg: '🛒 Seyyah Yakup köyden ayrıldı. Bir sonraki ziyaretini bekle.' });
      return;
    }
    if (m.active && day === m.until - 1) this.events.push({ msg: '🛒 Seyyah Yakup yarın gidiyor! Almak istediğin bir şey varsa acele et.' });
    if (!m.active && day >= m.nextDay) this.merchantArrive(day);
  }

  makeMerchantStock(id) {
    const item = { id, sold: false };
    const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
    if (id === 'tohum') {
      const pool = ['papatya', 'aycicegi', 'kekik', 'lavanta'];
      item.seeds = [pick(pool), pick(pool), pick(pool)];
    }
    if (id === 'nadirTohum') item.seeds = [pick(['lavanta', 'kisfundasi', 'kestane']), pick(['kekik', 'lavanta', 'kisfundasi'])];
    if (id === 'mevsimTohum') {
      const season = this.calendar().season;
      const pool = Object.keys(FLOWERS).filter((x) => FLOWERS[x].seasons.includes(season));
      if (!pool.length) return null;
      item.seeds = [pick(pool), pick(pool), pick(pool)];
    }
    return item;
  }

  merchantArrive(day) {
    const m = this.state.merchant;
    let pool = Object.keys(MERCHANT_ITEMS).filter((k) => k !== 'sandik' || (m.sandik || 0) < 3);
    if (!Object.keys(FLOWERS).some((x) => FLOWERS[x].seasons.includes(this.calendar().season))) pool = pool.filter((x) => x !== 'mevsimTohum');
    const stock = [];
    while (stock.length < 4 && pool.length) {
      const id = pool.splice(Math.floor(Math.random() * pool.length), 1)[0];
      const made = this.makeMerchantStock(id);
      if (made) stock.push(made);
    }
    const planted = this.plantedFlowers();
    const wants = (planted.length ? planted : Object.keys(FLOWERS))[Math.floor(Math.random() * (planted.length || Object.keys(FLOWERS).length))];
    const used = new Set(Object.values(this.state.village.slots));
    const free = this.ringKeys(ISLAND_RADIUS + 1).filter((k) => !used.has(k));
    Object.assign(m, {
      active: true, arrivedDay: day, until: day + MERCHANT_STAY, stock, bought: [], salesTicketKg: 0,
      wants, wantsLeft: 10, slot: free.length ? free[Math.floor(Math.random() * free.length)] : null
    });
    this.events.push({ msg: `🛒 Gezgin satıcı Seyyah Yakup köye geldi! 2 gün kalacak. ${FLOWERS[wants].name} balı da arıyor.` });
  }

  merchantPrice(id, target, stockItem = null) {
    const item = stockItem || (this.state.merchant && this.state.merchant.stock || []).find((x) => x.id === id);
    const h = target && this.state.hives[target];
    const t = target && this.state.tiles[target];
    const ord = target && this.findOrder(target);
    const fx = this.state.merchantEffects || {};
    switch (id) {
      case 'surup': return 110;
      case 'kralice': { const u = h && this.nextUpgrade(h); return u && u.type === 'queen' ? Math.round(u.cost * 0.7) : null; }
      case 'tohum': return item && item.seeds ? Math.round(item.seeds.reduce((n, x) => n + this.seedCost(x), 0) * 0.5) : null;
      case 'dortMevsim': return t && t.item && t.item.type === 'flower' && !t.item.wilted ? this.seedCost(t.item.flower) * 2 : null;
      case 'suru': { if (!h || h.capBees - h.bees < 3) return null; let n = 0; for (let i = 1; i <= 3; i++) n += this.beeNumberPrice(h.bees + i); return Math.round(n * 0.7); }
      case 'sut': return h ? 150 : null;
      case 'kit': return h && h.sick ? 55 : null;
      case 'sandik': return (this.state.merchant.sandik || 0) < 3 ? 120 : null;
      case 'mum': return 70;
      case 'kislikSurup': return h ? 105 : null;
      case 'propolis': return h ? 70 : null;
      case 'vitamin': return h ? 110 : null;
      case 'yalitim': return h ? 35 : null;
      case 'irkKupon': { const [hid, breed] = String(target || '').split('|'); const hh = this.state.hives[hid]; return hh && BREEDS[breed] && hh.breed !== breed ? 110 : null; }
      case 'nakil': return target && String(target).includes('|') ? 60 : null;
      case 'polenKeki': return h ? 90 : null;
      case 'acilKis': return h && !h.winterShield ? 45 : null;
      case 'cicekBesini': return t && t.item && t.item.type === 'flower' && !t.item.wilted ? 140 : null;
      case 'omurGubre': return t && t.item && t.item.type === 'flower' && !t.item.wilted ? Math.min(130, Math.max(30, Math.round(this.seedCost(t.item.flower) * 0.08))) : null;
      case 'yenidenEkim': return t && t.item && t.item.type === 'flower' && t.item.wilted ? 60 : null;
      case 'nadirTohum': return 900;
      case 'mevsimTohum': return item && item.seeds ? Math.round(item.seeds.reduce((n, x) => n + this.seedCost(x), 0) * 0.6) : null;
      case 'polenKarisim': return h ? 120 : null;
      case 'eldiven': return 80;
      case 'balmumuPresi': return 55;
      case 'mumKalibi': return 60;
      case 'depoKupon': { const u = this.nextStorage(); return u && !fx.storageCoupon ? Math.round(u.cost * 0.10) : null; }
      case 'pazarMuhru': return 75;
      case 'fiyatSabitle': return FLOWERS[target] ? 60 : null;
      case 'pazarTahmin': return 25;
      case 'siparisKum': return ord && ord.status === 'accepted' ? 35 : null;
      case 'siparisMuhru': return ord && !ord.merchantPayBonus ? Math.max(20, Math.round(ord.reward * 0.06)) : null;
      case 'dostlukJeton': return fx.friendToken ? null : 90;
      case 'oncelikKart': return fx.priorityCard ? null : 35;
      case 'festivalCila': return fx.festivalPolish || fx.festivalPolishSeason === Math.floor(this.dayIndex() / DAYS_PER_SEASON) ? null : 180;
      case 'festivalGuvence': return fx.festivalInsurance || fx.festivalInsuranceSeason === Math.floor(this.dayIndex() / DAYS_PER_SEASON) ? null : 100;
      case 'seyyahFis': return this.state.merchant.salesTicketKg > 0 ? null : 40;
      case 'stokDegisim': return target ? 45 : null;
      default: return null;
    }
  }

  merchantQuote(id, target) {
    const m = this.state.merchant;
    if (!m || !m.active) return this.fail('Satıcı şu an köyde değil.');
    const item = m.stock.find((x) => x.id === id);
    if (!item || item.sold) return this.fail('Bu ürün kalmadı.');
    const price = this.merchantPrice(id, target, item);
    if (price == null) return { ok: false, price: null, msg: 'Bu ürün şu an uygulanamaz.' };
    return { ok: true, price, msg: '' };
  }

  merchantBuy(id, target) {
    const m = this.state.merchant;
    if (!m.active) return this.fail('Satıcı şu an köyde değil.');
    const item = m.stock.find((x) => x.id === id);
    if (!item || item.sold) return this.fail('Bu ürün kalmadı.');
    if (id !== 'stokDegisim' && m.bought.length >= MERCHANT_MAX_BUY) return this.fail(`Bu ziyarette en fazla ${MERCHANT_MAX_BUY} farklı ürün alabilirsin.`);
    const def = MERCHANT_ITEMS[id];
    const h = target && this.state.hives[target];
    const t = target && this.state.tiles[target];
    const ord = target && this.findOrder(target);
    if (def.target && def.target.startsWith('hive') && !['hiveTransfer', 'hiveBreed'].includes(def.target) && !h) return this.fail('Önce uygun bir kovan seç.');
    if (def.target === 'hiveQueen' && !(this.nextUpgrade(h) && this.nextUpgrade(h).type === 'queen')) return this.fail('Bu kovanın sıradaki yükseltmesi kraliçe değil.');
    if (def.target === 'hiveRoom3' && (!h || h.capBees - h.bees < 3)) return this.fail('Bu kovanda 3 arı için yer yok.');
    if (def.target === 'hiveSick' && (!h || !h.sick)) return this.fail('Bu kovan hasta değil.');
    if (def.target === 'flower' && (!t || !t.item || t.item.type !== 'flower' || t.item.wilted)) return this.fail('Önce sağlıklı bir tarh seç.');
    if (def.target === 'flowerWilted' && (!t || !t.item || t.item.type !== 'flower' || !t.item.wilted)) return this.fail('Önce solmuş bir tarh seç.');
    if (def.target === 'honey' && !FLOWERS[target]) return this.fail('Bir bal türü seç.');
    if (def.target === 'acceptedOrder' && (!ord || ord.status !== 'accepted')) return this.fail('Kabul edilmiş bir sipariş seç.');
    if (def.target === 'order' && !ord) return this.fail('Bir sipariş seç.');
    let transfer = null;
    if (def.target === 'hiveTransfer') {
      const [fromId, toId] = String(target || '').split('|'); const from = this.state.hives[fromId], to = this.state.hives[toId];
      if (!from || !to || from === to || from.bees <= 1 || to.bees >= to.capBees) return this.fail('Arı taşımak için iki uygun kovan seç.');
      transfer = { from, to };
    }
    if (def.target === 'merchantStock') {
      const targetItem = m.stock.find((x) => x.id === target && !x.sold && x.id !== 'stokDegisim');
      if (!targetItem) return this.fail('Değiştirilecek uygun bir teklif seç.');
    }
    const price = this.merchantPrice(id, target, item);
    if (price == null) return this.fail('Bu ürün şu an uygulanamaz.');
    if (this.state.coins < price) return this.fail(`Yeterli jeton yok (${price} gerekli).`);
    this.state.coins -= price;
    item.sold = true;
    if (id !== 'stokDegisim') m.bought.push(id);
    const day = this.dayIndex();
    const fx = this.state.merchantEffects;
    let msg = '';
    if (id === 'surup') { h.boostUntilDay = Math.max(day, h.boostUntilDay || 0) + 1; msg = `${h.name}’e uygulandı · +%50 üretim · 1 gün.`; }
    if (id === 'kralice') { const u = this.nextUpgrade(h); h.level += 1; h.queens += 1; h.capBees = u.capBees; h.invested += price; msg = `${QUEEN_NAMES[h.queens]} geldi! (${h.name})`; }
    if (id === 'tohum' || id === 'nadirTohum' || id === 'mevsimTohum') { for (const seed of item.seeds || []) this.state.vouchers[seed] = (this.state.vouchers[seed] || 0) + 1; msg = `Hediye tohumlar: ${(item.seeds || []).map((x) => FLOWERS[x].name).join(', ')}.`; }
    if (id === 'dortMevsim') { t.item.allSeasonUntil = Math.max(day, t.item.allSeasonUntil || 0) + 30; msg = 'Tarhın Dört Mevsim etkisi 30 gün uzadı.'; }
    if (id === 'suru') { h.bees += 3; msg = `${h.name}: +3 arı.`; }
    if (id === 'sut') { h.milkDays = (h.milkDays || 0) + 3; msg = `${h.name}: Arı Sütü etkisi +3 gün.`; }
    if (id === 'kit') { this.recoverHive(h, day, false); this.state.ledger.cured += 1; this.questEvent('cure'); msg = `${h.name} iyileşti ve 1 oyun yılı bağışık oldu.`; }
    if (id === 'sandik') { m.sandik = (m.sandik || 0) + 1; this.state.storageCap = this.state.storageBaseCap + m.sandik * 10; msg = 'Depo kalıcı olarak +10 kg büyüdü.'; }
    if (id === 'mum') { this.state.wax += 1; msg = '+1 kg balmumu.'; }
    if (id === 'kislikSurup') { h.syrup += 45; msg = `${h.name}: +45 kg kış erzakı.`; }
    if (id === 'propolis') { h.propolisUntilDay = Math.max(day, h.propolisUntilDay || 0) + 10; msg = `${h.name}: Propolis Kalkanı 10 gün uzadı.`; }
    if (id === 'vitamin') { h.vitaminUntilDay = Math.max(day, h.vitaminUntilDay || 0) + 5; msg = `${h.name}: +%15 üretim etkisi 5 gün uzadı.`; }
    if (id === 'yalitim') { const year = DAYS_PER_SEASON * 4, pos = ((day % year) + year) % year, base = day - pos; let winterStart = base + DAYS_PER_SEASON * 3; if (day >= winterStart) winterStart += year; h.insulationFromDay = winterStart; h.insulationUntilDay = winterStart + DAYS_PER_SEASON; msg = `${h.name}: sıradaki kışta şurup tüketimi yarıya inecek.`; }
    if (id === 'irkKupon') { const [hid, breed] = String(target).split('|'); const hh = this.state.hives[hid]; hh.breed = breed; hh.invested += price; this.questEvent('breedChange', { hiveId: hid, breed }); msg = `${hh.name} artık ${BREEDS[breed].name} kraliçesiyle.`; }
    if (id === 'nakil') { const move = Math.min(3, transfer.from.bees - 1, transfer.to.capBees - transfer.to.bees); transfer.from.bees -= move; transfer.to.bees += move; msg = `${transfer.from.name} → ${transfer.to.name}: ${move} arı taşındı.`; }
    if (id === 'polenKeki') { h.pollenCakeUntilDay = Math.max(day, h.pollenCakeUntilDay || 0) + 5; msg = `${h.name}: doğal üreme desteği 5 gün uzadı.`; }
    if (id === 'acilKis') { h.winterShield = 1; msg = `${h.name}: bir sonraki şurupsuz kış kaybı engellenecek.`; }
    if (id === 'cicekBesini') { t.item.feedUntilDay = Math.max(day, t.item.feedUntilDay || 0) + 5; msg = `${FLOWERS[t.item.flower].name} tarhı 5 gün +%25 üretim aldı.`; }
    if (id === 'omurGubre') { t.item.plantedDay = (t.item.plantedDay || day) + 10; msg = `${FLOWERS[t.item.flower].name} tarhının ömrü 10 gün uzadı.`; }
    if (id === 'yenidenEkim') { t.item.plantedDay = day; t.item.wilted = false; this.questEvent('revive', { flower: t.item.flower }); msg = `${FLOWERS[t.item.flower].name} tarhı ücretsiz canlandı.`; }
    if (id === 'polenKarisim') { h.pollenMixUntilDay = Math.max(day, h.pollenMixUntilDay || 0) + 5; msg = `${h.name}: çiçek bonusları 5 gün güçlendi.`; }
    if (id === 'eldiven') { fx.waxGloveHarvests = (fx.waxGloveHarvests || 0) + 3; msg = 'Sonraki 3 başarılı hasatta balmumu +%50.'; }
    if (id === 'balmumuPresi') { fx.waxPressUses = (fx.waxPressUses || 0) + 5; msg = 'Sonraki 5 mum yalnız 300 g balmumu kullanacak.'; }
    if (id === 'mumKalibi') { fx.candleMoldUses = (fx.candleMoldUses || 0) + 5; msg = 'Sonraki 5 mum satışı +%35 değerli.'; }
    if (id === 'depoKupon') { fx.storageCoupon = true; msg = 'Bir sonraki depo yükseltmesi %20 indirimli.'; }
    if (id === 'pazarMuhru') { fx.marketSealKg = 10; msg = 'Bir sonraki pazar satışında en fazla 10 kg için +%15 fiyat aktif.'; }
    if (id === 'fiyatSabitle') { const current = this.price(target); const old = this.state.marketLocks[target]; this.state.marketLocks[target] = { price: current, untilDay: Math.max(day, old && old.untilDay || 0) + 1 }; msg = `${FLOWERS[target].name} balı fiyatı 1 gün sabitlendi.`; }
    if (id === 'pazarTahmin') {
      const nextMult = {}; for (const [flower, cur] of Object.entries(this.state.market.mult)) { const drift = (Math.random() - 0.5) * 0.18; const pull = (1.05 - cur) * 0.15; nextMult[flower] = Math.min(1.3, Math.max(0.8, cur + drift + pull)); }
      const choices = (this.plantedFlowers().length ? this.plantedFlowers() : Object.keys(FLOWERS)).slice(); const reveal = []; while (reveal.length < Math.min(3, choices.length)) reveal.push(choices.splice(Math.floor(Math.random() * choices.length), 1)[0]);
      fx.marketForecast = { forDay: day + 1, nextMult, reveal };
      msg = reveal.map((x) => `${FLOWERS[x].name} ${nextMult[x] >= this.state.market.mult[x] ? '↑' : '↓'}`).join(' · ');
    }
    if (id === 'siparisKum') { ord.deadline += DAY_GAME_MS; msg = `${ord.who} siparişine +1 oyun günü eklendi.`; }
    if (id === 'siparisMuhru') { ord.merchantPayBonus = 0.12; msg = `${ord.who} siparişine +%12 ödeme mührü uygulandı.`; }
    if (id === 'dostlukJeton') { fx.friendToken = 10; msg = 'Bir sonraki başarılı köylü siparişine +10 ilişki puanı.'; }
    if (id === 'oncelikKart') { fx.priorityCard = 4; msg = 'Bir sonraki başarılı köylü siparişine +4 ilişki puanı.'; }
    if (id === 'festivalCila') { fx.festivalPolish = true; fx.festivalPolishSeason = Math.floor(this.dayIndex() / DAYS_PER_SEASON); msg = 'Bir sonraki turnuva katılımına Bal Kalitesi puanı desteği hazır.'; }
    if (id === 'festivalGuvence') { fx.festivalInsurance = true; fx.festivalInsuranceSeason = Math.floor(this.dayIndex() / DAYS_PER_SEASON); msg = 'Bir sonraki turnuvada kupa olmazsa balın %60’ı geri dönecek.'; }
    if (id === 'seyyahFis') { m.salesTicketKg = 10; msg = 'Bu ziyarette Yakup’a satılan en fazla 10 kg bala ek +%10 ödeme aktif.'; }
    if (id === 'stokDegisim') {
      const idx = m.stock.findIndex((x) => x.id === target);
      const currentIds = new Set(m.stock.map((x) => x.id));
      let pool = Object.keys(MERCHANT_ITEMS).filter((x) => !currentIds.has(x) && (x !== 'sandik' || (m.sandik || 0) < 3));
      if (!Object.keys(FLOWERS).some((x) => FLOWERS[x].seasons.includes(this.calendar().season))) pool = pool.filter((x) => x !== 'mevsimTohum');
      if (!pool.length) return this.fail('Yeni stok seçeneği bulunamadı.');
      const freshId = pool[Math.floor(Math.random() * pool.length)], fresh = this.makeMerchantStock(freshId);
      m.stock[idx] = fresh; msg = `${MERCHANT_ITEMS[target].name} yerine ${MERCHANT_ITEMS[freshId].name} geldi.`;
    }
    this.questEvent('merchantBuy', { id });
    this.save();
    return { ok: true, msg: `🛒 ${def.name} alındı (-${price} 🪙). ${msg}` };
  }

  merchantSell(kg) {
    const m = this.state.merchant;
    if (!m.active) return this.fail('Satıcı şu an köyde değil.');
    const f = m.wants;
    const have = this.state.storage[f] || 0;
    const amount = Math.min(m.wantsLeft, have, kg === 'all' ? Infinity : Number(kg) || 0);
    if (amount < 0.05) return this.fail(`Depoda ${FLOWERS[f].name} balı yok ya da satıcı yeterince aldı.`);
    const unit = this.price(f) * 1.4;
    const ticketKg = Math.min(amount, m.salesTicketKg || 0);
    const gain = Math.round(amount * unit + ticketKg * unit * 0.10);
    this.state.storage[f] = have - amount;
    if (this.state.storage[f] < 0.001) delete this.state.storage[f];
    m.wantsLeft -= amount;
    m.salesTicketKg = Math.max(0, (m.salesTicketKg || 0) - ticketKg);
    this.state.coins += gain;
    this.state.counters.earned += gain;
    const L = this.ledgerHoney(f); L.soldKg += amount; L.earned += gain;
    this.countSold(f, amount);
    this.questEvent('merchantSell', { kg: amount, flower: f, gain });
    this.save();
    return { ok: true, msg: `Seyyah Yakup ${amount.toFixed(1)} kg ${FLOWERS[f].name} balını aldı (+${gain} 🪙).` };
  }

  merchantView() {
    const m = this.state.merchant;
    if (!m.active) return { active: false };
    return {
      active: true, slot: m.slot, leftMs: Math.max(0, m.until * DAY_GAME_MS - this.state.gameMs), maxBuy: MERCHANT_MAX_BUY, bought: m.bought.length,
      wants: m.wants, wantsLeft: Math.round(m.wantsLeft * 10) / 10, wantsPrice: Math.round(this.price(m.wants) * 1.4 * 10) / 10, salesTicketKg: Math.max(0, m.salesTicketKg || 0),
      stock: m.stock.map((x) => ({ ...x, ...MERCHANT_ITEMS[x.id], contents: (x.seeds || []).map((z) => FLOWERS[z].name), basePrice: this.merchantPrice(x.id, null, x) }))
    };
  }
  // --- Köylü hikâyeleri --------------------------------------------------------------
  storyFx(key) {
    let v = 0;
    for (const s of STORIES) if (s.bonus === key && this.state.stories[s.id] && this.state.stories[s.id].done) v += s.value;
    return v;
  }

  // Adımın ölçtüğü şeyin şu anki değeri (baz alınarak ilerleme hesaplanır)
  storyMetric(step, who) {
    const L = this.state.ledger;
    switch (step.t) {
      case 'maxBees': return Math.max(0, ...Object.values(this.state.hives).map((h) => h.bees));
      case 'harvestKg': return (L.honey[step.f] || {}).kg || 0;
      case 'festivalCup': return (this.state.festival.cups || []).length;
      case 'deliverKg': return L.deliveredKgBy[step.f] || 0;
      case 'deliverOrders': return L.deliveredOrdersBy[step.f] || 0;
      case 'candles': return L.candlesMade || 0;
      case 'orders': return L.ordersDone || 0;
      case 'quests': return this.state.questsDone || 0;
      case 'syrup': return L.syrupGiven || 0;
      case 'cured': return L.cured || 0;
      case 'cleanWinter': return L.cleanWinters || 0;
      case 'muhtarlik': return L.muhtarlikDone || 0;
      case 'deliverTo': return L.deliveredTo[who] || 0;
      default: return 0;
    }
  }

  // Durum adımları (baz gerekmez)
  storyState(step, who) {
    switch (step.t) {
      case 'nearWater': return Object.values(this.state.tiles).some((t) => t.owned && t.item && t.item.type === 'flower' && DIRS.some(([dq, dr]) => { const n = this.state.tiles[key(t.q + dq, t.r + dr)]; return n && n.kind === 'water'; })) ? 1 : 0;
      case 'planted': return this.plantedFlowers().includes(step.f) ? 1 : 0;
      case 'hiveNamed': return Object.values(this.state.hives).some((h) => !/^Kovan \d+$/.test(h.name)) ? 1 : 0;
      case 'pages': return Object.values(this.state.ledger.honey).filter((x) => x.first).length;
      case 'label': return this.state.label ? 1 : 0;
      case 'soldTypes': return Object.values(this.state.ledger.honey).filter((x) => x.soldKg > 0).length;
      case 'village': return this.state.village.arrived.length;
      case 'friends': return Object.keys(this.state.customers).filter((n) => this.relation(n) >= 50).length;
      case 'relation': return this.relation(who);
      case 'maxBees': return this.storyMetric(step, who);
      default: return null;
    }
  }

  storyProgress(s, st) {
    const step = s.steps[st.step];
    const stateVal = this.storyState(step, s.who);
    if (stateVal !== null) return Math.min(step.n, stateVal);
    return Math.min(step.n, this.storyMetric(step, s.who) - (st.base || 0));
  }

  checkStories() {
    const arrivedNames = new Set(this.villagePeople().map((p) => p.name));
    for (const s of STORIES) {
      let st = this.state.stories[s.id];
      if (!st) {
        if (!arrivedNames.has(s.who) || this.relation(s.who) < 50) continue;
        st = this.state.stories[s.id] = { step: 0, base: this.storyMetric(s.steps[0], s.who), done: false };
        this.events.push({ msg: `📖 ${s.who} sana bir hikâye anlatmak istiyor: "${s.title}". İlk adım: ${s.steps[0].text}.` });
      }
      if (st.done) continue;
      if (this.storyProgress(s, st) < s.steps[st.step].n) continue;
      // Adım tamam: ödül
      const last = st.step === s.steps.length - 1;
      if (last) {
        st.done = true;
        this.state.coins += 150;
        this.events.push({ msg: `🌟 "${s.title}" hikâyesi tamamlandı! ${s.who}: +150 🪙 ve kalıcı ödül: ${s.bonusText}.` });
        this.state.milestones[`hikaye_${s.id}`] = Date.now(); // rozetlere bağlanabilsin diye sessiz kayıt
      } else {
        if (st.step === 0) { this.state.coins += 60; this.events.push({ msg: `📖 ${s.who}: "${s.steps[0].text}" tamam! +60 🪙. Sıradaki: ${s.steps[1].text}.` }); }
        else {
          const f = ['papatya', 'aycicegi', 'kekik'][Math.floor(Math.random() * 3)];
          this.state.vouchers[f] = (this.state.vouchers[f] || 0) + 1;
          this.state.coins += 80;
          this.events.push({ msg: `📖 ${s.who}: "${s.steps[1].text}" tamam! +80 🪙 ve 1 ${FLOWERS[f].name} tohumu. Son adım: ${s.steps[2].text}.` });
        }
        st.step += 1;
        st.base = this.storyMetric(s.steps[st.step], s.who);
      }
    }
  }

  storiesView() {
    return STORIES.map((s) => {
      const st = this.state.stories[s.id];
      return {
        id: s.id, who: s.who, title: s.title, bonusText: s.bonusText,
        unlocked: !!st, done: !!(st && st.done),
        step: st ? Math.min(st.step, s.steps.length - 1) : 0,
        progress: st && !st.done ? this.storyProgress(s, st) : 0,
        steps: s.steps.map((x) => ({ text: x.text, n: x.n }))
      };
    });
  }

  effectsView() {
    const day = this.dayIndex();
    const effects = [];
    const cal = this.calendar();
    if ((this.state.festival.cups || []).some((cup) => cup.cup === 'altın' && cup.season === cal.season && cup.year === cal.year - 1))
      effects.push({ id: 'competition:champion', icon: 'season', title: '+%20 bal üretimi',
        source: `Geçen yılın ${cal.seasonName} şampiyonluğu`, daysLeft: DAYS_PER_SEASON - cal.day + 1 });
    const fx = this.state.merchantEffects || {};
    for (const s of STORIES) {
      const st = this.state.stories[s.id];
      if (st && st.done) effects.push({ id: `story:${s.id}`, icon: 'story', title: s.bonusText, source: `${s.who} · ${s.title}`, permanent: true });
    }
    for (const n of this.state.village.arrived) {
      const e = VILLAGE[n - 1];
      if (e.effect && e.effectText) effects.push({ id: `village:${e.n}`, icon: 'building', title: e.effectText, source: e.name, permanent: true });
    }
    for (const h of Object.values(this.state.hives)) {
      if (day < (h.boostUntilDay || 0)) effects.push({ id: `syrup:${h.id}`, icon: 'syrup', title: '+%50 bal üretimi', source: `${h.name} · Ballı Şurup`, daysLeft: h.boostUntilDay - day });
      if ((h.milkDays || 0) > 0) effects.push({ id: `milk:${h.id}`, icon: 'milk', title: 'Her gün +1 arı', source: `${h.name} · Arı Sütü`, daysLeft: h.milkDays });
      if (day < (h.propolisUntilDay || 0)) effects.push({ id: `propolis:${h.id}`, icon: 'immunity', title: 'Hastalanma ihtimali %50 az', source: `${h.name} · Propolis Kalkanı`, daysLeft: h.propolisUntilDay - day });
      if (day < (h.vitaminUntilDay || 0)) effects.push({ id: `vitamin:${h.id}`, icon: 'syrup', title: '+%15 bal üretimi', source: `${h.name} · Arı Vitamini`, daysLeft: h.vitaminUntilDay - day });
      if (day < (h.pollenCakeUntilDay || 0)) effects.push({ id: `cake:${h.id}`, icon: 'milk', title: 'Doğal üreme daha hızlı', source: `${h.name} · Polen Keki`, daysLeft: h.pollenCakeUntilDay - day });
      if (day < (h.pollenMixUntilDay || 0)) effects.push({ id: `mix:${h.id}`, icon: 'story', title: 'Çiçek bonusları %25 güçlü', source: `${h.name} · Özel Polen Karışımı`, daysLeft: h.pollenMixUntilDay - day });
      if (h.winterShield) effects.push({ id: `winter:${h.id}`, icon: 'immunity', title: '1 kış arı kaybı engellenir', source: `${h.name} · Acil Kış Paketi`, permanent: true });
      if ((h.insulationUntilDay || 0) > day) effects.push({ id: `insulation:${h.id}`, icon: 'story', title: 'Kış şurup tüketimi %50 az', source: `${h.name} · Kovan Yalıtımı`, daysLeft: Math.max(1, h.insulationUntilDay - Math.max(day, h.insulationFromDay || day)) });
      if (!h.sick && day < (h.immuneUntil || 0)) effects.push({ id: `immune:${h.id}`, icon: 'immunity', title: 'Hastalığa karşı bağışık', source: h.name, daysLeft: h.immuneUntil - day });
    }
    for (const [k, t] of Object.entries(this.state.tiles)) {
      if (t.item && t.item.type === 'flower' && day < (t.item.allSeasonUntil || 0)) effects.push({ id: `season:${k}`, icon: 'season', title: 'Mevsim dışı üretim cezası yok', source: `${FLOWERS[t.item.flower].name} tarhı · Dört Mevsim`, daysLeft: t.item.allSeasonUntil - day });
      if (t.item && t.item.type === 'flower' && day < (t.item.feedUntilDay || 0)) effects.push({ id: `feed:${k}`, icon: 'story', title: '+%25 tarh üretimi', source: `${FLOWERS[t.item.flower].name} tarhı · Çiçek Besini`, daysLeft: t.item.feedUntilDay - day });
    }
    const crates = (this.state.merchant && this.state.merchant.sandik) || 0;
    if (crates) effects.push({ id: 'storage:crates', icon: 'storage', title: `+${crates * 10} kg depo kapasitesi`, source: `Seyyah Yakup · ${crates} depo sandığı`, permanent: true });
    if (fx.storageCoupon) effects.push({ id: 'yakup:storage', icon: 'storage', title: 'Sonraki depo yükseltmesi %20 ucuz', source: 'Seyyah Yakup · Depo Yükseltme Kuponu', permanent: true });
    if (fx.marketSealKg > 0) effects.push({ id: 'yakup:market', icon: 'story', title: `Kalan ${Math.round(fx.marketSealKg * 10) / 10} kg satışta +%15`, source: 'Seyyah Yakup · Pazar Mührü', permanent: true });
    if (fx.waxGloveHarvests > 0) effects.push({ id: 'yakup:glove', icon: 'story', title: `Sonraki ${fx.waxGloveHarvests} hasatta balmumu +%50`, source: 'Seyyah Yakup · Arıcı Eldiveni', permanent: true });
    if (fx.waxPressUses > 0) effects.push({ id: 'yakup:press', icon: 'story', title: `Sonraki ${fx.waxPressUses} mum 300 g balmumu`, source: 'Seyyah Yakup · Balmumu Presi', permanent: true });
    if (fx.candleMoldUses > 0) effects.push({ id: 'yakup:mold', icon: 'story', title: `Sonraki ${fx.candleMoldUses} mum satışında +%35`, source: 'Seyyah Yakup · Usta Mum Kalıbı', permanent: true });
    if (fx.friendToken) effects.push({ id: 'yakup:friend', icon: 'story', title: '+10 ilişki puanı bekliyor', source: 'Seyyah Yakup · Dostluk Jetonu', permanent: true });
    if (fx.priorityCard) effects.push({ id: 'yakup:priority', icon: 'story', title: '+4 ilişki puanı bekliyor', source: 'Seyyah Yakup · Öncelikli Teslim Kartı', permanent: true });
    if (fx.festivalPolish) effects.push({ id: 'yakup:polish', icon: 'story', title: 'Sonraki turnuvada Bal Kalitesi +20', source: 'Seyyah Yakup · Festival Cilası', permanent: true });
    if (fx.festivalInsurance) effects.push({ id: 'yakup:insurance', icon: 'story', title: 'Kupa olmazsa balın %60’ı geri', source: 'Seyyah Yakup · Festival Güvencesi', permanent: true });
    const focusDay = this.todayKey();
    const earnedMs = this.state.focusDaily && this.state.focusDaily.day === focusDay ? this.state.focusDaily.earnedMs : 0;
    return {
      focus: { active: Date.now() < (this.state.focusBoostUntil || 0), icon: 'focus', title: 'Odak Bonusu', text: `+%${Math.round(FOCUS_BOOST * 100)} bal üretimi`, leftMs: Math.max(0, (this.state.focusBoostUntil || 0) - Date.now()), earnedTodayMs: earnedMs, dailyLimitMs: 4 * FOCUS_BOOST_MS },
      list: effects
    };
  }

  villageTarget(kg) {
    // İlk ev 50 kg'da, ardından her 150 kg sipariş teslimatında bir ev.
    return Math.min(VILLAGE.length, 6 + (kg >= 50 ? 1 + Math.floor((kg - 50) / 150) : 0));
  }

  // Köyün dış halkaları genişleyen adanın dışında kalır.
  ringKeys(radius) {
    const out = [];
    let q = -radius;
    let r = radius;
    for (const [dq, dr] of [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]]) {
      for (let i = 0; i < radius; i++) { out.push(key(q, r)); q += dq; r += dr; }
    }
    return out;
  }

  // n. yerleşimcinin karesi: halkanın etrafına aralıklı dağılır (7 ve 11 adımla)
  villageSlot(n) {
    if (n <= 36) { const ring = this.ringKeys(ISLAND_RADIUS + 1); return ring[((n - 1) * 7) % ring.length]; }
    const ring = this.ringKeys(ISLAND_RADIUS + 2);
    return ring[((n - 37) * 11) % ring.length];
  }

  checkVillage(silent = false) {
    const v = this.state.village;
    const target = Math.max(this.villageTarget(v.deliveredKg), this.state.counters.produced >= 50 ? 7 : 6);
    while (v.arrived.length < target) {
      const e = VILLAGE[v.arrived.length];
      v.arrived.push(e.n);
      v.slots[e.n] = this.villageSlot(e.n);
      if (e.n === 7 && this.state.ezgiWelcomeClaimed !== true) this.state.ezgiWelcomePending = true;
      if (e.effect === 'firin' || e.effect === 'pastane' || e.effect === 'muhtarlik') v.special[e.effect] = this.dayIndex();
      if (silent) continue;
      if (e.n === 7) this.events.push({ msg: '🌷 Kasabaya yeni biri yerleşti! Çiçekçi Ezgi dükkânını açtı.', villager: e.n });
      else if (e.type === 'koylu') this.events.push({ msg: `🏘️ Köye yeni biri taşındı: ${e.name} (${e.role}). ${FLOWERS[e.fav].name} balını çok sever.`, villager: e.n });
      else this.events.push({ msg: `${e.type === 'dukkan' ? '🏪' : '🏛️'} Köyde ${e.name} açıldı! ${e.effectText}`, villager: e.n });
      if (v.arrived.length === 37) this.events.push({ msg: '🏘️ Köyün ilk halkası doldu! Artık ikinci halkaya yerleşiyorlar.' });
      if (v.arrived.length === VILLAGE.length) this.milestone('koy_tamam', 'Köy tamamlandı: 78 yerleşimcinin hepsi geldi');
    }
    for (const [lvl, kg] of [[1, 50], [2, 150], [3, 400], [4, 1000]]) if (v.deliveredKg >= kg && !silent) this.milestone(`koy_seviye_${lvl}`, `Köy ${lvl}. seviyeye ulaştı`);
  }

  // Köyde yaşayıp sipariş verebilen kişiler (köylüler + dükkân sahipleri)
  villagePeople() {
    const out = [];
    for (const n of this.state.village.arrived) {
      const e = VILLAGE[n - 1];
      if (e.type === 'koylu') out.push({ name: e.name, fav: e.fav });
      else if (e.owner) out.push({ name: e.owner, fav: null });
    }
    return out;
  }

  // Açılmış yapıların etkileri
  fx(effect) {
    let v = 0;
    for (const n of this.state.village.arrived) { const e = VILLAGE[n - 1]; if (e.effect === effect) v += e.value; }
    return v;
  }

  ezgiUnlocked() { return !!(this.state.village && this.state.village.arrived.includes(7)); }

  ezgiChoice() {
    if (!this.ezgiUnlocked()) return null;
    const season = this.calendar().season;
    let pool = Object.keys(FLOWERS).filter((f) => season !== 'kis' && FLOWERS[f].seasons.includes(season));
    if (!pool.length) pool = Object.keys(FLOWERS);
    const day = this.dayIndex();
    return pool[Math.abs(day * 7 + 3) % pool.length];
  }

  seedCost(f) {
    let mult = 1 - this.fx('seedDiscount');
    if (this.ezgiChoice() === f) mult *= 0.85;
    return Math.max(1, Math.round(FLOWERS[f].seed * mult));
  }
  reviveCost(f) { return Math.max(1, Math.round(this.seedCost(f) * REVIVE_RATE)); }
  decorCost(id) { return Math.round(DECOR[id].cost * (1 - this.fx('decorDiscount'))); }
  syrupCost() { return Math.round(SYRUP_COST * (1 - this.fx('syrupDiscount'))); }
  medicineCost() { return Math.round(MEDICINE_COST * (1 - this.fx('medicineDiscount') - this.storyFx('medicine'))); }
  orderMax() { return ORDER_MAX + this.fx('orderMax'); }
  seasonOrderMult() {
    const s = this.calendar().season;
    return 1 + (s === 'yaz' ? this.fx('summerOrders') : 0) + (s === 'kis' ? this.fx('winterOrders') : 0);
  }

  // Fırın (7 günde bir), Pastane (5 günde bir), Muhtarlık (7 günde bir) düzenli siparişleri
  specialOrders() {
    const v = this.state.village;
    const day = this.dayIndex();
    const planted = this.plantedFlowers();
    const defs = [
      { key: 'firin', who: '🍞 Fırın', every: 7, flowers: ['yonca', 'papatya'], kg: [8, 12], mult: 1.6, days: 4 },
      { key: 'pastane', who: '🍰 Pastane', every: 5, flowers: ['lavanta', 'kisfundasi', 'kestane'], kg: [2, 4], mult: 2.2, days: 4 },
      { key: 'muhtarlik', who: '🏛️ Muhtarlık (köy isteği)', every: 7, flowers: null, kg: [20, 20], mult: 1.8, days: 6 }
    ];
    for (const d of defs) {
      if (!this.fx(d.key)) continue;
      if (day - (v.special[d.key] || 0) < d.every) continue;
      if (this.state.orders.list.some((x) => x.special === d.key)) continue;
      const options = (d.flowers || planted).filter((f) => planted.includes(f));
      if (!options.length) continue;
      v.special[d.key] = day;
      const f = options[Math.floor(Math.random() * options.length)];
      const kg = d.kg[0] + Math.floor(Math.random() * (d.kg[1] - d.kg[0] + 1));
      const reward = Math.round(kg * FLOWERS[f].price * d.mult * this.seasonOrderMult());
      this.state.orders.list.push({ id: uid(), who: d.who, flower: f, kg, reward, days: d.days + this.fx('orderDays'), status: 'open', deadline: null, special: d.key });
      this.state.counters.ordersIn += 1;
      this.events.push({ msg: `📜 ${d.who}: ${kg} kg ${FLOWERS[f].name} balı istiyor (düzenli sipariş, +${reward} 🪙).` });
    }
  }

  villageView() {
    const v = this.state.village;
    const kg = v.deliveredKg;
    const n = v.arrived.length;
    let nextKg = null;
    if (n < VILLAGE.length) nextKg = 50 + Math.max(0, n - 6) * 150;
    return {
      deliveredKg: Math.round(kg * 10) / 10,
      nextKg,
      total: VILLAGE.length,
      rings: n > 36 ? 2 : 1,
      ring1: this.ringKeys(ISLAND_RADIUS + 1),
      ring2: n > 36 ? this.ringKeys(ISLAND_RADIUS + 2) : [],
      residents: v.arrived.map((i) => ({ ...VILLAGE[i - 1], slot: v.slots[i], hearts: ((this.state.customers[VILLAGE[i - 1].owner || VILLAGE[i - 1].name] || {}).hearts) || 0 }))
    };
  }

  // --- Bal Defteri -----------------------------------------------------------------
  ledgerHoney(f) {
    const h = this.state.ledger.honey;
    if (!h[f]) h[f] = { kg: 0, soldKg: 0, earned: 0, bestPrice: 0, first: null };
    return h[f];
  }

  recordHarvest(hive, moved, scale) {
    const cal = this.calendar();
    const byFlower = {};
    for (const [f, kg] of Object.entries(this.lastHoney || {})) {
      const L = this.ledgerHoney(f);
      const took = kg * scale;
      byFlower[f] = took;
      if (!L.first && took > 0.01) {
        L.first = { day: cal.day, season: cal.seasonName, year: cal.year };
        this.events.push({ msg: `📖 Bal Defteri'ne yeni sayfa: ilk ${FLOWERS[f].name} balın!` });
      }
      L.kg += took;
    }
    this.state.ledger.harvests += 1;
    this.questEvent('harvest', { kg: moved, hiveId: hive.id, byFlower });
    const total = Object.values(this.state.ledger.honey).reduce((a, x) => a + x.kg, 0);
    if (total >= 20) this.milestone('ilk_kavanoz', 'İlk kavanoz: toplam 20 kg bal hasat ettin');
    if (Object.keys(FLOWERS).every((f) => (this.state.ledger.honey[f] || {}).first)) this.milestone('tum_ballar', 'Yedi balın hepsini ürettin');
  }

  milestone(id, text) {
    if (this.state.milestones[id]) return;
    this.state.milestones[id] = Date.now();
    this.events.push({ msg: `🌟 ${text}`, milestone: id });
  }

  // --- Günlük görevler -------------------------------------------------------------
  todayKey() { return new Date().toDateString(); }

  questCandidates() {
    const out = [];
    const choose = (a) => a[Math.floor(Math.random() * a.length)];
    const add = (type, family, target, reward, extra = {}) => out.push({ type, family, target, reward, heavy: false, ...extra });
    const hives = Object.values(this.state.hives);
    const planted = this.plantedFlowers();
    const stored = Object.keys(this.state.storage).filter((f) => (this.state.storage[f] || 0) >= 0.05);
    const orders = this.state.orders.list.filter((o) => o.status === 'open' || o.status === 'accepted');
    const openOrders = orders.filter((o) => o.status === 'open');
    const affordableSeeds = Object.keys(FLOWERS).filter((x) => this.seedCost(x) <= this.state.coins);
    const emptyTiles = Object.values(this.state.tiles).filter((t) => t.owned && t.kind === 'grass' && !t.item).length;
    const wilted = Object.entries(this.state.tiles).filter(([, t]) => t.owned && t.item && t.item.type === 'flower' && t.item.wilted);
    const rooms = hives.reduce((n, h) => n + Math.max(0, h.capBees - h.bees), 0);

    { const vals = [5, 10, 15], i = Math.floor(Math.random() * vals.length); add('harvest', 'harvest', vals[i], [50, 70, 90][i]); }
    if (planted.length) { const f = choose(planted), target = 3 + Math.floor(Math.random() * 4); add('harvestFlower', 'harvest', target, target <= 3 ? 60 : target <= 5 ? 75 : 90, { flower: f }); }
    if (stored.length) { const vals = [5, 8, 11], i = Math.floor(Math.random() * vals.length); add('sell', 'market', vals[i], [45, 60, 80][i]); }
    if (orders.length) add('deliver', 'orders', 1, 90);
    if (this.state.wax >= 0.5) add('candle', 'craft', 1, 50);
    if (emptyTiles && affordableSeeds.length) add('plant', 'plant', 1, 45);

    if (hives.length >= 2) add('harvest2Hives', 'harvest', 2, 65);
    if (hives.length >= 3) add('harvest3Hives', 'harvest', 3, 95);
    if (hives.some((h) => h.capKg >= 10) && planted.length) add('harvestSingle10', 'harvest', 1, 80, { minKg: 10 });
    if (planted.length >= 2) add('harvest2Types', 'harvest', 2, 70);
    if (planted.length >= 3) add('harvest3Types', 'harvest', 3, 105);
    { const premium = planted.filter((x) => ['lavanta', 'kisfundasi', 'kestane'].includes(x)); if (premium.length) add('harvestPremium', 'harvest', 3, 110); }

    if (stored.length) add('sell2Transactions', 'market', 2, 55);
    if (stored.length >= 2) add('sell2Types', 'market', 2, 75);
    if (stored.length) { const flower = choose(stored), target = (this.state.storage[flower] || 0) >= 5 ? (Math.random() < 0.5 ? 3 : 5) : Math.min(3, Math.max(1, Math.floor(this.state.storage[flower] || 1))); add('sellFlower', 'market', target, target >= 5 ? 90 : 70, { flower }); }
    if (stored.length) { const maxGain = Math.max(...stored.map((x) => (this.state.storage[x] || 0) * this.price(x))); if (maxGain >= 100) { const minGain = maxGain >= 200 && Math.random() < 0.5 ? 200 : 100; add('saleIncome', 'market', 1, minGain === 200 ? 115 : 75, { minGain }); } }
    if (this.calendar().season === 'kis' && stored.length) add('winterSell', 'market', 5, 90);

    if (openOrders.length) add('acceptOrder', 'orders', 1, 45);
    if (orders.length >= 2) add('deliver2', 'orders', 2, 140);
    if (orders.length) add('deliverNoPenalty', 'orders', 1, 95);
    if (orders.length) { const ord = choose(orders); add('deliverPerson', 'orders', 1, 120, { who: ord.who }); }
    { const regs = orders.filter((o) => ((this.state.customers[o.who] || {}).hearts || 0) > 0); if (regs.length) add('deliverRegular', 'orders', 1, 100); }

    if (rooms >= 1 && hives.some((h) => h.bees < h.capBees && this.beePrice(h) <= this.state.coins)) add('buyBee', 'bees', 1, 45);
    if (rooms >= 3) { const prices = []; for (const h of hives) for (let n = h.bees + 1; n <= h.capBees; n++) prices.push(this.beeNumberPrice(n)); prices.sort((x, y) => x - y); if (prices.slice(0, 3).reduce((x, y) => x + y, 0) <= this.state.coins) add('buy3Bees', 'bees', 3, 90); }
    if (hives.length && this.state.coins >= this.syrupCost()) add('syrup1', 'bees', 1, 55);
    if (hives.length >= 2 && this.state.coins >= this.syrupCost() * 2) add('syrup2Hives', 'bees', 2, 95);
    if (hives.some((h) => h.sick) && this.state.coins >= this.medicineCost()) add('cureHive', 'bees', 1, 110);
    if (hives.length && this.state.coins >= BREED_CHANGE_COST) add('changeBreed', 'bees', 1, 120, { heavy: true });
    { const x = hives.map((h) => this.nextUpgrade(h)).filter((u) => u && u.type === 'queen' && u.cost <= this.state.coins); if (x.length) { const c = Math.min(...x.map((u) => u.cost)); add('queenUpgrade', 'bees', 1, Math.min(400, Math.max(100, Math.round(c * 0.12))), { heavy: true }); } }
    { const x = hives.map((h) => this.nextUpgrade(h)).filter((u) => u && u.type === 'hive' && u.cost <= this.state.coins); if (x.length) { const c = Math.min(...x.map((u) => u.cost)); add('hiveUpgrade', 'bees', 1, Math.min(450, Math.max(100, Math.round(c * 0.10))), { heavy: true }); } }
    if (emptyTiles && this.state.coins >= this.nextHiveCost()) add('placeHive', 'bees', 1, 180, { heavy: true });

    if (emptyTiles >= 2 && affordableSeeds.length) add('plant2', 'plant', 2, 75);
    if (emptyTiles && affordableSeeds.length) { const flower = choose(affordableSeeds); add('plantFlower', 'plant', 1, Math.min(220, Math.max(50, 40 + Math.round(this.seedCost(flower) * 0.15))), { flower, heavy: true }); }
    if (wilted.some(([k, t]) => this.reviveCost(t.item.flower) <= this.state.coins)) add('reviveFlower', 'plant', 1, 60);
    if (emptyTiles >= 2 && affordableSeeds.length >= 2) add('plant2Types', 'plant', 2, 90);
    if (this.state.candles >= 1) { const target = this.state.candles >= 2 && Math.random() < 0.5 ? 2 : 1; add('sellCandles', 'craft', target, target === 2 ? 75 : 50); }
    if (this.state.wax >= 1) add('candle2', 'craft', 2, 80);
    add('claim2', 'meta', 2, 65);
    if (this.state.merchant && this.state.merchant.active && this.state.merchant.stock.some((x) => !x.sold)) add('merchantBuy', 'special', 1, 70);
    if (this.state.merchant && this.state.merchant.active && (this.state.storage[this.state.merchant.wants] || 0) >= 0.05 && this.state.merchant.wantsLeft > 0) add('merchantSell', 'special', 1, 85);
    return out;
  }

  makeQuest(excluded = [], usedFamilies = [], heavyUsed = false) {
    let pool = this.questCandidates().filter((q) => !excluded.includes(q.type) && (!heavyUsed || !q.heavy));
    if (!pool.length) return null;
    const diverse = pool.filter((q) => !usedFamilies.includes(q.family));
    if (diverse.length) pool = diverse;
    const q = { ...pool[Math.floor(Math.random() * pool.length)], id: uid(), progress: 0, claimed: false, seen: [] };
    if (Math.random() < 0.2) { const tiers = ['papatya', 'aycicegi', 'kekik']; q.voucher = tiers[Math.floor(Math.random() * tiers.length)]; }
    return q;
  }

  ensureQuests() {
    const day = this.todayKey();
    const old = this.state.quests;
    if (old && old.day === day) {
      if (old.refreshFree == null) old.refreshFree = 2;
      if (old.paidUsed == null) old.paidUsed = false;
      return;
    }
    const list = [];
    const families = [];
    let heavy = false;
    while (list.length < 3) {
      const q = this.makeQuest(list.map((x) => x.type), families, heavy);
      if (!q) break;
      list.push(q); families.push(q.family); heavy = heavy || q.heavy;
    }
    this.state.quests = { day, list, refreshFree: 2, paidUsed: false };
  }

  questEvent(event, data = {}) {
    this.ensureQuests();
    const complete = (q, amount = 1) => {
      const before = q.progress;
      q.progress = Math.min(q.target, q.progress + amount);
      if (before < q.target && q.progress >= q.target) this.events.push({ msg: '✅ Günlük görev tamamlandı! Ödülünü almayı unutma.' });
    };
    const seen = (q, value) => { if (value == null) return; q.seen = Array.isArray(q.seen) ? q.seen : []; if (!q.seen.includes(value)) q.seen.push(value); q.progress = Math.min(q.target, q.seen.length); };
    for (const q of this.state.quests.list) {
      if (q.claimed || q.progress >= q.target) continue;
      if (event === 'harvest') {
        if (q.type === 'harvest') complete(q, data.kg || 0);
        if (q.type === 'harvestFlower' && q.flower) complete(q, (data.byFlower || {})[q.flower] || 0);
        if (q.type === 'harvest2Hives' || q.type === 'harvest3Hives') { const before = q.progress; seen(q, data.hiveId); if (before < q.target && q.progress >= q.target) this.events.push({ msg: '✅ Günlük görev tamamlandı! Ödülünü almayı unutma.' }); }
        if (q.type === 'harvestSingle10' && (data.kg || 0) >= (q.minKg || 10)) complete(q, 1);
        if (q.type === 'harvest2Types' || q.type === 'harvest3Types') { const before = q.progress; for (const [f, kg] of Object.entries(data.byFlower || {})) if (kg > 0.01) seen(q, f); if (before < q.target && q.progress >= q.target) this.events.push({ msg: '✅ Günlük görev tamamlandı! Ödülünü almayı unutma.' }); }
        if (q.type === 'harvestPremium') complete(q, ['lavanta', 'kisfundasi', 'kestane'].reduce((n, f) => n + ((data.byFlower || {})[f] || 0), 0));
      }
      if (event === 'sell') {
        if (q.type === 'sell') complete(q, data.kg || 0);
        if (q.type === 'sell2Transactions') complete(q, 1);
        if (q.type === 'sell2Types') { const before = q.progress; seen(q, data.flower); if (before < q.target && q.progress >= q.target) this.events.push({ msg: '✅ Günlük görev tamamlandı! Ödülünü almayı unutma.' }); }
        if (q.type === 'sellFlower' && q.flower === data.flower) complete(q, data.kg || 0);
        if (q.type === 'saleIncome' && (data.gain || 0) >= (q.minGain || 100)) complete(q, 1);
        if (q.type === 'winterSell' && this.calendar().season === 'kis') complete(q, data.kg || 0);
      }
      if (event === 'acceptOrder' && q.type === 'acceptOrder') complete(q, 1);
      if (event === 'deliver') {
        if (q.type === 'deliver' || q.type === 'deliver2' || q.type === 'deliverNoPenalty') complete(q, 1);
        if (q.type === 'deliverPerson' && q.who === data.who) complete(q, 1);
        if (q.type === 'deliverRegular' && data.regular) complete(q, 1);
      }
      if (event === 'buyBee' && (q.type === 'buyBee' || q.type === 'buy3Bees')) complete(q, 1);
      if (event === 'syrup') { if (q.type === 'syrup1') complete(q, 1); if (q.type === 'syrup2Hives') { const before = q.progress; seen(q, data.hiveId); if (before < q.target && q.progress >= q.target) this.events.push({ msg: '✅ Günlük görev tamamlandı! Ödülünü almayı unutma.' }); } }
      if (event === 'cure' && q.type === 'cureHive') complete(q, 1);
      if (event === 'breedChange' && q.type === 'changeBreed') complete(q, 1);
      if (event === 'upgrade' && q.type === (data.kind === 'queen' ? 'queenUpgrade' : 'hiveUpgrade')) complete(q, 1);
      if (event === 'placeHive' && q.type === 'placeHive') complete(q, 1);
      if (event === 'plant') { if (q.type === 'plant' || q.type === 'plant2') complete(q, 1); if (q.type === 'plantFlower' && q.flower === data.flower) complete(q, 1); if (q.type === 'plant2Types') { const before = q.progress; seen(q, data.flower); if (before < q.target && q.progress >= q.target) this.events.push({ msg: '✅ Günlük görev tamamlandı! Ödülünü almayı unutma.' }); } }
      if (event === 'revive' && q.type === 'reviveFlower') complete(q, 1);
      if (event === 'candleMake' && (q.type === 'candle' || q.type === 'candle2')) complete(q, 1);
      if (event === 'candleSell' && q.type === 'sellCandles') complete(q, data.count || 1);
      if (event === 'claim' && q.type === 'claim2' && data.sourceId !== q.id) complete(q, 1);
      if (event === 'merchantBuy' && q.type === 'merchantBuy') complete(q, 1);
      if (event === 'merchantSell' && q.type === 'merchantSell') complete(q, 1);
    }
  }

  questProgress(type, amount, flower) {
    this.ensureQuests();
    for (const q of this.state.quests.list) {
      if (q.type !== type || q.claimed || q.progress >= q.target) continue;
      if (type === 'harvestFlower' && q.flower !== flower) continue;
      const before = q.progress;
      q.progress = Math.min(q.target, q.progress + amount);
      if (before < q.target && q.progress >= q.target) this.events.push({ msg: '✅ Günlük görev tamamlandı! Ödülünü almayı unutma.' });
    }
  }

  refreshQuest(id) {
    this.ensureQuests();
    const Q = this.state.quests;
    const i = Q.list.findIndex((x) => x.id === id);
    if (i < 0) return this.fail('Görev bulunamadı.');
    const old = Q.list[i];
    if (old.claimed || old.progress >= old.target) return this.fail('Tamamlanmış görev değiştirilemez.');
    const others = Q.list.filter((_, n) => n !== i);
    const fresh = this.makeQuest([...others.map((x) => x.type), old.type], others.map((x) => x.family), others.some((x) => x.heavy));
    if (!fresh) return this.fail('Şu an uygun başka görev bulunamadı. Hakkın harcanmadı.');
    let cost = 0;
    if (Q.refreshFree > 0) Q.refreshFree -= 1;
    else {
      if (Q.paidUsed) return this.fail('Bugünkü değiştirme hakkın bitti.');
      cost = 100;
      if (this.state.coins < cost) return this.fail('Ücretli görev değişimi için 100 🪙 gerekli.');
      this.state.coins -= cost;
      Q.paidUsed = true;
    }
    Q.list[i] = fresh;
    this.save();
    return { ok: true, msg: cost ? `Görev değiştirildi (-${cost} 🪙).` : `Görev ücretsiz değiştirildi. Kalan ücretsiz hak: ${Q.refreshFree}.` };
  }

  claimQuest(id) {
    this.ensureQuests();
    const q = this.state.quests.list.find((x) => x.id === id);
    if (!q || q.claimed) return this.fail('Görev bulunamadı.');
    if (q.progress < q.target) return this.fail('Görev henüz tamamlanmadı.');
    q.claimed = true;
    const reward = Math.round(q.reward * (1 + this.fx('questBonus') + this.storyFx('quest')));
    this.state.coins += reward;
    this.state.questsDone += 1;
    if (q.voucher) this.state.vouchers[q.voucher] = (this.state.vouchers[q.voucher] || 0) + 1;
    this.questEvent('claim', { sourceId: q.id });
    this.save();
    return { ok: true, msg: `Görev ödülü: +${reward} 🪙${q.voucher ? ` ve 1 ${FLOWERS[q.voucher].name} tohumu 🎁` : ''}` };
  }

  questText(q) {
    const f = q.flower ? FLOWERS[q.flower].name : '';
    const map = {
      harvest: `${q.target} kg bal hasat et`, harvestFlower: `${q.target} kg ${f} balı hasat et`, sell: `Pazarda ${q.target} kg bal sat`, deliver: 'Bir siparişi teslim et', candle: 'Bir mum yap', plant: 'Bir tarh ek ya da yeniden ek',
      harvest2Hives: '2 farklı kovandan hasat yap', harvest3Hives: '3 farklı kovandan hasat yap', harvestSingle10: 'Tek hasatta en az 10 kg bal al', harvest2Types: '2 farklı bal türü hasat et', harvest3Types: '3 farklı bal türü hasat et', harvestPremium: 'Lavanta, Kış Fundası veya kestane balından toplam 3 kg hasat et',
      sell2Transactions: 'Pazarda 2 ayrı satış yap', sell2Types: '2 farklı bal türü sat', sellFlower: `${q.target} kg ${f} balı sat`, saleIncome: `Tek satıştan en az ${q.minGain} 🪙 kazan`, winterSell: 'Kışın pazarda 5 kg bal sat',
      acceptOrder: 'Bir sipariş kabul et', deliver2: '2 sipariş teslim et', deliverNoPenalty: 'Bir siparişi başarıyla tamamla', deliverPerson: `${q.who} için bir sipariş teslim et`, deliverRegular: 'Bir müdavim köylüye sipariş teslim et',
      buyBee: '1 arı satın al', buy3Bees: '3 arı satın al', syrup1: 'Bir kovana şurup ver', syrup2Hives: '2 farklı kovana şurup ver', cureHive: 'Hasta bir kovanı iyileştir', changeBreed: 'Bir kovanın arı ırkını değiştir', queenUpgrade: 'Bir kraliçe yükseltmesi yap', hiveUpgrade: 'Bir kovan kapasite yükseltmesi yap', placeHive: 'Yeni bir kovan kur',
      plant2: '2 tarh ek', plantFlower: `1 ${f} tarhı ek`, reviveFlower: 'Solmuş bir tarhı canlandır', plant2Types: '2 farklı çiçek türü ek', sellCandles: `${q.target} mum sat`, candle2: '2 mum üret', claim2: 'Diğer 2 günlük görev ödülünü al', merchantBuy: "Seyyah Yakup'tan 1 ürün al", merchantSell: "Seyyah Yakup'a bal sat"
    };
    return map[q.type] || q.type;
  }
  // --- İsimler ve kavanoz etiketi -----------------------------------------------
  cleanName(name, max = 24) { return String(name || '').replace(/[<>]/g, '').trim().slice(0, max); }

  renameHive(hiveId, name) {
    const h = this.state.hives[hiveId];
    const n = this.cleanName(name);
    if (!h || !n) return this.fail('Geçerli bir isim yaz.');
    h.name = n;
    this.save();
    return { ok: true, msg: `Kovanın yeni adı: ${n}` };
  }

  setFarmName(name) {
    const n = this.cleanName(name, 28);
    if (!n) return this.fail('Geçerli bir isim yaz.');
    this.state.farmName = n;
    this.save();
    return { ok: true, msg: `Çiftliğinin adı artık "${n}".` };
  }

  setLabel(design, color) {
    if (!LABEL_DESIGNS[design] || !/^#[0-9a-fA-F]{6}$/.test(String(color))) return this.fail('Geçersiz etiket.');
    const first = !this.state.label;
    this.state.label = { design, color };
    this.save();
    return { ok: true, msg: first ? 'Kavanoz etiketin hazır! Müdavimlerin artık %5 bahşiş verir.' : 'Etiket güncellendi.' };
  }

  // --- Hava durumu, hastalık, tanıtım -----------------------------------------
  rollWeather(season, silent = false) {
    const odds = WEATHER_ODDS[season];
    let x = Math.random();
    let pick = odds[odds.length - 1][0];
    for (const [w, p] of odds) { if (x < p) { pick = w; break; } x -= p; }
    this.state.weather = pick;
    if (silent) return;
    if (pick === 'yagmurlu') this.events.push({ msg: '🌧️ Bugün yağmurlu, arılar kovandan pek çıkmıyor.' });
    else if (pick === 'karli') this.events.push({ msg: '🌨️ Bugün kar yağıyor. Arılar kovanda ısınıyor.' });
  }

  giveMedicine(hiveId) {
    const h = this.state.hives[hiveId];
    if (!h) return this.fail('Kovan bulunamadı.');
    if (!h.sick) return this.fail('Bu kovan sağlıklı.');
    const medCost = this.medicineCost();
    if (this.state.coins < medCost) return this.fail(`Yeterli jeton yok (${medCost} gerekli).`);
    this.state.coins -= medCost;
    this.recoverHive(h, this.dayIndex(), false);
    this.state.ledger.cured += 1;
    this.questEvent('cure');
    this.save();
    return { ok: true, msg: `${h.name} iyileşti 💊` };
  }

  finishTutorial() { this.state.tutorialDone = true; this.save(); return { ok: true, msg: '' }; }

  // --- Sen yokken özeti -------------------------------------------------------
  myRank() { const me = this.leaderboard().find((r) => r.me); return me ? me.rank : 1; }

  markAway() {
    const now = Date.now();
    this.state.lastSeenAt = now;
    this.state.away = { at: now, ...this.state.counters, rank: this.myRank() };
    this.save();
  }

  takeAwaySummary() {
    const a = this.state.away;
    this.state.away = null;
    if (!a || Date.now() - a.at < AWAY_SUMMARY_MS) return null;
    const c = this.state.counters;
    const board = this.leaderboard();
    const rank = this.myRank();
    const passedBy = rank > a.rank ? board[rank - 2] : null;
    return {
      minutes: Math.round((Date.now() - a.at) / 60000),
      produced: c.produced - a.produced,
      born: c.born - a.born,
      died: c.died - a.died,
      ordersIn: c.ordersIn - a.ordersIn,
      rank,
      oldRank: a.rank,
      passedBy: passedBy ? passedBy.name : null,
      full: Object.values(this.state.hives).filter((h) => this.hiveTotal(h) >= h.capKg - 0.05).length,
      sick: Object.values(this.state.hives).filter((h) => h.sick).length
    };
  }

  notificationSoundEnabled(kind) {
    const s = this.state.gameSettings || GAME_SETTINGS_DEFAULT;
    if (s.notificationSound === false) return false;
    const key = {
      bee_order_due: 'notifyOrders',
      bee_hive_full: 'notifyHive', bee_sick: 'notifyHive', bee_winter: 'notifyHive',
      bee_merchant: 'notifyMerchant',
      bee_overtaken: 'notifySpecial', bee_letter: 'notifySpecial'
    }[kind] || 'notifySpecial';
    return !s.audio || s.audio[key] !== false;
  }

  // Masaüstündeki Nero için: oyun penceresi kapalıyken söylenecek yeni durumlar
  pendingAlerts() {
    const out = [];
    const seen = this.alertSeen;
    for (const h of Object.values(this.state.hives)) {
      const full = this.hiveTotal(h) >= h.capKg - 0.05;
      if (full && !seen[`full:${h.id}`]) out.push({ kind: 'bee_hive_full', vars: { hive: h.name } });
      seen[`full:${h.id}`] = full;
      if (h.sick && !seen[`sick:${h.id}`]) out.push({ kind: 'bee_sick', vars: { hive: h.name } });
      seen[`sick:${h.id}`] = !!h.sick;
    }
    for (const o of this.state.orders.list) {
      const due = o.status === 'accepted' && o.deadline - this.state.gameMs < DAY_GAME_MS;
      if (due && !seen[`due:${o.id}`]) out.push({ kind: 'bee_order_due', vars: { who: o.who } });
      if (due) seen[`due:${o.id}`] = true;
    }
    const winterHungry = this.calendar().season === 'kis' && Object.values(this.state.hives).some((h) => h.syrup < 1);
    const wKey = `winter:${Math.floor(this.dayIndex() / DAYS_PER_SEASON)}`;
    if (winterHungry && !seen[wKey]) { out.push({ kind: 'bee_winter', vars: {} }); seen[wKey] = true; }
    const rank = this.myRank();
    if (seen.rank && rank > seen.rank) {
      const passer = this.leaderboard()[rank - 2];
      out.push({ kind: 'bee_overtaken', vars: { rival: passer ? passer.name : 'Bir rakip' } });
    }
    seen.rank = rank;
    const m = this.state.merchant;
    if (m && m.active && !seen[`merchant:${m.arrivedDay}`]) { out.push({ kind: 'bee_merchant', vars: {} }); seen[`merchant:${m.arrivedDay}`] = true; }
    const lastLetter = this.state.letters[this.state.letters.length - 1];
    if (lastLetter && !lastLetter.read && !seen[`letter:${lastLetter.id}`]) { out.push({ kind: 'bee_letter', vars: { who: lastLetter.from } }); seen[`letter:${lastLetter.id}`] = true; }
    // Oyun ayarlarındaki bildirim tercihleri
    const pref = this.state.gameSettings.notify;
    const map = { bee_hive_full: 'full', bee_order_due: 'due', bee_sick: 'sick', bee_winter: 'winter', bee_overtaken: 'rival', bee_merchant: 'merchant', bee_letter: 'letter' };
    return out.filter((a) => pref[map[a.kind]] !== false);
  }

  // --- Pazar -------------------------------------------------------------------
  newMarket() {
    const mult = {};
    const history = {};
    for (const f of Object.keys(FLOWERS)) {
      mult[f] = 0.9 + Math.random() * 0.25;
      history[f] = [mult[f]];
    }
    return { mult, prev: { ...mult }, history, event: null };
  }

  // Her gün: fiyatlar bir öncekine yakın kalarak %80-130 arasında dalgalanır
  rollMarket() {
    const m = this.state.market;
    const day = this.dayIndex();
    const fx = this.state.merchantEffects || {};
    m.prev = { ...m.mult };
    const forecast = fx.marketForecast && fx.marketForecast.forDay === day ? fx.marketForecast : null;
    for (const f of Object.keys(FLOWERS)) {
      if (forecast && forecast.nextMult && forecast.nextMult[f] != null) m.mult[f] = forecast.nextMult[f];
      else {
        const drift = (Math.random() - 0.5) * 0.18;
        const pull = (1.05 - m.mult[f]) * 0.15;
        m.mult[f] = Math.min(1.3, Math.max(0.8, m.mult[f] + drift + pull));
      }
      m.history[f] = [...(m.history[f] || []), m.mult[f]].slice(-HISTORY_DAYS);
    }
    if (forecast) fx.marketForecast = null;
    if (m.event && day >= m.event.until) m.event = null;
    if (!m.event && Math.random() < 0.12) {
      const keys = Object.keys(FLOWERS);
      const f = keys[Math.floor(Math.random() * keys.length)];
      m.event = { flower: f, pct: 50, until: day + 2 };
      this.events.push({ msg: `🎉 Festival! ${FLOWERS[f].name} balı 2 gün boyunca %50 daha değerli.` });
    }
  }

  price(f) {
    const lock = this.state.marketLocks && this.state.marketLocks[f];
    if (lock && this.dayIndex() < lock.untilDay) return lock.price;
    const m = this.state.market;
    const season = this.calendar().season;
    let p = FLOWERS[f].price * m.mult[f] * SEASON_PRICE[season];
    if (m.event && m.event.flower === f) p *= 1 + m.event.pct / 100;
    p *= 1 + this.fx('marketBonus') + this.storyFx('market') + (f === 'yonca' ? this.storyFx('yonca') : 0);
    return Math.round(p * 10) / 10;
  }

  prices() {
    const m = this.state.market;
    const season = this.calendar().season;
    const out = {};
    for (const f of Object.keys(FLOWERS)) {
      const change = m.prev[f] ? (m.mult[f] - m.prev[f]) / m.prev[f] : 0;
      out[f] = {
        price: this.price(f),
        change: Math.round(change * 100),
        history: (m.history[f] || []).map((x) => Math.round(FLOWERS[f].price * x * SEASON_PRICE[season] * 10) / 10),
        festival: !!(m.event && m.event.flower === f)
      };
    }
    return out;
  }

  sellHoney(f, amount) {
    const have = this.state.storage[f] || 0;
    if (!FLOWERS[f]) return this.fail('Bilinmeyen bal.');
    if (have < 0.05) return this.fail(`Depoda ${FLOWERS[f].name} balı yok.`);
    const kg = amount === 'all' ? have : Math.min(have, Number(amount) || 0);
    if (kg < 0.05) return this.fail('Satılacak miktar yok.');
    const fx = this.state.merchantEffects || {};
    const marketUnit = this.price(f);
    const sealKg = Math.min(kg, fx.marketSealKg || 0);
    const gain = Math.round(kg * marketUnit + sealKg * marketUnit * 0.15);
    if ((fx.marketSealKg || 0) > 0) fx.marketSealKg = 0; // yalnız bir sonraki satış
    this.state.storage[f] = have - kg;
    if (this.state.storage[f] < 0.001) delete this.state.storage[f];
    this.state.coins += gain;
    this.state.counters.earned += gain;
    const L = this.ledgerHoney(f);
    L.soldKg += kg;
    this.countSold(f, kg);
    L.earned += gain;
    const realizedUnit = gain / kg;
    if (!L.bestPrice || realizedUnit > L.bestPrice) L.bestPrice = Math.round(realizedUnit * 10) / 10;
    const best = this.state.ledger.bestSale;
    if (!best || gain > best.coins) this.state.ledger.bestSale = { coins: gain, flower: f, kg: Math.round(kg * 10) / 10 };
    this.questEvent('sell', { kg, flower: f, gain });
    this.save();
    return { ok: true, msg: `${kg.toFixed(1)} kg ${FLOWERS[f].name} balı satıldı (+${gain} 🪙).` };
  }

  nextStorage() { return STORAGE_UPGRADES.find((u) => u.cap > (this.state.storageBaseCap || 50)) || null; }

  upgradeStorage() {
    const u = this.nextStorage();
    if (!u) return this.fail('Depo en büyük boyutta.');
    const fx = this.state.merchantEffects || {};
    const coupon = !!fx.storageCoupon;
    const cost = Math.round(u.cost * (coupon ? 0.8 : 1));
    if (this.state.coins < cost) return this.fail(`Yeterli jeton yok (${cost} gerekli).`);
    this.state.coins -= cost;
    if (coupon) fx.storageCoupon = false;
    this.state.storageBaseCap = u.cap;
    this.state.storageCap = u.cap + ((this.state.merchant && this.state.merchant.sandik) || 0) * 10;
    this.save();
    return { ok: true, msg: `Depo büyüdü: artık ${this.state.storageCap} kg alıyor${coupon ? ` · kuponla ${u.cost - cost} 🪙 tasarruf` : ''}.` };
  }

  // --- Siparişler ------------------------------------------------------------
  plantedFlowers() {
    const set = new Set();
    for (const t of Object.values(this.state.tiles)) if (t.owned && t.item && t.item.type === 'flower' && !t.item.wilted) set.add(t.item.flower);
    return [...set];
  }

  makeOrder() {
    const planted = this.plantedFlowers();
    if (!planted.length) return null;
    // Sipariş veren: köyde yaşayanlar (tanıdıklar biraz daha sık)
    const used = new Set(this.state.orders.list.filter((x) => !x.special && (x.status === 'open' || x.status === 'accepted')).map((x) => x.who));
    const pool = this.villagePeople().filter((p) => !used.has(p.name));
    if (!pool.length) return null;
    const known = pool.filter((p) => ((this.state.customers[p.name] || {}).hearts || 0) > 0);
    const person = known.length && Math.random() < 0.45 ? known[Math.floor(Math.random() * known.length)] : pool[Math.floor(Math.random() * pool.length)];
    const who = person.name;
    let f = planted[Math.floor(Math.random() * planted.length)];
    let fav = false;
    if (person && person.fav && planted.includes(person.fav) && Math.random() < 0.35) { f = person.fav; fav = true; }
    else if (this.fx('favorOrders') && Math.random() < 0.3) {
      const pick = ['kekik', 'kisfundasi'].filter((x) => planted.includes(x));
      if (pick.length) f = pick[Math.floor(Math.random() * pick.length)];
    }
    const def = FLOWERS[f];
    // Değerli bal daha az miktarda istenir
    const maxKg = def.price >= 50 ? 5 : def.price >= 25 ? 8 : 12;
    const kg = Math.max(2, Math.round(2 + Math.random() * (maxKg - 2)));
    const days = 2 + Math.floor(Math.random() * 4) + this.fx('orderDays');
    const hearts = (this.state.customers[who] || {}).hearts || 0;
    const reward = Math.round(kg * def.price * (1.4 + Math.random() * 0.4) * (1 + hearts * HEART_BONUS) * (fav ? 1.15 : 1) * this.seasonOrderMult() * (1 + (person ? this.storyFx('orderPay') : 0))); // piyasadan daha iyi öder
    return { id: uid(), who, flower: f, kg, reward, days, status: 'open', deadline: null, fav };
  }

  processOrders() {
    const o = this.state.orders;
    const now = this.state.gameMs;
    // Süresi geçen kabul edilmiş siparişler: ceza
    for (const ord of [...o.list]) {
      if (ord.status === 'accepted' && now >= ord.deadline) {
        const fine = Math.round(ord.reward * ORDER_PENALTY);
        this.state.coins = Math.max(0, this.state.coins - fine);
        o.list = o.list.filter((x) => x.id !== ord.id);
        this.events.push({ msg: `Sipariş yetişmedi (${ord.who}). -${fine} 🪙 ceza.`, err: true });
      }
    }
    this.specialOrders();
    // Yeni sipariş: gerçek zamanda 5 dakikada bir. Uzun aradan sonra tek seferde en fazla 3 tane birikir.
    const real = Date.now();
    if (!o.nextAtReal) o.nextAtReal = real + ORDER_EVERY_REAL_MS;
    const normalCount = o.list.filter((x) => !x.special).length;
    if (normalCount >= this.orderMax()) { o.nextAtReal = real + ORDER_EVERY_REAL_MS; return; }
    if (real >= o.nextAtReal) {
      const elapsedSlots = Math.floor((real - o.nextAtReal) / ORDER_EVERY_REAL_MS) + 1;
      const addCount = Math.min(elapsedSlots, ORDER_CATCHUP_MAX, this.orderMax() - normalCount);
      o.nextAtReal += elapsedSlots * ORDER_EVERY_REAL_MS;
      for (let i = 0; i < addCount; i++) {
        const ord = this.makeOrder();
        if (!ord) break;
        o.list.push(ord);
        this.state.counters.ordersIn += 1;
        this.events.push({ msg: `📜 Yeni sipariş: ${ord.who} ${ord.kg} kg ${FLOWERS[ord.flower].name} balı istiyor.` });
      }
    }
  }

  findOrder(id) { return this.state.orders.list.find((x) => x.id === id); }

  acceptOrder(id) {
    const ord = this.findOrder(id);
    if (!ord || ord.status !== 'open') return this.fail('Sipariş bulunamadı.');
    ord.status = 'accepted';
    ord.deadline = this.state.gameMs + ord.days * DAY_GAME_MS;
    this.questEvent('acceptOrder', { who: ord.who });
    this.save();
    return { ok: true, msg: `Sipariş kabul edildi (${ord.who}). ${ord.days} gün içinde teslim et.` };
  }

  deliverOrder(id) {
    const ord = this.findOrder(id);
    if (!ord || ord.status !== 'accepted') return this.fail('Önce siparişi kabul et.');
    const have = this.state.storage[ord.flower] || 0;
    if (have + 1e-6 < ord.kg) return this.fail(`Depoda yeterli ${FLOWERS[ord.flower].name} balı yok (${have.toFixed(1)} / ${ord.kg} kg).`);
    this.state.storage[ord.flower] = have - ord.kg;
    if (this.state.storage[ord.flower] < 0.001) delete this.state.storage[ord.flower];
    const known = ((this.state.customers[ord.who] || {}).hearts || 0) > 0;
    const wasRegular = known;
    const fx = this.state.merchantEffects || {};
    const seal = ord.merchantPayBonus ? Math.round(ord.reward * ord.merchantPayBonus) : 0;
    const extra = known && this.state.label ? Math.round(ord.reward * LABEL_BONUS) : 0;
    this.state.coins += ord.reward + seal + extra;
    this.state.counters.earned += ord.reward + seal + extra;
    this.state.orders.list = this.state.orders.list.filter((x) => x.id !== id);
    const relationExtra = (fx.friendToken || 0) + (fx.priorityCard || 0);
    this.bond(ord.who, relationExtra);
    fx.friendToken = 0;
    fx.priorityCard = 0;
    this.state.ledger.ordersDone += 1;
    const LD = this.state.ledger;
    LD.deliveredKgBy[ord.flower] = (LD.deliveredKgBy[ord.flower] || 0) + ord.kg;
    this.countSold(ord.flower, ord.kg);
    LD.deliveredOrdersBy[ord.flower] = (LD.deliveredOrdersBy[ord.flower] || 0) + 1;
    LD.deliveredTo[ord.who] = (LD.deliveredTo[ord.who] || 0) + 1;
    if (ord.special === 'muhtarlik') LD.muhtarlikDone += 1;
    this.questEvent('deliver', { who: ord.who, regular: wasRegular });
    this.state.village.deliveredKg += ord.kg;
    this.checkVillage();
    this.events.push({ type: 'delivered', who: (ord.special && VILLAGE.find((v) => v.effect === ord.special)?.owner) || ord.who,
      flower: ord.flower, kg: ord.kg });
    this.save();
    return { ok: true, msg: `${ord.who} çok memnun kaldı! +${ord.reward} 🪙${seal ? ` (+${seal} Sipariş Mührü)` : ''}${extra ? ` (+${extra} etiket bahşişi)` : ''}${relationExtra ? ` · +${relationExtra} ilişki puanı` : ''}` };
  }

  // Reddetmek o kişiyle ilişkiyi %2 azaltır (1 teslim = %10; en az %0)
  hurtRelation(who) {
    const c = this.state.customers[who];
    if (!c) return 0;
    const before = c.delivered;
    c.delivered = Math.max(0, Math.round((c.delivered - REJECT_REL) * 100) / 100);
    let hearts = Math.min(HEART_MAX, Math.floor(c.delivered / HEART_EVERY + 1e-9));
    if (this.fx('firstHeart') && c.delivered >= 1) hearts = Math.max(1, hearts);
    c.hearts = Math.min(c.hearts, hearts);
    return before - c.delivered;
  }

  relation(who) {
    const c = this.state.customers[who];
    return c ? Math.min(100, Math.round(c.delivered * 10)) : 0;
  }

  rejectOrder(id) {
    const ord = this.findOrder(id);
    if (!ord) return this.fail('Sipariş bulunamadı.');
    const hurt = ord.special ? 0 : this.hurtRelation(ord.who);
    const relMsg = hurt > 0 ? ` ${ord.who} ile ilişkin %2 azaldı.` : '';
    if (ord.status === 'accepted') {
      // Kabul edilmiş siparişten vazgeçmek de ceza getirir
      const fine = Math.round(ord.reward * ORDER_PENALTY);
      this.state.coins = Math.max(0, this.state.coins - fine);
      this.state.orders.list = this.state.orders.list.filter((x) => x.id !== id);
      this.save();
      return { ok: true, msg: `Siparişten vazgeçtin. -${fine} 🪙 ceza.${relMsg}` };
    }
    this.state.orders.list = this.state.orders.list.filter((x) => x.id !== id);
    this.save();
    return { ok: true, msg: `Sipariş reddedildi.${relMsg}` };
  }

  swapOrder(id) {
    const ord = this.findOrder(id);
    if (!ord || ord.status !== 'open') return this.fail('Sadece açık siparişler değiştirilebilir.');
    if (this.state.coins < ORDER_SWAP_COST) return this.fail(`Yeterli jeton yok (${ORDER_SWAP_COST} gerekli).`);
    const fresh = this.makeOrder();
    if (!fresh) return this.fail('Ekili çiçek yok, yeni sipariş gelmez.');
    this.state.coins -= ORDER_SWAP_COST;
    const i = this.state.orders.list.findIndex((x) => x.id === id);
    this.state.orders.list[i] = fresh;
    this.save();
    return { ok: true, msg: `Yeni sipariş geldi: ${fresh.who} (-${ORDER_SWAP_COST} 🪙).` };
  }

  ordersView() {
    const o = this.state.orders;
    const now = this.state.gameMs;
    const rates = Object.values(this.state.hives).reduce((sum, hive) => {
      const byFlower = this.hiveRates(hive.id);
      for (const [flower, rate] of Object.entries(byFlower)) {
        const room = Math.max(0, hive.capKg - this.hiveTotal(hive));
        sum[flower] = (sum[flower] || 0) + (room >= 0.05 ? rate : 0);
      }
      return sum;
    }, {});
    return {
      list: o.list.map((x) => ({
        ...x,
        penalty: Math.round(x.reward * ORDER_PENALTY),
        leftMs: x.deadline ? Math.max(0, x.deadline - now) : null,
        have: this.state.storage[x.flower] || 0,
        estimateDays: (() => {
          const available = (this.state.storage[x.flower] || 0)
            + Object.values(this.state.hives).reduce((sum, h) => sum + (h.honey[x.flower] || 0), 0);
          const missing = Math.max(0, x.kg - available);
          return !missing ? 0 : (rates[x.flower] || 0) > 0
            ? missing / (rates[x.flower] * DAY_GAME_MS / HOUR_MS) : null;
        })()
      })),
      nextInMs: o.list.filter((x) => !x.special).length >= this.orderMax() ? null : Math.max(0, (o.nextAtReal || Date.now() + ORDER_EVERY_REAL_MS) - Date.now()),
      realTime: true,
      max: this.orderMax(),
      swapCost: ORDER_SWAP_COST,
      planted: this.plantedFlowers().length
    };
  }

  // --- Net değer ve rakipler ---------------------------------------------------
  hiveValue(h) { return Math.round(HIVE_COST * 0.5 + (h.invested || 0) * 0.5 + h.bees * 5); }

  netWorth() {
    let v = this.state.coins;
    for (const [f, kg] of Object.entries(this.state.storage)) v += kg * this.price(f);
    for (const h of Object.values(this.state.hives)) v += this.hiveValue(h) + this.hiveTotal(h) * this.price('yonca') * 0.5;
    v += (this.state.tilesBought || 0) * 20 + (this.state.candles || 0) * this.candlePrice();
    return Math.round(v);
  }

  // Günlük rakip çiftlikleri: tekrar çağrı aynı günü iki kez üretmez.
  rollRivals(day = this.dayIndex()) {
    if (this.state.rivalsLastDay != null && day <= this.state.rivalsLastDay) return;
    const season = SEASONS[Math.floor(day / DAYS_PER_SEASON) % 4];
    const weather = WEATHER[this.state.weather] || WEATHER.bulutlu;
    const price = this.price('yonca');
    const marketMult = this.state.market.mult.yonca || 1;
    const me = this.netWorth();
    this.state.nwHistory = [...(this.state.nwHistory || []), me].slice(-HISTORY_NW);
    for (const r of this.state.rivals) {
      const st = RIVAL_STYLE[r.id];
      if (!st || !r.farm) continue;
      const f = r.farm;
      const rnd = rivalRandom(day, r.id);
      const notes = [];
      // Çiçek erişimi ile hava/mevsim etkisi oyuncunun çarpanlarından gelir.
      const winter = season === 'kis' ? (f.syrupDays > 0 ? WINTER_SYRUP_FACTOR : WINTER_FACTOR) : 1;
      const seasonalFlower = season === 'kis' || season === 'sonbahar' ? OUT_OF_SEASON : 1;
      const produced = Math.min(f.hives * 20, f.hives * f.bees * BASE_KG_PER_BEE_HOUR *
        (1 + f.buff) * weather.mult * winter * seasonalFlower * (DAY_GAME_MS / HOUR_MS) * (.9 + rnd() * .2));
      f.honey += produced;
      f.seasonProduction = (f.seasonProduction || 0) + produced;
      if (marketMult >= st.sellAt && f.honey > 0) {
        const sold = f.honey * st.sellShare;
        f.coins += sold * price;
        f.honey -= sold;
        if (st.sellAt > 1) notes.push({ good: true, text: 'yüksek fiyattan bal sattı' });
      }
      if (season === 'kis') {
        if (f.syrupDays <= 0 && rnd() < st.syrupChance && f.coins >= SYRUP_COST * f.hives) {
          f.coins -= SYRUP_COST * f.hives;
          f.syrupDays = 6;
          notes.push({ good: true, text: 'kış için şurup aldı' });
        }
        if (f.syrupDays > 0) f.syrupDays--;
        else if (f.bees > 4) { f.bees--; notes.push({ good: false, text: 'şurupsuz kaldı, arı kaybetti' }); }
      } else if (rnd() < st.sick && f.bees > 4) {
        f.bees = Math.max(4, f.bees - 2);
        notes.push({ good: false, text: 'kovanları hastalandı, arı kaybetti' });
      }
      const gap = me > 0 ? r.nw / me : 1;
      const budget = f.coins * st.invest * (gap > 1.5 ? .5 : gap < .7 ? 1.3 : 1);
      if (f.coins > st.investAt && season !== 'kis') {
        if (f.bees < 20) {
          const count = Math.min(20 - f.bees, Math.floor(budget / 40));
          if (count > 0) { f.bees += count; f.coins -= count * 40; notes.push({ good: true, text: `${count} arı aldı` }); }
        } else if (budget >= HIVE_COST && f.coins >= HIVE_COST) {
          // Kovan başına ortalama arı sayısı; yeni kovan boşluktan değer üretmez.
          f.bees = Math.max(4, Math.round((f.bees * f.hives) / (f.hives + 1)));
          f.hives++;
          f.coins -= HIVE_COST;
          notes.push({ good: true, text: 'yeni bir kovan kurdu' });
        }
      }
      const before = r.nw;
      // Oyuncunun hiveValue mantığı: kurulum yatırımının yarısı + arı değeri.
      r.nw = Math.max(50, Math.round(f.coins + f.honey * price +
        f.hives * (HIVE_COST * .5 + f.bees * 5)));
      r.last = before ? (r.nw - before) / before : 0;
      r.history = [...(r.history || []), r.nw].slice(-HISTORY_NW);
      r.reason = notes.length ? notes[notes.length - 1].text : (produced > 0 ? 'bal üretti' : 'sakin bir gün');
      r.reasonGood = notes.length ? notes[notes.length - 1].good : true;
      if (notes.length && Math.abs(r.last) >= .05) {
        const def = RIVALS.find((x) => x.id === r.id);
        this.events.push({ msg: `${def.name}: ${r.reason} (${r.last >= 0 ? '+' : '-'}%${Math.round(Math.abs(r.last) * 100)})`, err: !r.reasonGood });
      }
    }
    this.state.rivalsLastDay = day;
  }

  leaderboard() {
    const me = this.netWorth();
    const hist = this.state.nwHistory || [];
    // Rakiplerle aynı ölçü: bugünün başındaki değer ile dünün başındaki değer
    const meLast = hist.length >= 2 ? (hist[hist.length - 1] - hist[hist.length - 2]) / (hist[hist.length - 2] || 1) : 0;
    const rows = [
      { id: 'me', name: 'Sen', style: 'Oyuncu', nw: me, last: meLast, history: [...hist, me].slice(-HISTORY_NW),
        cups: this.state.festival.cups.reduce((sum, c) => ({ ...sum, [c.cup]: (sum[c.cup] || 0) + 1 }), {}), me: true },
      ...this.state.rivals.map((r) => {
        const def = RIVALS.find((x) => x.id === r.id);
        return { id: r.id, name: def.name, style: def.style, nw: r.nw, last: r.last, history: r.history, reason: r.reason || '', reasonGood: r.reasonGood !== false, hives: r.farm ? r.farm.hives : 0, cups: r.cups || {}, me: false };
      })
    ];
    rows.sort((a, b) => b.nw - a.nw);
    return rows.map((r, i) => ({ ...r, rank: i + 1 }));
  }

  // Son 20 bildirim kalıcı olarak tutulur (sol alttaki zil paneli)
  logNotifs(events) {
    if (!events.length) return;
    const list = this.state.notifs || [];
    for (const e of events) if (e.msg) list.push({ t: Date.now(), msg: e.msg, err: !!e.err, go: e.go || this.notifTarget(e.msg) });
    this.state.notifs = list.slice(-NOTIF_KEEP);
    this.state.notifsUnread = Math.min(NOTIF_KEEP, (this.state.notifsUnread || 0) + events.filter((e) => e.msg).length);
  }

  // Bildirime tıklayınca açılacak yer (mesajın içeriğinden çıkarılır)
  notifTarget(msg) {
    if (msg.startsWith('✉️')) return { to: 'letters' };
    if (msg.startsWith('🛒')) return { to: 'merchant' };
    if (msg.startsWith('📜') || msg.includes('Sipariş')) return { to: 'orders' };
    if (/^(🏘️|🏪|🏛️|📖|🌟)/u.test(msg)) return { to: 'village' };
    if (msg.includes('Festival') || msg.includes('festival') || msg.includes('turnuva')) return { to: 'market' };
    const hive = Object.values(this.state.hives).find((h) => msg.includes(h.name));
    if (hive) return { to: 'hive', id: hive.id };
    return null;
  }

  readNotifs() { this.state.notifsUnread = 0; this.save(); return { ok: true, msg: '' }; }

  drainEvents() { const e = this.events; this.events = []; this.logNotifs(e); return e; }

  // --- Arıcı: evden kovana yürür, 5 sn çalışır, sonra sıradaki kovana geçer --
  houseKey() {
    for (const [k, t] of Object.entries(this.state.tiles)) if (t.item && t.item.type === 'house') return k;
    return '0,0';
  }

  storageKey() {
    return Object.keys(this.state.tiles).find((k) => this.state.tiles[k].kind === 'storage') || this.houseKey();
  }

  walkMs(fromKey, toKey) {
    const [q1, r1] = parse(fromKey);
    const [q2, r2] = parse(toKey);
    const d = hexDist(q2 - q1, r2 - r1);
    return Math.max(1200, d * WALK_MS_PER_TILE);
  }

  startNextJob(now, fromKey) {
    const kp = this.state.keeper;
    while (kp.queue.length) {
      const hiveId = kp.queue.shift();
      const to = this.hiveTileKey(hiveId);
      if (!to) continue;
      const walk = this.walkMs(fromKey, to);
      kp.job = { kind: 'harvest', hiveId, from: fromKey, to, startAt: now, arriveAt: now + walk, doneAt: now + walk + WORK_MS };
      this.events.push({ msg: `Arıcı ${this.state.hives[hiveId].name}'e gidiyor…` });
      return;
    }
    const home = kp.carrying ? this.storageKey() : this.houseKey();
    if (fromKey !== home) {
      const walk = this.walkMs(fromKey, home);
      kp.job = { kind: 'home', from: fromKey, to: home, startAt: now, arriveAt: now + walk, doneAt: now + walk };
    } else {
      kp.job = null;
    }
  }

  processKeeper(now) {
    const kp = this.state.keeper;
    if (!kp.job) {
      if (kp.queue.length) { this.startNextJob(now, this.houseKey()); return true; }
      return false;
    }
    if (now < kp.job.doneAt) return false;
    const job = kp.job;
    if (job.kind === 'harvest') {
      const r = this.harvestHive(job.hiveId);
      if (r.ok) kp.carrying = true;
      this.events.push({ msg: r.msg, err: !r.ok });
    } else if (job.kind === 'home') {
      kp.carrying = false;
    }
    this.startNextJob(now, job.to);
    this.save();
    return true;
  }

  isQueued(hiveId) {
    const kp = this.state.keeper;
    return kp.queue.includes(hiveId) || (kp.job && kp.job.kind === 'harvest' && kp.job.hiveId === hiveId);
  }

  requestHarvest(hiveId) {
    const hive = this.state.hives[hiveId];
    if (!hive) return this.fail('Kovan bulunamadı.');
    if (this.isQueued(hiveId)) return this.fail('Arıcı zaten bu kovana gidiyor.');
    if (this.hiveTotal(hive) < 0.05) return this.fail('Hasat edilecek bal yok.');
    this.state.keeper.queue.push(hiveId);
    this.processKeeper(Date.now());
    this.save();
    return { ok: true, msg: '' };
  }

  // --- Arı alım/satım -----------------------------------------------------
  beeNumberPrice(number) {
    return Math.max(1, BEE_PRICE_BASE + (Number(number) - BEE_PRICE_BASE_NUMBER) * BEE_PRICE_STEP);
  }

  beePrice(h) { return this.beeNumberPrice(h.bees + 1); }
  beeSellPrice(h) { return Math.floor(this.beeNumberPrice(h.bees) / 2); }

  buyBee(hiveId) {
    const h = this.state.hives[hiveId];
    if (!h) return this.fail('Kovan bulunamadı.');
    if (h.bees >= h.capBees) return this.fail('Kovan dolu. Kraliçeyi yükselterek yer aç.');
    const price = this.beePrice(h);
    if (this.state.coins < price) return this.fail(`Yeterli jeton yok (${price} gerekli).`);
    this.state.coins -= price;
    h.bees += 1;
    h.beesBought += 1;
    h.invested += price;
    this.questEvent('buyBee', { hiveId });
    this.save();
    return { ok: true, msg: `Yeni bir arı aldın (-${price} 🪙).` };
  }

  sellBee(hiveId) {
    const h = this.state.hives[hiveId];
    if (!h) return this.fail('Kovan bulunamadı.');
    if (h.bees <= 1) return this.fail('Kovanda en az bir arı kalmalı.');
    const gain = this.beeSellPrice(h);
    h.bees -= 1;
    this.state.coins += gain;
    this.save();
    return { ok: true, msg: `Bir arı sattın (+${gain} 🪙).` };
  }

  // --- Yükseltmeler ---------------------------------------------------------
  nextUpgrade(h) { return UPGRADES[h.level] || null; }

  upgrade(hiveId) {
    const h = this.state.hives[hiveId];
    if (!h) return this.fail('Kovan bulunamadı.');
    const u = this.nextUpgrade(h);
    if (!u) return this.fail('Bu kovan tamamen gelişti.');
    if (this.state.coins < u.cost) return this.fail(`Yeterli jeton yok (${u.cost} gerekli).`);
    this.state.coins -= u.cost;
    h.invested += u.cost;
    h.level += 1;
    if (u.type === 'queen') {
      this.questEvent('upgrade', { kind: 'queen', hiveId });
      h.queens += 1;
      h.capBees = u.capBees;
      if (u.capBees >= 20) this.milestone('kovan_20', `${h.name} 20 arılık dev bir kovan oldu`);
      this.save();
      return { ok: true, msg: `${QUEEN_NAMES[h.queens]} geldi! Kapasite ${u.capBees} arı.` };
    }
    h.capKg = u.capKg;
    this.questEvent('upgrade', { kind: 'hive', hiveId });
    this.save();
    return { ok: true, msg: `Kovan büyüdü: artık ${u.capKg} kg bal alıyor.` };
  }

  giveSyrup(hiveId) {
    const h = this.state.hives[hiveId];
    if (!h) return this.fail('Kovan bulunamadı.');
    const syrupCost = this.syrupCost();
    if (this.state.coins < syrupCost) return this.fail(`Yeterli jeton yok (${syrupCost} gerekli).`);
    this.state.coins -= syrupCost;
    h.syrup += SYRUP_KG;
    this.state.ledger.syrupGiven += 1;
    this.questEvent('syrup', { hiveId });
    this.save();
    return { ok: true, msg: `${h.name}: +${SYRUP_KG} kg kış erzakı.` };
  }

  sellValue(h) { return Math.round((h.invested || 0) * 0.5 + h.bees * 5); }

  sellHive(hiveId) {
    const h = this.state.hives[hiveId];
    if (!h) return this.fail('Kovan bulunamadı.');
    if (Object.keys(this.state.hives).length <= 1) return this.fail('Son kovanını satamazsın.');
    const k = this.hiveTileKey(hiveId);
    const gain = this.sellValue(h);
    this.state.coins += gain;
    if (k) this.state.tiles[k].item = null;
    delete this.state.hives[hiveId];
    const kp = this.state.keeper;
    kp.queue = kp.queue.filter((id) => id !== hiveId);
    this.save();
    return { ok: true, msg: `${h.name} satıldı (+${gain} 🪙).` };
  }

  // --- Oyuncu eylemleri ---------------------------------------------------
  fail(msg) { return { ok: false, msg }; }

  // Sahip olunan bir kareye komşu mu (satın alınabilir mi)
  isBuyable(k) {
    const t = this.state.tiles[k];
    if (!t || t.owned || t.kind !== 'grass') return false;
    return DIRS.some(([dq, dr]) => {
      const n = this.state.tiles[key(t.q + dq, t.r + dr)];
      return n && n.owned;
    });
  }

  tilePrice() { return Math.round(60 * Math.pow(1.4, this.state.tilesBought)); }

  buyTile(k) {
    if (!this.isBuyable(k)) return this.fail('Bu kare satın alınamaz.');
    const price = this.tilePrice();
    if (this.state.coins < price) return this.fail(`Yeterli jeton yok (${price} gerekli).`);
    this.state.coins -= price;
    this.state.tilesBought += 1;
    const t = this.state.tiles[k];
    t.owned = true;
    t.tree = false;
    this.save();
    return { ok: true, msg: `Yeni kare alındı (-${price} 🪙).` };
  }

  placeHive(k) {
    const t = this.state.tiles[k];
    if (!t || !t.owned || t.item || t.kind !== 'grass') return this.fail('Buraya kovan konamaz.');
    const cost = this.nextHiveCost();
    if (this.state.coins < cost) return this.fail(`Yeterli jeton yok (${cost} gerekli).`);
    this.state.coins -= cost;
    const id = uid();
    const n = Object.keys(this.state.hives).length + 1;
    this.state.hives[id] = newHive(id, `Kovan ${n}`, 4, cost);
    this.state.hives[id].undoPending = true;
    this.state.hivesPurchased++;
    t.item = { type: 'hive', id };
    this.state.undoPlacement = { kind: 'hive', key: k, id, cost, expiresAt: Date.now() + 10000 };
    this.save();
    return { ok: true, msg: `${this.state.hives[id].name} kuruldu (-${cost} 🪙).` };
  }

  nextHiveCost() { return Math.round(HIVE_COST * 1.25 ** Math.max(0, this.state.hivesPurchased || 0) / 25) * 25; }

  commitPlacement() {
    const pending = this.state.undoPlacement;
    if (!pending) return;
    const tile = this.state.tiles[pending.key];
    if (tile?.item) delete tile.item.undoPending;
    if (pending.kind === 'hive' && this.state.hives[pending.id]) {
      delete this.state.hives[pending.id].undoPending;
      this.questEvent('placeHive', { hiveId: pending.id });
    } else if (pending.kind === 'flower') this.questEvent('plant', { flower: pending.flower });
    this.state.undoPlacement = null;
    this.save();
  }

  undoPlacement() {
    const pending = this.state.undoPlacement;
    if (!pending || Date.now() > pending.expiresAt) return this.fail('Geri alma süresi doldu.');
    const tile = this.state.tiles[pending.key];
    if (!tile?.item) return this.fail('Yerleştirme artık geri alınamaz.');
    tile.item = null;
    this.state.coins += pending.cost;
    if (pending.kind === 'hive') { delete this.state.hives[pending.id]; this.state.hivesPurchased--; }
    else if (pending.free) this.state.vouchers[pending.flower] = (this.state.vouchers[pending.flower] || 0) + 1;
    this.state.undoPlacement = null;
    this.save();
    return { ok: true, msg: 'Son yerleştirme geri alındı.' };
  }

  buySeed(flower) {
    const def = FLOWERS[flower];
    if (!def) return this.fail('Bilinmeyen tohum.');
    const seedCost = this.seedCost(flower);
    if (this.state.coins < seedCost) return this.fail(`Yeterli jeton yok (${seedCost} gerekli).`);
    this.state.coins -= seedCost;
    this.state.vouchers[flower] = (this.state.vouchers[flower] || 0) + 1;
    this.save();
    return { ok: true, msg: `${def.name} tohumu envantere eklendi (-${seedCost} 🪙). Envanter: ${this.state.vouchers[flower]}` };
  }

  plantSeed(k, flower) {
    const t = this.state.tiles[k];
    const def = FLOWERS[flower];
    if (!def) return this.fail('Bilinmeyen tohum.');
    if (!t || !t.owned || t.item || t.kind !== 'grass') return this.fail('Buraya tohum ekilemez.');
    const free = (this.state.vouchers[flower] || 0) > 0;
    const seedCost = this.seedCost(flower);
    if (!free && this.state.coins < seedCost) return this.fail(`Yeterli jeton yok (${seedCost} gerekli).`);
    if (free) this.state.vouchers[flower] -= 1; else this.state.coins -= seedCost;
    t.item = { type: 'flower', flower, plantedDay: this.dayIndex(), wilted: false, undoPending: true };
    this.state.undoPlacement = { kind: 'flower', key: k, flower, cost: free ? 0 : seedCost, free, expiresAt: Date.now() + 10000 };
    this.save();
    return { ok: true, msg: free ? `${def.name} hediye tohumla ekildi 🎁` : `${def.name} ekildi (-${seedCost} 🪙).` };
  }

  replant(k) {
    const t = this.state.tiles[k];
    if (!t || !t.item || t.item.type !== 'flower') return this.fail('Burada çiçek yok.');
    const def = FLOWERS[t.item.flower];
    const wasWilted = !!t.item.wilted;
    const seedCost = wasWilted ? this.reviveCost(t.item.flower) : this.seedCost(t.item.flower);
    if (this.state.coins < seedCost) return this.fail(`Yeterli jeton yok (${seedCost} gerekli).`);
    this.state.coins -= seedCost;
    t.item.plantedDay = this.dayIndex();
    t.item.wilted = false;
    this.questEvent('plant', { flower: t.item.flower });
    if (wasWilted) this.questEvent('revive', { flower: t.item.flower });
    this.save();
    return { ok: true, msg: `${def.name} yeniden canlandı (-${seedCost} 🪙).` };
  }

  reviveAll() {
    const wilted = Object.values(this.state.tiles).filter((t) => t.item?.type === 'flower' && t.item.wilted);
    if (!wilted.length) return this.fail('Canlandırılacak solmuş çiçek yok.');
    const cost = wilted.reduce((sum, t) => sum + this.reviveCost(t.item.flower), 0);
    if (this.state.coins < cost) return this.fail(`Tümünü canlandırmak için ${cost} jeton gerekli.`);
    this.state.coins -= cost;
    for (const t of wilted) {
      t.item.plantedDay = this.dayIndex(); t.item.wilted = false;
      this.questEvent('plant', { flower: t.item.flower });
      this.questEvent('revive', { flower: t.item.flower });
    }
    this.save();
    return { ok: true, msg: `${wilted.length} tarh canlandı (-${cost} 🪙).` };
  }

  removeFlower(k) {
    const t = this.state.tiles[k];
    if (!t || !t.item || t.item.type !== 'flower') return this.fail('Burada çiçek yok.');
    t.item = null;
    this.save();
    return { ok: true, msg: 'Tarh temizlendi.' };
  }

  // 1. aşamada anında hasat; arıcının yürüyüşü 2. aşamada gelecek.
  harvestHive(hiveId) {
    const hive = this.state.hives[hiveId];
    if (hive) this.lastHoney = { ...hive.honey };
    if (!hive) return this.fail('Kovan bulunamadı.');
    const total = this.hiveTotal(hive);
    if (total < 0.05) return this.fail('Hasat edilecek bal yok.');
    const stored = Object.values(this.state.storage).reduce((a, b) => a + b, 0);
    const room = this.state.storageCap - stored;
    if (room <= 0.05) return this.fail('Depo dolu.');
    const scale = Math.min(1, room / total);
    let moved = 0;
    for (const [f, kg] of Object.entries(hive.honey)) {
      const take = kg * scale;
      this.state.storage[f] = (this.state.storage[f] || 0) + take;
      hive.honey[f] = kg - take;
      if (hive.honey[f] < 0.001) delete hive.honey[f];
      moved += take;
    }
    const fx = this.state.merchantEffects || {};
    const glove = moved > 0.01 && (fx.waxGloveHarvests || 0) > 0;
    const wax = moved * WAX_PER_KG * (glove ? 1.5 : 1);
    if (glove) fx.waxGloveHarvests -= 1;
    this.state.wax += wax;
    this.recordHarvest(hive, moved, scale);
    this.save();
    return { ok: true, msg: `+${moved.toFixed(1)} kg bal depoya eklendi (+${Math.round(wax * 1000)} g balmumu).`, kg: moved };
  }

  harvestAll() {
    let n = 0;
    for (const h of Object.values(this.state.hives)) {
      if (this.hiveTotal(h) >= 0.05 && !this.isQueued(h.id)) { this.state.keeper.queue.push(h.id); n += 1; }
    }
    if (!n) return this.fail('Hasat edilecek bal yok.');
    this.processKeeper(Date.now());
    this.save();
    return { ok: true, msg: n > 1 ? `Arıcı ${n} kovanı sırayla hasat edecek.` : '' };
  }

  setSpeed(speed) {
    if (![0, 1, 2, 4].includes(speed)) return this.fail('Geçersiz hız.');
    this.state.speed = speed;
    this.save();
    return { ok: true };
  }

  // --- Pencereye gönderilen görünüm -----------------------------------------
  view() {
    const s = this.state;
    const storageKg = Object.values(s.storage).reduce((a, b) => a + b, 0);
    const hives = {};
    for (const h of Object.values(s.hives)) {
      const rates = this.hiveRates(h.id);
      hives[h.id] = {
        ...h,
        immuneDays: Math.max(0, (h.immuneUntil || 0) - this.dayIndex()),
        sickDeaths: h.sickDeaths || 0,
        sickDeathLimit: h.sick ? this.sicknessDeathLimit(h) : 0,
        total: this.hiveTotal(h),
        ratePerHour: Object.values(rates).reduce((a, b) => a + b, 0),
        near: this.flowersNear(this.hiveTileKey(h.id) || '0,0'),
        queenName: QUEEN_NAMES[h.queens] || QUEEN_NAMES[0],
        nextQueenName: QUEEN_NAMES[h.queens + 1] || null,
        next: this.nextUpgrade(h),
        beePrice: this.beePrice(h),
        beeSellPrice: this.beeSellPrice(h),
        sellValue: this.sellValue(h),
        feedDays: this.feedDays(h),
        boostDays: Math.max(0, (h.boostUntilDay || 0) - this.dayIndex()),
        queued: !!this.isQueued(h.id)
      };
    }
    return {
      coins: s.coins,
      speed: s.speed,
      storage: s.storage,
      storageKg,
      storageCap: s.storageCap,
      storageBaseCap: s.storageBaseCap,
      calendar: this.calendar(),
      tiles: s.tiles,
      hives,
      tilePrice: this.tilePrice(),
      hiveCost: this.nextHiveCost(),
      syrupCost: this.syrupCost(),
      winterSyrupCost: this.winterHungryHives().length * this.syrupCost(),
      syrupKg: SYRUP_KG,
      keeper: this.state.keeper,
      undoPlacement: this.state.undoPlacement,
      market: this.prices(),
      marketForecast: (() => {
        const fc = this.state.merchantEffects && this.state.merchantEffects.marketForecast;
        if (!fc || !fc.reveal || !fc.nextMult) return null;
        return {
          forDay: fc.forDay,
          rows: fc.reveal.map((flower) => ({
            flower,
            direction: fc.nextMult[flower] >= this.state.market.mult[flower] ? 'up' : 'down'
          }))
        };
      })(),
      orders: this.ordersView(),
      weather: { id: this.state.weather, ...(WEATHER[this.state.weather] || WEATHER.bulutlu) },
      tutorialDone: this.state.tutorialDone,
      medicineCost: this.medicineCost(),
      focusBoostLeftMs: Math.max(0, (this.state.focusBoostUntil || 0) - Date.now()),
      focusBoost: FOCUS_BOOST,
      customers: this.state.customers,
      heartMax: HEART_MAX,
      vouchers: this.state.vouchers,
      decor: Object.fromEntries(Object.entries(DECOR).map(([k, d]) => [k, { ...d, cost: this.decorCost(k) }])),
      breeds: BREEDS,
      breedChangeCost: BREED_CHANGE_COST,
      wax: this.state.wax,
      candles: this.state.candles,
      candleWax: (this.state.merchantEffects && this.state.merchantEffects.waxPressUses > 0) ? 0.3 : CANDLE_WAX,
      candlePrice: this.candlePrice(),
      festival: { open: this.festivalOpen(), entry: this.state.festival.entry, cups: this.state.festival.cups,
        results: this.state.festival.results || [], nextInDays: DAYS_PER_SEASON - this.calendar().day + 1,
        nextSeason: SEASON_NAMES[this.calendar().season], maxKg: FESTIVAL_MAX_KG },
      flowerLife: FLOWER_LIFE_DAYS + this.fx('flowerLife'),
      dayIndex: this.dayIndex(),
      clusterBonus: CLUSTER_BONUS,
      clusterTiles: Object.fromEntries(Object.entries(this.state.tiles)
        .filter(([, t]) => t.item && t.item.type === 'flower').map(([k]) => [k, this.clusterBonus(k) > 0])),
      leaderboard: this.leaderboard(),
      farmName: this.state.farmName,
      quests: (this.ensureQuests(), this.state.quests.list.map((q) => ({ ...q, text: this.questText(q) }))),
      questRefresh: { free: this.state.quests.refreshFree, paidUsed: this.state.quests.paidUsed, paidCost: 100 },
      questsDone: this.state.questsDone,
      ledger: this.state.ledger,
      history: this.state.history,
      today: {
        produced: Math.round((this.state.counters.produced - this.dayStart.produced) * 10) / 10,
        earned: Math.round(this.state.counters.earned - this.dayStart.earned),
        sold: this.soldSince(this.dayStart.soldBy)
      },
      label: this.state.label,
      labelDesigns: LABEL_DESIGNS,
      labelBonus: LABEL_BONUS,
      milestones: this.state.milestones,
      merchant: this.merchantView(),
      letters: this.state.letters.slice().reverse(),
      lettersUnread: this.state.letters.filter((l) => !l.read).length,
      gameSettings: this.state.gameSettings,
      syrupAllCost: this.syrupAllCost(),
      hints: this.hints(),
      stories: this.storiesView(),
      effects: this.effectsView(),
      notifs: (this.state.notifs || []).slice().reverse(),
      notifsUnread: this.state.notifsUnread || 0,
      reviveRate: REVIVE_RATE,
      soldTotalKg: Math.round((Object.values(this.state.ledger.honey).reduce((a, x) => a + (x.soldKg || 0), 0) + (this.state.village ? this.state.village.deliveredKg : 0)) * 10) / 10,
      relations: Object.fromEntries(Object.keys(this.state.customers).map((n) => [n, this.relation(n)])),
      dayMs: DAY_GAME_MS,
      marketEvent: this.state.market.event,
      seasonPrice: SEASON_PRICE[this.calendar().season],
      nextStorage: (() => { const u = this.nextStorage(); if (!u) return null; const coupon = !!(this.state.merchantEffects && this.state.merchantEffects.storageCoupon); return { ...u, cost: Math.round(u.cost * (coupon ? 0.8 : 1)), baseCost: u.cost, coupon }; })(),
      houseKey: this.houseKey(),
      storageKey: this.storageKey(),
      now: Date.now(),
      flowers: Object.fromEntries(Object.entries(FLOWERS).map(([k, f]) => [k, { ...f, seed: this.seedCost(k) }])),
      village: this.villageView(),
      ezgi: {
        unlocked: this.ezgiUnlocked(),
        welcomePending: !!this.state.ezgiWelcomePending,
        welcomeClaimed: !!this.state.ezgiWelcomeClaimed,
        choice: this.ezgiChoice(),
        discount: 0.15
      },
      unattended: !!s.pauseStartedAt || Date.now() - s.lastSeenAt >= UNATTENDED_CAP_MS
    };
  }
}

module.exports = { BeeGame, FLOWERS, freshState };
