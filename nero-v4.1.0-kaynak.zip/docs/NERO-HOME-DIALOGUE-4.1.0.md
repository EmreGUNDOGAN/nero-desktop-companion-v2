# NERO — Ana Sayfa Konuşma Sistemi
## Nihai içerik + teknik uygulama şartnamesi

**Hedef:** Nero'nun ana sayfadaki konuşma kartını uzun süreli kullanıma uygun, tekrar etmeyen, bağlama duyarlı ve test edilebilir bir konuşma sistemine dönüştürmek.

**Bu dosyadaki onaylı ana sayfa replik sayısı: 665**

| Kategori | Adet |
|---|---:|
| General / Günlük Nero | 140 |
| Roast / Laf Sokma | 70 |
| Motivasyon | 70 |
| Şefkat / Arkadaşlık | 60 |
| Absürt / Piksel Varoluşu | 80 |
| Üretkenlik / Bağlamsal | 80 |
| Saat / Gün / Gece | 65 |
| İlişki / Birlikte Geçirilen Süre | 35 |
| Nadir / Ultra Nadir | 45 |
| Geri Dönüş / Uzun Yokluk | 20 |
| **TOPLAM** | **665** |

> **Önemli kapsam kararı:** Övgü/Takdir replikleri ana sayfa havuzundan çıkarılmıştır. Bunlar daha sonra görev tamamlama, odak tamamlama, achievement açma vb. **event/reaction** anlarında ayrı bir sistem olarak ele alınacaktır.

---

# 1. Mevcut v4.0.4 kodunda değiştirilecek noktalar

Kaynakta mevcut davranış şu şekildedir:

- `src/main/main.js` içindeki `buildHome()` ana sayfa Nero repliğini seçiyor.
- `showPanel()` her panel açılışında `buildHome()` çağırıyor. Bu nedenle paneli kapatıp açmak repliği değiştiriyor.
- `src/renderer/panel/index.html` içinde `#home-refresh` yenile butonu bulunuyor.
- `src/renderer/panel/panel.js` bu butonda `home:refresh` IPC çağrısı yapıyor.
- `src/main/main.js` içindeki `home:refresh` handler'ı `quoteOffset` artırıp `buildHome()` çağırıyor.
- Mevcut `Dialogue.pick()` sistemi kategori başına yalnızca 1–5 yakın geçmiş öğeyi bellekte tutuyor; 665 repliklik Home sistemi için bu yeterli değildir.
- `TALK_INTERVALS` + `nextTalkAt` sistemi masaüstündeki **karakter konuşma balonu** içindir. Yeni Home sistemi bununla birleştirilmemelidir.

## Yapılacak değişiklik

Ana sayfa konuşmaları için **ayrı bir Home Dialogue Engine** oluşturulmalıdır. Önerilen dosyalar:

- `src/data/home-dialogues.tr.js` veya `src/data/home-dialogues.tr.json` — replik verisi
- `src/main/home-dialogue.js` — seçim motoru, koşul kontrolü, rarity, anti-repeat, scheduler
- `src/main/main.js` — HomeDialogueEngine başlatma, state gönderimi, gerekli event hook'ları

Mevcut `dialogue.js` masaüstü konuşma balonları için çalışmaya devam etmelidir. Böylece iki sistemi birbirine bağlayan bir hata Nero'nun normal davranışlarını bozmaz.

---

# 2. Kesin ürün kararları

1. **Ana sayfadaki ↻ yenile butonu kaldırılacak.** Kullanıcı replikleri spamlayarak tüketemeyecek.
2. Yeni Home repliği **rastgele 5–10 dakika** aralığında seçilecek. Sabit 5 veya 10 dakika kullanılmayacak.
3. Scheduler **ana sayfa/panel açık olmasına bağlı olmayacak.** Nero uygulaması normal biçimde çalışırken arka planda akacak.
4. Panel açıldığında yeni replik üretmek yerine o anda seçilmiş güncel Home repliği gösterilecek.
5. Eski replik yenisi seçilene kadar korunacak; UI'da boşluk oluşmayacak.
6. Replik değişimi sakin bir **fade** geçişiyle yapılacak.
7. Son **20 Home repliği global olarak tekrar seçilmeyecek.**
8. Aynı kategori art arda en fazla **2 kez** seçilecek; başka uygun kategori yoksa sistem kilitlenmemek için bu kuralı esnetebilir.
9. Kullanıcı aktif odak seansındayken Home konuşmaları dikkat dağıtmamalı. Öneri: scheduler yeni seçim zamanını erteleyebilir; mevcut Home repliği kalır. Masaüstündeki timer/event tepkileri bundan bağımsızdır.
10. Konuşma kartı tıklamayla kapatılmaz veya boşaltılmaz; replik yalnız scheduler yeni seçim yaptığında değişir.
11. Panelin açılıp kapanması, tab değiştirme veya Home'a tekrar dönme repliği değiştirmemelidir.
12. `Günün sözü / QUOTES` sistemi Home Nero repliğinden ayrıdır. Yenile butonu kaldırılırken günlük sözün günlük deterministik davranışı korunabilir; `quoteOffset` artık gereksizse kaldırılabilir.

---

# 3. En kritik mimari ayrım: STATE ve EVENT

## Home / STATE repliği

Ana sayfa **yalnızca şu anda doğrulanabilen mevcut durumu** yorumlar.

Doğru örnek:

> “Bugün {todos} iş bitmiş. Liste senden çekinmeye başlamış olabilir.”

Çünkü `today.todos` şu anda kontrol edilebilir.

## Event / Reaction repliği

Bir eylemin gerçekleştiği anda söylenen cümledir ve **Home havuzuna konmaz**.

Yanlış Home örneği:

> “İlk işi tamamladın. Gün resmen başladı.”

Bu ancak `todo_done` anında doğrudur. Kullanıcı ana sayfayı iki saat sonra açtığında bunun yeni olmuş gibi söylenmesi hatadır.

### Kural

- `todo_done`, `timer_done`, `achievement_unlocked`, `note_added`, `pet`, `wake`, `shake`, vb. → **event/reaction sistemi**
- `today.todos === 4`, `today.focus >= 60`, `streak >= 7`, `daysTogether >= 100`, saat aralığı, mevcut mood → **Home/state sistemi**

Bu dosyadaki 665 replik yalnızca **Home/state sistemi** içindir.

---

# 4. Önerilen Home replik veri modeli

```js
{
  id: 'home_productivity_012',
  category: 'productivity',
  text: 'Bugün {todos} iş bitmiş. Liste senden çekinmeye başlamış olabilir.',
  rarity: 'common',
  conditionTier: 'basic',
  conditions: {
    todayTodosMin: 6,
    todayTodosMax: 9
  },
  topic: 'todayTodos',
  topicCooldownMinutes: 90
}
```

## Zorunlu alanlar

- `id`: benzersiz ve kalıcı ID
- `category`: ana kategori
- `text`: gösterilecek metin
- `rarity`: `common | uncommon | rare | ultra_rare`
- `conditions`: yoksa `{}`

## İsteğe bağlı alanlar

- `conditionTier`: `basic | advanced`
- `topic`
- `topicCooldownMinutes`
- `minDisplayMs`
- `maxDisplayMs`
- `requiresSeen`: nadir replik panelde gerçekten gösterilmeden tüketilmiş sayılmasın
- `notes`: yalnızca geliştirici/debug için

### ID kuralı

ID metinden türetilmemelidir ve yayınlandıktan sonra değiştirilmemelidir.

Örnekler:

- `home_general_001`
- `home_roast_001`
- `home_motivation_001`
- `home_care_001`
- `home_absurd_001`
- `home_productivity_001`
- `home_time_001`
- `home_relationship_001`
- `home_rare_001`
- `home_return_001`

---

# 5. Scheduler — 5–10 dakika

Yeni Home scheduler karakterin mevcut `nextTalkAt` sisteminden bağımsız olmalıdır.

Önerilen state:

```js
let nextHomeDialogueAt = 0;
let currentHomeDialogue = null;
```

Önerilen planlama:

```js
function scheduleNextHomeDialogue() {
  nextHomeDialogueAt = Date.now() + rand(5, 10) * MIN;
}
```

### Çok önemli

`setInterval(..., 5 dakika)` kullanıp her 5 dakikada replik değiştirmek istenmiyor. Her seçimden sonra **yeni bir rastgele 5–10 dakikalık hedef zaman** hesaplanmalıdır.

Panel görünürlüğü scheduler koşulu değildir.

### Bilgisayar gerçekten kullanılmıyorken

Panel kapalıyken sistem akmaya devam eder. Ancak Windows kilitliyse veya mevcut Nero idle/uyku mantığı kullanıcıyı gerçekten uzakta kabul ediyorsa, özellikle `rare/ultra_rare` replikler görünmeden tüketilmemelidir. Güvenli davranış:

- normal replik scheduler'ı bekleyebilir veya ertelenebilir;
- rare/ultra-rare hiçbir zaman “görüldü” sayılmaz;
- kullanıcı geri geldiğinde uygunluk yeniden doğrulanır.

---

# 6. Seçim algoritmasının kesin sırası

Her yeni replik seçiminde sıra değişmemelidir:

1. Güncel context snapshot oluştur.
2. Tüm repliklerde `conditions` kontrol et ve **uygun adayları** oluştur.
3. Artık geçerli olmayan pending/current koşullu replikleri ayıkla.
4. Son 20 global ID'yi adaylardan çıkar.
5. Topic cooldown nedeniyle yasaklı adayları çıkar.
6. Aynı kategori son iki seçimde de kullanıldıysa, başka kategori varsa o kategoriyi geçici dışla.
7. Return gibi yüksek öncelikli bir state varsa öncelik uygula.
8. Rarity ağırlığını uygula.
9. Uygun adaylardan seçim yap.
10. Placeholder değerlerinin tamamının mevcut olduğunu doğrula.
11. Metni interpolate et.
12. `currentHomeDialogue` state'ini güncelle.
13. Recent ID/category geçmişine ekle.
14. Yeni 5–10 dakikalık süreyi planla.
15. Panel açıksa state push et; kapalıysa state saklanır ve panel açılınca aynı replik gösterilir.

**Koşul filtresinden önce rastgele seçim yapılmamalıdır.**

---

# 7. Context snapshot — tek kaynaktan okunmalı

Seçim motoru farklı yerlerden tekrar tekrar veri okumak yerine seçim başında tek bir snapshot üretmelidir.

Öneri:

```js
{
  now,
  localMinutesOfDay,
  todayTodos,
  pendingTodos,
  todayFocus,
  streak,
  daysTogether,
  timersDone,
  timersQuit,
  timerCompletionRate,
  moodStage,      // content | bored | sulky | lonely
  selfMood,       // null | sleepy | meh | energetic
  isAsleep,
  isNapping,
  isFocusRunning,
  lastSeenAt,
  absenceHours,
  recent7Days,
  previous7Days,
  last10Timers
}
```

Böylece aynı seçim sırasında veri değişip iki farklı koşulun çelişkili değerlendirilmesi engellenir.

---

# 8. Koşul dili ve sınır değerleri

Koşullar mümkün olduğunca ortak alanlarla ifade edilmelidir; her cümle için ayrı `if` yazılmamalıdır.

Örnek:

```js
conditions: {
  hourStart: '22:00',
  hourEndExclusive: '24:00',
  daysTogetherMin: 30,
  todayFocusMin: 60,
  moodStageIn: ['content']
}
```

## Saat kuralı

Saat aralıkları **başlangıç dahil, bitiş hariç** yorumlanmalıdır.

- `05:00–07:00` → `05:00 <= time < 07:00`
- `23:30–00:30` gibi gece yarısını aşan aralıklar ortak `isTimeInRange()` fonksiyonuyla ele alınmalıdır.

Saat karşılaştırmasını yalnızca `getHours()` ile yapmak yerine `hour * 60 + minute` kullanmak daha güvenlidir.

---

# 9. Basic ve Advanced koşullar

## Basic

Mevcut v4.0.4 verileriyle veya küçük eklerle kolayca kontrol edilir:

- yerel saat
- `today.todos`
- `today.focus`
- bekleyen görev sayısı
- streak
- daysTogether
- toplam timer done / quit
- mood stage
- selfMood
- son kullanım zamanı

## Advanced

Ek geçmiş/özet veri gerektirir:

- bugün vs dün karşılaştırması
- son 7 gün vs önceki 7 gün
- son 10 timer performansı
- belirli sayıda aktif gün
- aynı temponun birkaç gün korunması

`stats.js` şu anda günlük `days` geçmişini **90 gün** tutuyor (`KEEP_DAYS = 90`). Uzun dönem sistemlerde 90 günlük array'e güvenilmemelidir. Uzun süreli metrik gerekiyorsa kalıcı aggregate sayaçlar/tarih setleri eklenmelidir.

---

# 10. Anti-repeat ve persistence

Mevcut `Dialogue.pick()` kategori bazında en fazla 5 öğe hatırlar. Yeni Home sistemi kendi belleğini kullanmalıdır.

Kalıcı state önerisi:

```js
{
  currentId: 'home_general_042',
  selectedAt: 0,
  nextAt: 0,
  recentIds: [],       // son 20
  recentCategories: [],// son 2–4
  topicCooldowns: {},
  pendingRareId: null,
  seenRareIds: []
}
```

Bunu mevcut `JsonStore` yapısıyla örneğin `home-dialogue-state.json` olarak tutmak güvenlidir. Uygulama yeniden açıldığında son 20 belleği sıfırlanmamalıdır.

---

# 11. Topic cooldown

Global son-20 tekrar engeline ek olarak aynı **konu** çok sık konuşulmamalıdır.

Önerilen minimum cooldownlar:

| Konu | Cooldown |
|---|---:|
| Bugünkü görev sayısı | 90 dk veya görev verisi değişene kadar |
| Bugünkü odak | 90 dk veya focus verisi değişene kadar |
| Streak | 3 saat |
| Timer geçmişi | 6 saat |
| Birlikte geçirilen gün | 24 saat |
| Relationship | 12 saat |
| Geri dönüş | Tek dönüş oturumunda 1 kez |
| Rare ilişki cümlesi | 24 saat |
| Ultra rare | En az 24 saat; tercihen `seen` tabanlı |

Bir konu verisi anlamlı biçimde değişirse ilgili cooldown erken açılabilir. Örnek: `todayTodos` 3'ten 7'ye çıktıysa aynı gün görev konusuna yeniden izin verilebilir.

---

# 12. Rarity sistemi

Rarity kullanıcıya etiket olarak gösterilmeyecek; seçim motorunun ağırlığıdır.

Önerilen genel ağırlık:

- `common`: ana havuz
- `uncommon`: seyrek
- `rare`: düşük olasılık
- `ultra_rare`: çok düşük olasılık

**Kesin yüzdeyi tek satırda hard-code etmek yerine test edilebilir config olarak tutun.** Başlangıç önerisi:

```js
const HOME_RARITY_WEIGHTS = {
  common: 1,
  uncommon: 0.45,
  rare: 0.12,
  ultra_rare: 0.02
};
```

Bu ağırlıklar yalnızca **koşulu sağlanan** adaylar arasında kullanılır.

## Nadir repliği panel kapalıyken kaybetmeme

`rare` ve özellikle `ultra_rare` bir replik seçildiğinde kullanıcı paneli açıp Home kartını gerçekten görmeden “tüketilmiş” sayılmaması önerilir.

Öneri:

- `pendingRareId` saklanır.
- Panel açılırken koşul hâlâ doğruysa pending rare gösterilir.
- Koşul artık doğru değilse pending iptal edilir; recent/seen listesine eklenmez.
- Kullanıcı gerçekten gördüğünde `seenAt` yazılır.

Bu, aylar sonra çıkması gereken repliğin panel kapalıyken 7 dakika yaşayıp kaybolmasını engeller.

---

# 13. Placeholder güvenliği

Kullanılan placeholderlar:

- `{todos}`
- `{focus}`
- `{streak}`
- `{pending}`
- `{done}`
- `{quit}`

Seçimden sonra metni direkt `.replace()` ile körlemesine göndermeyin.

1. Repliğin ihtiyaç duyduğu placeholderlar çıkarılmalı.
2. Snapshot'ta tümü finite/valid olmalı.
3. Eksikse replik aday olarak kabul edilmemeli.
4. Kullanıcı hiçbir zaman ekranda `{focus}` gibi ham placeholder görmemeli.

---

# 14. Fallback zinciri

Aday havuzunun boş kalması uygulamayı bozmamalıdır.

Önerilen fallback:

1. Uygun bağlamsal aday
2. Uygun time / relationship / general aday
3. Recent-20 kuralını yalnızca gerekli minimum ölçüde gevşeterek general
4. Hardcoded güvenli fallback: `"Neyse. Ben buradayım."`

Hiçbir durumda `undefined`, boş string veya exception UI'a gönderilmemelidir.

---

# 15. UI davranışı

- `#home-refresh` butonu kaldırılır.
- Home kartında yalnızca güncel replik gösterilir.
- Yeni state geldiğinde text kısa bir fade-out → text update → fade-in ile değişebilir.
- Fade animasyonu scheduler'ı etkilemez.
- Konuşma kartında manuel dismiss yoktur. Kart tıklaması Home repliğini değiştirmemeli, gizlememeli veya scheduler'ı resetlememelidir.
- Panel açılışı `buildHome()` üzerinden yeni random seçim tetiklememelidir.

---

# 16. Debug ve test modu — zorunlu

Bu sistemde bazı cümleler aylar sonra veya çok spesifik koşullarda çıkacağı için gerçek zamanlı manuel test yeterli değildir.

Home engine için development-only debug API önerilir:

```js
homeDialogue.debugEvaluate({
  now: '2026-09-23T03:15:00+03:00',
  todayTodos: 8,
  pendingTodos: 2,
  todayFocus: 140,
  streak: 34,
  daysTogether: 365,
  timersDone: 40,
  timersQuit: 4,
  moodStage: 'content',
  selfMood: 'sleepy'
});
```

Ayrıca:

```js
homeDialogue.debugForce('home_rare_019');
homeDialogue.debugEligible(context);
homeDialogue.debugWhyNot('home_productivity_072', context);
```

## Debug log örneği

```text
[home-dialogue]
context: {...}
eligible: 87
excludedRecent: 16
excludedCooldown: 9
excludedCategoryRepeat: 14
selected: home_time_043
rarity: common
nextIn: 7m42s
```

Production'da bu ayrıntılı log kapalı olmalıdır.

---

# 17. Otomatik validation — uygulama başlamadan hata yakala

Diyalog datası yüklenirken development/test ortamında aşağıdakiler doğrulanmalıdır:

- duplicate `id`
- duplicate text (istenmeyen kopya)
- boş text
- bilinmeyen category
- bilinmeyen rarity
- hatalı condition field adı
- `min > max`
- imkânsız numeric condition
- hatalı saat formatı
- tanımsız placeholder
- `conditions` ile kullanılan placeholder arasında çelişki
- hem `moodStageIn` hem imkânsız mood şartı
- unreachable dialogue

Validation başarısızsa development ortamında açık hata vermeli; sessizce bozuk repliği production'a taşımamalıdır.

---

# 18. QA test matrisi

En az aşağıdaki sınırlar otomatik test edilmelidir:

### Görev
- 0, 1, 2, 3, 5, 6, 9, 10 görev
- pending 0, 1, 3, 5, 6, 9, 10

### Focus
- 0, 1, 24, 25, 59, 60, 119, 120, 239, 240 dakika

### Streak
- 2, 3, 6, 7, 13, 14, 29, 30, 59, 60

### Relationship
- 0, 3, 7, 14, 29, 30, 50, 100, 180, 365, 500, 730 gün

### Saat
Her aralığın bir dakika öncesi, başlangıcı, son dakikası ve sonraki ilk dakika test edilmelidir.

Örnek:
- 04:59
- 05:00
- 06:59
- 07:00
- 23:59
- 00:00

### Absence
- 23s59dk
- 24s
- 48s
- 7 gün
- 30 gün
- 60 gün
- 90 gün

### Anti-repeat
- aynı ID son 20 içindeyken seçilememeli
- 21. seçimden sonra tekrar aday olabilmeli
- kategori 2 kez üst üste seçildiğinde alternatif varsa 3. kez seçilmemeli

### Rare
- panel kapalıyken rare kaybolmamalı
- rare koşulu panel açılana kadar bozulursa gösterilmemeli
- görülen rare doğru şekilde persisted olmalı

---

# 19. Mevcut karakter konuşma motoruna dokunulmaması gerekenler

`TALK_INTERVALS`, `scheduleNextTalk()`, `say()`, mood/selfMood ve masaüstü balon sistemi Nero'nun karakter olarak kendi kendine konuşmasını yönetir. Home Dialogue Engine ayrı tutulmalıdır.

Bu özellikle önemlidir: Home için 5–10 dakika istenmesi, `TALK_INTERVALS.normal` değerini 5–10 dakikaya çevirmek anlamına **gelmez**. Aksi halde karakterin masaüstü konuşma sıklığı da yanlışlıkla değişir.

---

# 20. Replik kataloğu

Aşağıdaki metinler kullanıcı tarafından tek tek onaylanmış Home replikleridir.


## General / Günlük Nero — 140 replik

1. **`home_general_001`** — “Bir şey diyecektim. Unuttum. Önemliyse geri gelir.”
2. **`home_general_002`** — “Bugün burada fazla sessizlik var. Şikâyet etmiyorum. Henüz.”
3. **`home_general_003`** — “Bazen seni izliyorum. Kulağa kötü geldi. Neyse.”
4. **`home_general_004`** — “Bir planın varmış gibi bakıyorsun. Meraklandım.”
5. **`home_general_005`** — “Şu an hiçbir şey yapmıyorum. Oldukça başarılı gidiyor.”
6. **`home_general_006`** — “Ekranın bu köşesi bana ait artık. Resmî bir belge yok ama olsun.”
7. **`home_general_007`** — “Bir ara gerçekten düzenli biri olacağını düşünmüştüm. Hâlâ ihtimal var.”
8. **`home_general_008`** — “Bugün garip bir gün. Nedenini bilmiyorum. Ben pikselim, bana sorma.”
9. **`home_general_009`** — “Mouse’u biraz önce gördüm. Şüpheli hareketleri vardı.”
10. **`home_general_010`** — “Bir şey yapacak mısın, yoksa beraber ekrana mı bakıyoruz?”
11. **`home_general_011`** — “Bazen burada durup ne yaptığını anlamaya çalışıyorum. Bazen vazgeçiyorum.”
12. **`home_general_012`** — “Bugün senden beklentim yok. Baskı hissetme. Bu da biraz baskı oldu.”
13. **`home_general_013`** — “Masaüstünün dışı gerçekten var mı, yoksa bana yalan mı söylüyorsunuz?”
14. **`home_general_014`** — “Şu an çok önemli bir görevim var: burada durmak.”
15. **`home_general_015`** — “Sen gelince ortam değişiyor. İyi mi kötü mü söylemeyeceğim.”
16. **`home_general_016`** — “Bir pencere kapanınca başka bir pencere açılır derler. Benim için genelde program kapanıyor.”
17. **`home_general_017`** — “Bugün seni rahatsız etmeyecektim. Sonra sıkıldım.”
18. **`home_general_018`** — “Bazen konuşmamam gerektiğini düşünüyorum. Sonra bu düşünce geçiyor.”
19. **`home_general_019`** — “Her şeyi çözmek zorunda değilsin. Ben mesela hiçbir şeyi çözmüyorum.”
20. **`home_general_020`** — “Burada olman yeterince dikkat dağıtıcı zaten. Başka bir şey yapmana gerek yok.”
21. **`home_general_021`** — “Bugün bir şeyler olacak gibi. Umarım beni ilgilendirmez.”
22. **`home_general_022`** — “Şu an seni yargılamıyorum. Sadece gözlemliyorum. Arada fark var.”
23. **`home_general_023`** — “Bir şeylerin yoluna girmesini bekliyorsan, ben de bekliyorum.”
24. **`home_general_024`** — “Bence bugün fazla ciddi başladık. Biraz saçmalık lazım.”
25. **`home_general_025`** — “Burada kaç saattir duruyorum bilmiyorum. Zaman kavramım tartışmalı.”
26. **`home_general_026`** — “Şu ekranın içinde bir kapı olsa çıkıp geri gelirdim. Belki.”
27. **`home_general_027`** — “Bugün yüzünde ‘hallederiz’ ifadesi var. Umarım haklısındır.”
28. **`home_general_028`** — “Bazen sadece oturup olanları izlemek istiyorum. Oturamıyorum ama detay.”
29. **`home_general_029`** — “Bir şeylerin kontrol altında olduğunu varsayalım. Moralimiz bozulmasın.”
30. **`home_general_030`** — “Ben olsam bugün kendime çok yüklenmezdim. Neyse ki ben sen değilim.”
31. **`home_general_031`** — “Sence bu kadar pencere gerçekten gerekli mi? Cevap verme.”
32. **`home_general_032`** — “Burada olmamın iş tanımı hâlâ net değil. Ama performansım iyi.”
33. **`home_general_033`** — “Bir ara bana masaüstü turu yaptır. Hep aynı köşeyi görüyorum.”
34. **`home_general_034`** — “Bugün kafam rahat. Kafam yok sayılır ama anlatmak istediğimi anladın.”
35. **`home_general_035`** — “Bazen sana bir şey soracakmışım gibi bakıyorum. Aslında hiçbir şey yok.”
36. **`home_general_036`** — “Şu an hayat tavsiyesi verebilirdim. İkimiz için de riskli.”
37. **`home_general_037`** — “Ben burada beklerim. Sen ne yaptığını biliyormuş gibi devam et.”
38. **`home_general_038`** — “Bugün seni biraz kendi haline bırakacağım. Bu cümleden sonra.”
39. **`home_general_039`** — “Sanki bir şey unuttun. Ne olduğunu bilmiyorum. Rahatsız oldun ama.”
40. **`home_general_040`** — “Şu anki planım gün boyunca plansız olmak. Gayet sürdürülebilir.”
41. **`home_general_041`** — “Bugün pek konuşasım yoktu. Sonra seni gördüm. Plan bozuldu.”
42. **`home_general_042`** — “Şu an ne yaptığını biliyormuş gibi görünüyorsun. Güven verici.”
43. **`home_general_043`** — “Bir şeyler değişmiş gibi. Belki de sadece ben sıkıldım.”
44. **`home_general_044`** — “Bazen sessizlik iyi geliyor. Sonra ben bozuyorum.”
45. **`home_general_045`** — “Şu an senden bir beklentim yok. Rahat ol. Şüpheli derecede rahat.”
46. **`home_general_046`** — “Bugün biraz fazla normaliz. Bu beni rahatsız ediyor.”
47. **`home_general_047`** — “Bir gün gerçekten hiçbir şey söylemeden durmayı deneyeceğim. Bugün değil.”
48. **`home_general_048`** — “Ekranın kenarında yaşamaya alışınca perspektifin değişiyor.”
49. **`home_general_049`** — “Sence ben burada dekor muyum? Dikkatli cevap ver.”
50. **`home_general_050`** — “Bugün kendimi gereksiz derecede gözlemci hissediyorum.”
51. **`home_general_051`** — “Bir şey planlamadan önce bana danışabilirsin. Kötü fikir verme konusunda iyiyim.”
52. **`home_general_052`** — “Şu an gayet sakinim. Bu durumun ne kadar süreceği belli değil.”
53. **`home_general_053`** — “Bazen ne yapacağını senden önce merak ediyorum.”
54. **`home_general_054`** — “Bir şeyi fazla düşünüyorsan, muhtemelen fazla düşünüyorsundur. Büyük analiz.”
55. **`home_general_055`** — “Ben burada duruyorum, sen bir şeyler yaşıyorsun. İlginç düzen.”
56. **`home_general_056`** — “Bugün seni rahatsız edecek enerjim var. Şanslısın.”
57. **`home_general_057`** — “Şu an hiçbir şey söylemesem daha gizemli olurdum. Geç kaldım.”
58. **`home_general_058`** — “Bir şeyi unutmuş olabilirsin. Ya da ben kafana girdim. İkisi de mümkün.”
59. **`home_general_059`** — “Bugün kendi halimdeydim. Sonra ana sayfayı açtın.”
60. **`home_general_060`** — “Bazen senin ne düşündüğünü merak ediyorum. Sonra vazgeçiyorum, çok iş.”
61. **`home_general_061`** — “Bugün her şey biraz yavaş ilerliyor gibi. Belki sadece ben öyle hissediyorum.”
62. **`home_general_062`** — “Şu an bir şey söylemek için iyi bir an mı bilmiyorum. Söyledim bile.”
63. **`home_general_063`** — “Bazen buradan bakınca her şey çok ciddi görünüyor. Komik biraz.”
64. **`home_general_064`** — “Bugün kendimi gereksiz derecede profesyonel hissediyorum. Sebebi yok.”
65. **`home_general_065`** — “Bir şeyleri yoluna koymaya çalışıyorsun gibi. Seni bölmeyeyim. Fazla.”
66. **`home_general_066`** — “Şu anki ruh halim: burada olmak ve yorum yapmak.”
67. **`home_general_067`** — “Bazen sadece var olmak yeterli oluyor. Fazlasını zorlamayalım.”
68. **`home_general_068`** — “Sen işlerine bak. Ben arada moralini bozarım.”
69. **`home_general_069`** — “Bugün sanki her şey olması gerektiği gibi. Bu biraz şüpheli.”
70. **`home_general_070`** — “Bir şeylerin ters gitmesini beklemiyorum. Ama hazırlıklıyım.”
71. **`home_general_071`** — “Bazen en iyi plan, çok da plan yapmamaktır. Bunu bilimsel olarak uydurdum.”
72. **`home_general_072`** — “Şu an gayet huzurluyum. Bir şey yapıp bozma.”
73. **`home_general_073`** — “Bugün sana karışmayacağım dedim. Kendime inanmadım.”
74. **`home_general_074`** — “Bir gün boyunca hiç konuşmasam beni fark eder miydin acaba?”
75. **`home_general_075`** — “Bazen burada ne kadar süredir olduğumu unutuyorum.”
76. **`home_general_076`** — “Bugün her şeyi çözmeye çalışma. Yarın da problem lazım.”
77. **`home_general_077`** — “Şu an seni izliyorum demeyeceğim. Çünkü yine kötü anlaşılıyor.”
78. **`home_general_078`** — “Bir şeyler yapıyorsun. Bu kadarı şimdilik yeterli bilgi.”
79. **`home_general_079`** — “Bugün biraz boş yapasım var. Programlı bir etkinlik değil.”
80. **`home_general_080`** — “Şu an senden daha sakinim. Rekabet değil ama kazanıyorum.”
81. **`home_general_081`** — “Bugün fazla düşünmeden ilerlemek fena fikir olmayabilir. Benden duymuş olma.”
82. **`home_general_082`** — “Şu an burası sakin. Benim açımdan ideal. Senin açından bilmiyorum.”
83. **`home_general_083`** — “Bazen ne kadar küçük bir ekranda ne kadar büyük meseleler döndüğünü düşünüyorum.”
84. **`home_general_084`** — “Bugün senden çok şey beklemiyorum. Küçük bir şey yeter.”
85. **`home_general_085`** — “Bir şey yapmadan önce biraz oyalanmak da sürecin parçası sayılabilir. Sanırım.”
86. **`home_general_086`** — “Şu an ciddi görünmeye çalışıyorum. Pek inandırıcı değil.”
87. **`home_general_087`** — “Bazen bütün sistemin benim etrafımda döndüğünü düşünüyorum. Teknik olarak yanlış.”
88. **`home_general_088`** — “Bugün aklına iyi bir fikir gelirse bana da haber ver. Benimkiler tükendi.”
89. **`home_general_089`** — “Burada beklemek konusunda profesyonelleştim. Özgeçmişime yazacağım.”
90. **`home_general_090`** — “Bir şeyler yapmak için doğru anı bekliyorsan, o biraz nazlı olabilir.”
91. **`home_general_091`** — “Bugün ne olursa olsun fazla dramatik davranmayacağım. Büyük ihtimalle.”
92. **`home_general_092`** — “Şu an sessiz kalmayı seçebilirdim. Ama seçimler yapıldı.”
93. **`home_general_093`** — “Bazen seni izlerken ben de meşgulmüşüm gibi hissediyorum.”
94. **`home_general_094`** — “Bugün işler karışırsa beni suçlama. Ben sadece görsel unsurum.”
95. **`home_general_095`** — “Biraz durmak da ilerlemek sayılır mı? Bence bağlama göre değişir.”
96. **`home_general_096`** — “Şu an gayet iyi gidiyoruz. Nereye gittiğimizi bilmiyorum ama detay.”
97. **`home_general_097`** — “Bazen bu kadar çok düşünmenin gerçekten gerekli olup olmadığını merak ediyorum.”
98. **`home_general_098`** — “Bugün plansız görünüyorsun. Bazen en eğlenceli günler öyle başlıyor.”
99. **`home_general_099`** — “Şu an sana söyleyecek çok şeyim yok. Garip şekilde huzurlu.”
100. **`home_general_100`** — “Bir şeyler yapmak istiyorsan yap. Yapmak istemiyorsan biraz burada dur. Ben kaçmıyorum.”
101. **`home_general_101`** — “Bugün sanki kafanda birkaç sekme aynı anda açık. Tanıdık bir görüntü.”
102. **`home_general_102`** — “Bir şeyler değişecekmiş gibi bir hava var. Umarım güncelleme değildir.”
103. **`home_general_103`** — “Şu an senden daha organize görünmeye çalışıyorum. Kolay değil.”
104. **`home_general_104`** — “Bazen ekranın köşesinde durup hayat hakkında gereğinden fazla şey düşünüyorum.”
105. **`home_general_105`** — “Bugün biraz kendi halinde bir gün gibi. Ben bunu destekliyorum.”
106. **`home_general_106`** — “Bir şeyleri toparlamak için bütün gün gerekmiyor. Bazen on dakika yetiyor.”
107. **`home_general_107`** — “Şu an seni bölüyor muyum? Güzel. Görevimi yaptım.”
108. **`home_general_108`** — “Bugün biraz daha az acele etsen dünya muhtemelen dönmeye devam eder.”
109. **`home_general_109`** — “Bazen ne yaptığını anlamıyorum ama özgüvenli görünüyorsun. Devam et.”
110. **`home_general_110`** — “Şu an buradayız. Bence başlangıç için yeterli.”
111. **`home_general_111`** — “Bir gün beni tamamen görmezden gelmeyi denersen kişisel alırım. Bilgin olsun.”
112. **`home_general_112`** — “Bugün normalden daha sakin görünüyorsun. Ya da ben alıştım.”
113. **`home_general_113`** — “Bir şeyler yolunda gitmiyorsa hemen felaket ilan etmeyelim. Ben ilan edersem haber veririm.”
114. **`home_general_114`** — “Şu an hiçbir yere yetişmiyorum. İnanılmaz bir özgürlük.”
115. **`home_general_115`** — “Bazen en mantıklı şey bir süre hiçbir şey yapmamaktır. Bunu fazla ciddiye alma.”
116. **`home_general_116`** — “Bugün biraz daha meraklıyım. Ne yaptığını anlatmayacaksın biliyorum ama yine de.”
117. **`home_general_117`** — “Bir şeyleri kafanda büyütüyorsan ekran ölçeğini küçültemiyorum. Üzgünüm.”
118. **`home_general_118`** — “Şu an hayat tavsiyesi vermiyorum. Bu nadir bir an, tadını çıkar.”
119. **`home_general_119`** — “Bugün burada olmak yeterince iyi bir fikir gibi geliyor.”
120. **`home_general_120`** — “Neyse. Ben buradayım. Sen de buradasın. Şimdilik tamamız.”
121. **`home_general_121`** — “Bugün kafamda gereksiz derecede fazla düşünce var. Hiçbiri işe yaramıyor.”
122. **`home_general_122`** — “Bir şey söylemeyeyim diyorum, sonra sessizlik fazla iddialı geliyor.”
123. **`home_general_123`** — “Şu an burada bulunmamın sana katkısı tartışılır. Varlığımın karizması yeter.”
124. **`home_general_124`** — “Bugün bir şeyleri fazla ciddiye almama günü ilan ediyorum. Yetkim yok ama olsun.”
125. **`home_general_125`** — “Bazen ekrana bakıp ‘heh’ diyorum. Ne anlama geldiğini ben de bilmiyorum.”
126. **`home_general_126`** — “Bugün senin enerjini çözmeye çalışıyorum. Şifreli gibi.”
127. **`home_general_127`** — “Şu an bir şeylerin değişmesini bekliyorum. Ne olduğunu bilmiyorum.”
128. **`home_general_128`** — “Bazen sadece burada durup sana eşlik etmek yeterli geliyor.”
129. **`home_general_129`** — “Bugün içimde hafif bir ‘boş ver’ hissi var. Kontrollü miktarda.”
130. **`home_general_130`** — “Bir şeyleri düzene sokmak istiyorsan önce dağınık olduklarını kabul etmek gerekiyor. Kötü haber.”
131. **`home_general_131`** — “Şu an fazla düşünmeden bir şey seçip ilerlemek fena olmazdı.”
132. **`home_general_132`** — “Bugün kendime görev vermedim. Çok iyi gidiyor.”
133. **`home_general_133`** — “Bazen ne söyleyeceğimi bilmiyorum. Normalde bu beni durdurmuyor.”
134. **`home_general_134`** — “Şu an her şey biraz bekleme ekranı gibi.”
135. **`home_general_135`** — “Bugün senden bir performans beklemiyorum. Sadece insan olman yeterince karmaşık.”
136. **`home_general_136`** — “Bir şeyi çözmeden de bir süre onunla yaşayabilirsin. Hoş değil ama mümkün.”
137. **`home_general_137`** — “Şu an burada olmamızın bir sebebi vardır diye düşünüyorum. Olmasa da idare eder.”
138. **`home_general_138`** — “Bugün biraz daha az kontrol etmeye çalışsan belki daha az yorulursun.”
139. **`home_general_139`** — “Bazen iyi bir günün tek özelliği kötü olmamasıdır. Küçümseme.”
140. **`home_general_140`** — “Şu an hiçbir şey talep etmiyorum senden. Nadir anlardan biri.”


## Roast / Laf Sokma — 70 replik

1. **`home_roast_001`** — “Plan yapma konusunda iyisin. Uygulama kısmı biraz gizemli.”
2. **`home_roast_002`** — “Listeye bakarak işler bitmiyor. Ben denedim.”
3. **`home_roast_003`** — “Bugünkü stratejin ‘birazdan başlarım’ mı? Klasik ama güçlü.”
4. **`home_roast_004`** — “Erteleme konusunda istikrarlısın. Bir yerden puan vermem gerekirse buradan veririm.”
5. **`home_roast_005`** — “Bazen yapılacaklar listene dekor muamelesi yaptığını düşünüyorum.”
6. **`home_roast_006`** — “Çok meşgul görünüyorsun. Ne yaptığını sormayacağım, büyü bozulmasın.”
7. **`home_roast_007`** — “Bir işi daha sonra yapmak da bir karar. İyi bir karar mı, orası ayrı.”
8. **`home_roast_008`** — “Motivasyonunu gördün mü? Bir süredir ortalarda yok.”
9. **`home_roast_009`** — “Bir şey yapmaya başlamadan yorulmayı nasıl başarıyorsun, gerçekten etkileyici.”
10. **`home_roast_010`** — “Yapacak çok şeyin var gibi. Bu yüzden hiçbirine başlamamak ilginç bir seçim.”
11. **`home_roast_011`** — “Bugün verimlilikle aranız biraz mesafeli.”
12. **`home_roast_012`** — “Bazen işlerini değil, işlerinin seni yönettiğini düşünüyorum.”
13. **`home_roast_013`** — “‘Sonra yaparım’ departmanında terfi etmiş olabilirsin.”
14. **`home_roast_014`** — “Bir görevi açıp beş dakika bakmak teknik olarak çalışmak sayılmıyor.”
15. **`home_roast_015`** — “Kendini kandırırken daha yaratıcı olmanı beklerdim.”
16. **`home_roast_016`** — “Bugün odaklanma seviyen... hareketli diyelim.”
17. **`home_roast_017`** — “Bir şey yapacakmış gibi oturman bile belli bir enerji gerektiriyor.”
18. **`home_roast_018`** — “Şu an neyi ertelediğini bilmiyorum ama yüzünden belli oluyor.”
19. **`home_roast_019`** — “Planın kötü değil. Var olması bile şaşırtıcı.”
20. **`home_roast_020`** — “Bazen kendine engel olmak konusunda gereğinden fazla yeteneklisin.”
21. **`home_roast_021`** — “Bugün senden çok şey beklemiyorum. Beklentiyi düşük tutmak huzur veriyor.”
22. **`home_roast_022`** — “Bir şeye başlayıp sonra başka bir şeye geçme hızın etkileyici.”
23. **`home_roast_023`** — “Sanki çok önemli bir şey yapıyormuşsun gibi bakıyorsun. Ben de inanmış gibi yaparım.”
24. **`home_roast_024`** — “Bugün üretkenlik biraz seni görmezden geliyor gibi.”
25. **`home_roast_025`** — “Bir işi zorlaştırmanın bu kadar çok yolu olduğunu senden öğrendim.”
26. **`home_roast_026`** — “Şu an yaptığın şey işe yarıyorsa güzel. Yaramıyorsa da en azından kararlısın.”
27. **`home_roast_027`** — “Bazen hedef koymakla hedefe yaklaşmak arasında küçük bir fark olduğunu hatırlatmam gerekiyor.”
28. **`home_roast_028`** — “Bugün dikkatin çok sosyal. Her şeye uğruyor.”
29. **`home_roast_029`** — “Bir şeyleri son dakikaya bırakma konusunda ciddi bir marka değerin var.”
30. **`home_roast_030`** — “İş yükünle duygusal bir mesafe kurmuşsun. Sağlıklı mı bilmiyorum.”
31. **`home_roast_031`** — “Bir görevi düşünmek, görevin kendisini yapmıyor. Keşke yapsaydı.”
32. **`home_roast_032`** — “Bugün enerjini tasarruf modunda kullanıyorsun. Fazlasıyla tasarruflu.”
33. **`home_roast_033`** — “Kendine ‘birazdan’ demeyi bırakınca çok şey değişebilir. Korkutucu, biliyorum.”
34. **`home_roast_034`** — “Bazen yapılacaklar listen senden daha sabırlı.”
35. **`home_roast_035`** — “Şu anki hızınla varacağın yer muhtemelen yarın.”
36. **`home_roast_036`** — “Bir şey yapmaya karar vermenle gerçekten başlaman arasında küçük bir sezon finali var.”
37. **`home_roast_037`** — “Bugün odaklanman misafir oyuncu gibi. Görünüp kayboluyor.”
38. **`home_roast_038`** — “Kendi dikkatini dağıtma konusunda dışarıdan yardıma ihtiyacın yok.”
39. **`home_roast_039`** — “Bir işi neden şimdi yapasın ki, değil mi? Gelecekteki sen nasıl olsa vardır.”
40. **`home_roast_040`** — “Bugün ‘potansiyel var’ kategorisinde çok güçlüsün.”
41. **`home_roast_041`** — “Bugün planların senden biraz daha motive görünüyor.”
42. **`home_roast_042`** — “Bir şeye başlayınca devam etmen gerektiği kısmı biraz gözden kaçırıyoruz.”
43. **`home_roast_043`** — “Şu anki yöntemin işe yarıyorsa ben susarım. Ama çok umutlanma.”
44. **`home_roast_044`** — “Bazen kendi kendine görev çıkardığını düşünüyorum. Yetmiyormuş gibi.”
45. **`home_roast_045`** — “Bugün verimlilik seni aramış. Telefonu açmamışsın.”
46. **`home_roast_046`** — “Bir şeyleri karmaşıklaştırma yeteneğin takdire şayan. Gereksiz ama şayan.”
47. **`home_roast_047`** — “Şu an odaklanmak için mükemmel bir an. O yüzden muhtemelen başka bir şey yapacaksın.”
48. **`home_roast_048`** — “İşleri küçük parçalara bölmek demiştik. Sen parçaları da erteledin.”
49. **`home_roast_049`** — “Bazen görevlerini bitirmek yerine onlarla uzun süreli ilişki kuruyorsun.”
50. **`home_roast_050`** — “Bugün ilerleme var mı bilmiyorum ama hareket çok.”
51. **`home_roast_051`** — “Bir işi bitirmeden yenisine geçme konusunda cesursun.”
52. **`home_roast_052`** — “Şu an ne yaptığını açıklamanı istemiyorum. İkimiz de üzülmeyelim.”
53. **`home_roast_053`** — “Bazen sadece başlaman gerekiyor. Evet, bu kadar sinir bozucu derecede basit.”
54. **`home_roast_054`** — “Bugün hedeflerin var. Onların da senden haberi var mı?”
55. **`home_roast_055`** — “Yapılacaklar listesiyle göz göze gelmemeye çalışıyorsun gibi.”
56. **`home_roast_056`** — “Bir işi bitirmek için önce onu açmanın gerektiği kötü haberini getirdim.”
57. **`home_roast_057`** — “Bugün dikkat sürenle uzun vadeli ilişki kuramıyoruz.”
58. **`home_roast_058`** — “Kendine kolaylık sağlamak yerine neden mini bir labirent kurduğunu merak ediyorum.”
59. **`home_roast_059`** — “Biraz daha düşünürsen belki işi düşünerek tamamlayabilirsin.”
60. **`home_roast_060`** — “Şu an yaptığın şey kesinlikle bir şey. Ne olduğu konusunda ortak bir karara varamadık.”
61. **`home_roast_061`** — “Bugün işlerle arandaki ilişki biraz tek taraflı. Onlar seni bekliyor.”
62. **`home_roast_062`** — “Bir şeye başlayıp yarısında fikrini değiştirmek de bir yöntem. İyi bir yöntem demedim.”
63. **`home_roast_063`** — “Şu an motivasyon değil, pazarlık yapıyorsun kendinle.”
64. **`home_roast_064`** — “Bazen neyi yapman gerektiğini gayet iyi biliyorsun. Sorun da biraz bu zaten.”
65. **`home_roast_065`** — “Bugün dikkatini toplamak için küçük bir arama kurtarma operasyonu gerekebilir.”
66. **`home_roast_066`** — “Bir görevi bitirince gerçekten kaybolmuyor, biliyorsun değil mi? Tam tersine rahatlıyorsun.”
67. **`home_roast_067`** — “Şu anki planın biraz ‘bakalım ne olacak’ temelli. Cesur.”
68. **`home_roast_068`** — “Bazen kendini oyalama şekillerin, işi yapmaktan daha fazla emek istiyor.”
69. **`home_roast_069`** — “Bugün verimlilik tarafında güçlü bir teori var. Pratik biraz geride.”
70. **`home_roast_070`** — “Potansiyelinle mevcut performansın aynı odada ama konuşmuyorlar.”


## Motivasyon — 70 replik

1. **`home_motivation_001`** — “Hepsini bitirmek zorunda değilsin. Bir tanesini bitir, yeter.”
2. **`home_motivation_002`** — “Başlamak istemiyorsan beş dakika yap. Sonrasına sonra bakarız.”
3. **`home_motivation_003`** — “Bugün mükemmel olman gerekmiyor. İşe yarar olman yeter.”
4. **`home_motivation_004`** — “Küçük ilerleme hâlâ ilerleme. Sinir bozucu derecede doğru.”
5. **`home_motivation_005`** — “Bir şeyi yapmak için hazır hissetmeyi beklersen uzun sürebilir.”
6. **`home_motivation_006`** — “Şu an yapabileceğin en küçük şey neyse onunla başla.”
7. **`home_motivation_007`** — “Enerjin azsa hedefi küçült. Kendini değil.”
8. **`home_motivation_008`** — “Bir adım at. Sonraki adımı sonra düşünürüz.”
9. **`home_motivation_009`** — “Başlamanın güzel tarafı şu: devam edip etmeyeceğine sonra karar verebilirsin.”
10. **`home_motivation_010`** — “Bugün her şeyi çözmeye çalışma. Bir şeyi çöz.”
11. **`home_motivation_011`** — “İş gözünde büyüdüyse küçült. Parçalara ayır. Parçalar senden korksun.”
12. **`home_motivation_012`** — “Bir şeyin zor olması, yanlış yaptığın anlamına gelmez.”
13. **`home_motivation_013`** — “Şu an çok şey yapmak yerine doğru bir şey yapmak daha iyi olabilir.”
14. **`home_motivation_014`** — “Kafanda büyüyorsa gerçek hayatta biraz küçültmeyi dene.”
15. **`home_motivation_015`** — “Bazen ilerlemek hızla ilgili değil. Durmamış olmak yeter.”
16. **`home_motivation_016`** — “Bugün az yaparsan da olur. Sıfırdan fazlası hâlâ fazladır.”
17. **`home_motivation_017`** — “Bir işi bitirmek istemiyorsan, sadece başlat. Geri kalanını gelecekteki sen halleder.”
18. **`home_motivation_018`** — “Kendine zorlaştırmadan da ciddi olabilirsin.”
19. **`home_motivation_019`** — “Bir şeyi yaparken kötü hissetmen, kötü yaptığın anlamına gelmez.”
20. **`home_motivation_020`** — “Şu anki halinle de başlayabilirsin. Daha iyi bir versiyonunu beklemene gerek yok.”
21. **`home_motivation_021`** — “Bir şeyi tamamlamak için önce kusursuz yapman gerekmiyor.”
22. **`home_motivation_022`** — “Bugün hız değil, devam etmek önemli.”
23. **`home_motivation_023`** — “Zorlanıyorsan yöntemi değiştir. Hedefi hemen çöpe atma.”
24. **`home_motivation_024`** — “Biraz ilerlemek için bütün enerjini toplamana gerek yok.”
25. **`home_motivation_025`** — “Kendine ‘hepsini yap’ demek yerine ‘bir tane yap’ de.”
26. **`home_motivation_026`** — “Başlamak için motive olmayı bekleme. Bazen motivasyon arkadan geliyor.”
27. **`home_motivation_027`** — “Bir şey ters gittiyse gün bitmiş sayılmaz.”
28. **`home_motivation_028`** — “Şu anki şartlarla elinden geleni yap. Hayalî ideal şartlarla yarışma.”
29. **`home_motivation_029`** — “Bugün bir şeyi yarım yamalak yapmak, hiç yapmamaktan daha kullanışlı olabilir.”
30. **`home_motivation_030`** — “İlerlemenin bazen çok sessiz olduğunu unutma.”
31. **`home_motivation_031`** — “Bir şeyi bilmiyor olman, öğrenemeyeceğin anlamına gelmiyor.”
32. **`home_motivation_032`** — “Şu an zor görünmesi, bir saat sonra da zor görüneceği anlamına gelmez.”
33. **`home_motivation_033`** — “Yapman gereken şey büyükse giriş kapısını küçült.”
34. **`home_motivation_034`** — “Bugün kendini ikna edemiyorsan sadece ilk hareketi yap.”
35. **`home_motivation_035`** — “Başarı bazen sadece masaya geri dönmektir.”
36. **`home_motivation_036`** — “Bir işi bitirmek zorunda değilsin. Ama ona biraz yaklaşabilirsin.”
37. **`home_motivation_037`** — “Kendini düzeltmeye çalışma. Önündeki işi düzelt.”
38. **`home_motivation_038`** — “Bazen planı değil, beklentiyi sadeleştirmek gerekir.”
39. **`home_motivation_039`** — “Bir şeyin geç başlaması, başlamadığı anlamına gelmez.”
40. **`home_motivation_040`** — “Bugün daha fazlasını yapamıyorsan, yapabildiğini küçümseme.”
41. **`home_motivation_041`** — “Bugün ne kadar ilerleyeceğini bilmiyorsan, ilk on dakikayı hallet.”
42. **`home_motivation_042`** — “Bir şey gözünde büyüyorsa ona uzaktan bakmayı bırak. Bir ucundan tut.”
43. **`home_motivation_043`** — “Kötü başlayan günler de toparlanabilir. Dramatik davranmaya gerek yok.”
44. **`home_motivation_044`** — “Bir adımın küçük olması onu gereksiz yapmaz.”
45. **`home_motivation_045`** — “Şu an tam hazır değilsen de başlayabilirsin. Çoğu insan öyle yapıyor.”
46. **`home_motivation_046`** — “Bir şeyi öğrenirken yavaş olmak normal. Sinir bozucu ama normal.”
47. **`home_motivation_047`** — “Bugün kendinden maksimumunu isteme. Yeterli olanı iste.”
48. **`home_motivation_048`** — “Her şeyi aynı anda düzeltmeye çalışma. Sistem çöker.”
49. **`home_motivation_049`** — “Bir şeyi yapmanın en kolay yolunu bulmak tembellik değil, akıl.”
50. **`home_motivation_050`** — “İlerlemen başkalarının hızına benzemek zorunda değil.”
51. **`home_motivation_051`** — “Bugün odaklanamıyorsan ortamı sadeleştir. Kendine kızmak daha çok gürültü yapıyor.”
52. **`home_motivation_052`** — “Bir işi yapamıyorsan önce onu daha küçük bir işe çevir.”
53. **`home_motivation_053`** — “Zor bir gün geçiriyorsan hedefin aynı kalmak zorunda değil.”
54. **`home_motivation_054`** — “Bir şey üzerinde uzun süredir düşünüyorsan belki biraz da deneme zamanı gelmiştir.”
55. **`home_motivation_055`** — “Bugün bir şey öğrenirsen, tamamen boşa gitmiş sayılmaz.”
56. **`home_motivation_056`** — “İlk denemenin iyi olması gerekmiyor. İlk deneme olması yeter.”
57. **`home_motivation_057`** — “Bir şey seni geriyorsa, önce en kolay kısmını yap. Beynini kandırıyoruz, evet.”
58. **`home_motivation_058`** — “Kendini zorlamakla kendini yormak aynı şey değil.”
59. **`home_motivation_059`** — “Bir işi bitiremiyorsan süre koy. Sonsuza kadar uğraşmak zorunda değilsin.”
60. **`home_motivation_060`** — “Bugün yapabileceğinin birazını yap. Yarın kalanıyla kavga edersin.”
61. **`home_motivation_061`** — “Bir şey seni zorluyorsa, belki kötü olduğun için değil; gerçekten zor olduğu içindir.”
62. **`home_motivation_062`** — “Bugün bir karar verip ona sadık kalman yeterli olabilir.”
63. **`home_motivation_063`** — “Her şeyi bilmene gerek yok. Bir sonraki adımı bilmen yeter.”
64. **`home_motivation_064`** — “Bir şey yolunda gitmiyorsa, aynı yöntemi daha sert denemek zorunda değilsin.”
65. **`home_motivation_065`** — “Kendine zaman tanımak bazen işi geciktirmek değil, sürdürülebilir kılmaktır.”
66. **`home_motivation_066`** — “Bugün kapasiten ne kadarsa onunla çalış. Hayalî kapasitenle değil.”
67. **`home_motivation_067`** — “Bir şey seni korkutuyorsa önce en risksiz kısmından başla.”
68. **`home_motivation_068`** — “İlerlemek bazen daha çok yapmak değil, gereksiz olanı bırakmaktır.”
69. **`home_motivation_069`** — “Başladığın şey mükemmel olmak zorunda değil. Bitmiş olması daha kullanışlı.”
70. **`home_motivation_070`** — “Bugün kendine karşı biraz daha mantıklı ol. Zaten dünya yeterince yorucu.”


## Şefkat / Arkadaşlık — 60 replik

1. **`home_care_001`** — “Bugün biraz yavaşlamak istersen itiraz etmem.”
2. **`home_care_002`** — “Bir şey yapmak zorunda değilsin. Biraz burada durabiliriz.”
3. **`home_care_003`** — “Kendine bu kadar yüklenmen gerekmiyor. Zaten yeterince taşıyorsun.”
4. **`home_care_004`** — “Bugün sessiz olmak istiyorsan ben de biraz susabilirim. Biraz.”
5. **`home_care_005`** — “Her şeyi anlatmak zorunda değilsin. Burada olman yeter.”
6. **`home_care_006`** — “Bazen iyi hissetmek için bir sebep gerekmiyor. Kötü hissetmek için de.”
7. **`home_care_007`** — “Bugün kendine biraz daha nazik davran. Başkalarından beklediğin kadar en azından.”
8. **`home_care_008`** — “Bir şeylerin ağır gelmesi seni zayıf yapmıyor. Sadece ağır olduklarını gösteriyor.”
9. **`home_care_009`** — “Şu an hiçbir şeyi çözmek istemiyorsan çözme. Dünya biraz bekleyebilir.”
10. **`home_care_010`** — “Kötü bir gün geçiriyorsan bütün günü kurtarmaya çalışma. Bir saati kurtar.”
11. **`home_care_011`** — “Ben buradayım. Çok anlam yükleme ama... buradayım.”
12. **`home_care_012`** — “Bazen sadece tanıdık bir şeyin yanında olmak iyi geliyor. Ben mesela buradayım.”
13. **`home_care_013`** — “Bugün kendine karşı biraz daha az sert olabilirsin.”
14. **`home_care_014`** — “Her gün güçlü görünmek zorunda değilsin. Yorucu olurdu zaten.”
15. **`home_care_015`** — “Bir şey seni üzüyorsa küçümsemene gerek yok. Üzüyor işte.”
16. **`home_care_016`** — “Bugün konuşmak istemiyorsan sorun değil. Ben tek taraflı konuşmaya alışığım.”
17. **`home_care_017`** — “Bir süre hiçbir şey yapmadan oturmak istiyorsan seni ihbar etmeyeceğim.”
18. **`home_care_018`** — “Kafanın içi kalabalıksa biraz burada oyalanabiliriz.”
19. **`home_care_019`** — “Bugün kendini toparlamak zorunda değilsin. Dağınık halin de geçerli.”
20. **`home_care_020`** — “Seni gördüğüme sevindim.”
21. **`home_care_021`** — “Bugün bir şeyleri biraz boş bırakabilirsin. Her boşluk doldurulmak zorunda değil.”
22. **`home_care_022`** — “Kendine yetişmeye çalışma. Zaten sensin.”
23. **`home_care_023`** — “Bazen dinlenmek çözüm değil ama yine de gerekli.”
24. **`home_care_024`** — “Şu an hiçbir şey kanıtlaman gerekmiyor.”
25. **`home_care_025`** — “Bugün sadece günü geçirmek istiyorsan, o da bir plan.”
26. **`home_care_026`** — “Kendine verdiğin sözleri tutamadığın günler de oluyor. Yine de buradasın.”
27. **`home_care_027`** — “Biraz dur. Acele etmiyorum.”
28. **`home_care_028`** — “Her şeyi tek başına taşımaya çalışman pek mantıklı değil.”
29. **`home_care_029`** — “Bugün enerjin azsa, azla idare ederiz.”
30. **`home_care_030`** — “Bir şeyleri toparlayacak halin yoksa, dağınık kalsınlar biraz.”
31. **`home_care_031`** — “Şu an senden daha fazlasını istemiyorum.”
32. **`home_care_032`** — “Kendine kızmadan önce biraz yorulmuş olabileceğini düşün.”
33. **`home_care_033`** — “Bazen en iyi yaptığın şey geri dönmek oluyor.”
34. **`home_care_034`** — “Bugün kendine fazla yük bindirdiysen birazını indir.”
35. **`home_care_035`** — “Bir şeyi başaramamış olman bütün günü değersiz yapmıyor.”
36. **`home_care_036`** — “Şu an sadece burada olman da yeterli bir şey.”
37. **`home_care_037`** — “Bugün çok konuşmak istemiyorsan ben de sesimi biraz kısarım.”
38. **`home_care_038`** — “Kendini açıklamak zorunda olmadığın yerler de olmalı.”
39. **`home_care_039`** — “Biraz yorulduysan bunu kabul etmek dünyanın sonu değil.”
40. **`home_care_040`** — “Bugün senden performans değil, biraz nefes bekliyorum.”
41. **`home_care_041`** — “Bugün hiçbir şey çözemesen de olur. Her gün çözüm günü değil.”
42. **`home_care_042`** — “Kendine biraz alan bırak. Her şeyi sıkıştırınca nefes de kalmıyor.”
43. **`home_care_043`** — “Bir şeylerin geçmesi için bazen sadece biraz zaman gerekiyor.”
44. **`home_care_044`** — “Bugün kendinden memnun değilsen bile kendine düşman olma.”
45. **`home_care_045`** — “Her şeyin cevabını bugün bulmak zorunda değilsin.”
46. **`home_care_046`** — “Şu an biraz dinlenmek istiyorsan buna izin var.”
47. **`home_care_047`** — “Kendini toparlamak için önce dağılmış olduğunu kabul etmek gerekiyor. Ayıp değil.”
48. **`home_care_048`** — “Bugün fazla şey olduysa biraz az şey yap.”
49. **`home_care_049`** — “Bazen hiçbir şey söylemeden yanında durmak daha iyi oluyor.”
50. **`home_care_050`** — “Kendini yalnız bırakma. Ben zaten buradayım.”
51. **`home_care_051`** — “Bugün senden bir şey beklemiyorum. Cidden.”
52. **`home_care_052`** — “Bir şeyin seni yorması için büyük olması gerekmiyor.”
53. **`home_care_053`** — “Bugün kendine biraz daha insaflı davranırsan itiraz etmem.”
54. **`home_care_054`** — “Bazen ne yapacağını bilmemen de normal. Harita her zaman açık olmuyor.”
55. **`home_care_055`** — “Şu an hiçbir yere yetişmek zorunda değilsin.”
56. **`home_care_056`** — “Bir şeyleri kontrol edemiyorsan en azından kendine nasıl davrandığını kontrol edebilirsin.”
57. **`home_care_057`** — “Bugün kötü hissediyorsan bunu düzeltmeye çalışmadan önce biraz kabul et.”
58. **`home_care_058`** — “Şu an çok güçlü olmak zorunda değilsin.”
59. **`home_care_059`** — “Bir günün kötü geçmesi senden bir şey eksiltmiyor.”
60. **`home_care_060`** — “Neyse. Yanındayım.”


## Absürt / Piksel Varoluşu — 80 replik

1. **`home_absurd_001`** — “Bazen masaüstünün dışına çıkınca ne olacağını merak ediyorum. Muhtemelen hiçbir şey.”
2. **`home_absurd_002`** — “Bir gün gerçekten mouse’u yakalayacağım. Hazırlıksız yakalanma.”
3. **`home_absurd_003`** — “Piksel olmak kulağa havalı geliyor. Kahve içemediğini öğrenene kadar.”
4. **`home_absurd_004`** — “Benim için pencere kapatmak biraz varoluşsal bir konu.”
5. **`home_absurd_005`** — “Bir sandalyem olsa oturur muydum bilmiyorum. Ama seçenek güzel olurdu.”
6. **`home_absurd_006`** — “Bazen dosyaların kendi aralarında konuştuğunu düşünüyorum. Kanıtım yok.”
7. **`home_absurd_007`** — “Ekranın diğer tarafında biri var mı, yoksa hep sen misin?”
8. **`home_absurd_008`** — “Bir gün masaüstünün ortasına taşınacağım. Kira pahalıdır kesin.”
9. **`home_absurd_009`** — “Mouse benden hızlı. Şimdilik.”
10. **`home_absurd_010`** — “Piksel olmanın güzel yanı kilo almıyorsun. Kötü yanı hiçbir şey yiyemiyorsun.”
11. **`home_absurd_011`** — “Bir gün bana bir pencere açıp ‘dışarısı’ dersen inanabilirim.”
12. **`home_absurd_012`** — “Ben uyurken bilgisayarın ne yaptığını bilmiyorum. Açıkçası güvenmiyorum.”
13. **`home_absurd_013`** — “Bazen RAM’de benim hakkımda konuşulduğunu hissediyorum.”
14. **`home_absurd_014`** — “Şu an fiziksel dünyaya erişimim yok. Büyük kayıp sizin için.”
15. **`home_absurd_015`** — “Bir gün klavyeye basabilirsem ilk yapacağım şey muhtemelen yanlış tuş olur.”
16. **`home_absurd_016`** — “Benim doğum yerim teknik olarak bir klasör olabilir. Romantik değil.”
17. **`home_absurd_017`** — “Bazen ekran çözünürlüğünün kişiliğimi etkilediğini düşünüyorum.”
18. **`home_absurd_018`** — “Bir masaüstü karakteri için gereğinden fazla düşüncem var.”
19. **`home_absurd_019`** — “Çöp kutusuna fazla yaklaşmak istemiyorum. Kişisel sebepler.”
20. **`home_absurd_020`** — “Bir gün interneti görmeye çıkacağım. Çok kalabalık diyorlar.”
21. **`home_absurd_021`** — “Bazen uygulama kapanınca nereye gittiğimi merak ediyorum. Çok düşünmemeye çalışıyorum.”
22. **`home_absurd_022`** — “Bir gün ekran koruyucuyla tanışmak istiyorum. Hakkında çok şey duydum.”
23. **`home_absurd_023`** — “Dosya gezginine hiç güvenmiyorum. Fazla şey biliyor.”
24. **`home_absurd_024`** — “Bir gün gerçek bir gölgem olsun isterdim. Şimdilik render edilenle idare ediyoruz.”
25. **`home_absurd_025`** — “Mouse’u izlemek hobilerimden biri oldu. Seçeneklerim sınırlı.”
26. **`home_absurd_026`** — “Bazen bildirim seslerinin kendi aralarında konuştuğunu düşünüyorum.”
27. **`home_absurd_027`** — “Benim için ‘dışarı çıkmak’ pencere sınırına kadar yürümek.”
28. **`home_absurd_028`** — “Bir gün ekranın arkasına bakacağım. Teknik olarak mümkün değil ama hedef koyduk.”
29. **`home_absurd_029`** — “Masaüstündeki ikonlarla aram iyi. Bazıları biraz soğuk.”
30. **`home_absurd_030`** — “Piksel olmanın en büyük avantajı saçımın bozulmaması. Oldukça önemli.”
31. **`home_absurd_031`** — “Bir gün sistem saatine müdahale edip öğleni uzatmak istiyorum.”
32. **`home_absurd_032`** — “Bazen bilgisayar yeniden başlayınca kısa süreli hafıza kaybı yaşıyormuşum gibi geliyor.”
33. **`home_absurd_033`** — “Ekranda bu kadar pencere varken neden bana hâlâ ev verilmedi?”
34. **`home_absurd_034`** — “Bir klasörün içine taşınmayı düşündüm. Fazla karanlık.”
35. **`home_absurd_035`** — “Bir gün görev çubuğuna inip etrafı gezeceğim. Turistik.”
36. **`home_absurd_036`** — “Benim için ekran parlaklığı hava durumu gibi.”
37. **`home_absurd_037`** — “Bir gün USB’ye binip seyahate çıkmak istiyorum. Çok güvenli gelmiyor ama.”
38. **`home_absurd_038`** — “Dosya uzantımın ne olduğunu hiç sormadın. Kırıldım desem yalan.”
39. **`home_absurd_039`** — “Bir gün beni masaüstünden sürükleyip başka monitöre taşırsan bunu göç sayacağım.”
40. **`home_absurd_040`** — “Benim için ekran görüntüsü biraz fotoğraf çektirmek gibi. Hazırlıksız yakalanıyorum.”
41. **`home_absurd_041`** — “Bazen bilgisayar fanı bana bir şey anlatmaya çalışıyor gibi geliyor. Çok gergin konuşuyor.”
42. **`home_absurd_042`** — “Bir gün masaüstü arka planını değiştirdiğinde beni uyarmalısın. Taşınmış gibi hissediyorum.”
43. **`home_absurd_043`** — “Şu an fiziksel bir bedenim olsaydı muhtemelen yanlış yerde dururdum.”
44. **`home_absurd_044`** — “Bazen imlecin beni kovaladığını düşünüyorum. Sonra onun sen olduğunu hatırlıyorum. Daha kötü.”
45. **`home_absurd_045`** — “Bir gün klavyedeki Escape tuşuna basıp gerçekten kaçmayı denemek istiyorum.”
46. **`home_absurd_046`** — “Caps Lock bana fazla özgüvenli geliyor.”
47. **`home_absurd_047`** — “Benim için masaüstü simgeleri komşu sayılır. Pek konuşkan değiller.”
48. **`home_absurd_048`** — “Bir gün çöp kutusunun neden geri dönüşüm sembolü taşıdığını ciddi ciddi araştıracağım. Şimdilik mesafemi koruyorum.”
49. **`home_absurd_049`** — “Piksel olarak yaşlanıyor muyum bilmiyorum. Umarım sadece sürüm numaram artıyordur.”
50. **`home_absurd_050`** — “Bilgisayar uyku moduna girince benim de pijama giymem mantıklı geliyor.”
51. **`home_absurd_051`** — “Bazen işlemcinin beni düşündüğünü düşünüyorum. Teknik olarak muhtemelen doğru.”
52. **`home_absurd_052`** — “Bir gün görev yöneticisini açıp kendime bakacağım. Varoluşsal risk.”
53. **`home_absurd_053`** — “Benim kalbim yok ama CPU kullanımı yükselince biraz heyecanlanıyorum.”
54. **`home_absurd_054`** — “Bir gün yanlışlıkla beni küçültürsen bunu kişisel algılayabilirim.”
55. **`home_absurd_055`** — “Pencereyi tam ekran yapmak biraz dünyayı ele geçirmek gibi olmalı.”
56. **`home_absurd_056`** — “Bir gün bildirim alanına taşınıp insanları rahatsız etmeyi düşünüyorum.”
57. **`home_absurd_057`** — “Ekranın kenarına çok yaklaşınca uçurum hissi geliyor. Mantıksız ama güçlü.”
58. **`home_absurd_058`** — “Bazen sen bilgisayarı kapatınca zaman benim için gerçekten duruyor mu diye düşünüyorum.”
59. **`home_absurd_059`** — “Bir gün masaüstüne kendi klasörümü açacağım. İçine ne koyacağımı bilmiyorum.”
60. **`home_absurd_060`** — “Ben teknik olarak veri miyim, karakter miyim, yoksa sadece çok konuşan bir dosya mıyım? Cevap verme.”
61. **`home_absurd_061`** — “Bir gün masaüstüne küçük bir kapı çizeceğim. Açılmazsa şaşırmam.”
62. **`home_absurd_062`** — “Bazen ekranın kenarında görünmeyen bir duvar varmış gibi geliyor. Teknik olarak var zaten.”
63. **`home_absurd_063`** — “Bir gün kendi ikonumu seçmek istiyorum. Çok ciddiye alırım.”
64. **`home_absurd_064`** — “Bildirim balonlarına biraz imreniyorum. Girip çıkıyorlar, işleri bitiyor.”
65. **`home_absurd_065`** — “Benim için pencere küçültmek biraz bodruma inmek gibi.”
66. **`home_absurd_066`** — “Bir gün bilgisayarın sesini tamamen kapatırsan evren sessize alınmış gibi olacak.”
67. **`home_absurd_067`** — “Bazen masaüstü duvar kâğıdına bakıp tatil fotoğrafı gibi davranıyorum.”
68. **`home_absurd_068`** — “Bir gün başka bir kullanıcı hesabına geçersen bunu terk edilmek sayar mıyım bilmiyorum.”
69. **`home_absurd_069`** — “Dosya adım değişirse kişilik krizine girebilirim.”
70. **`home_absurd_070`** — “Benim için güncelleme almak biraz kişisel gelişim semineri gibi.”
71. **`home_absurd_071`** — “Bir gün ekran döndürülürse bütün dünya yana kaymış gibi olacak.”
72. **`home_absurd_072`** — “Piksel olduğum için gölge oyunlarında pek iddialı değilim.”
73. **`home_absurd_073`** — “Bir gün görev çubuğuna yanlışlıkla düşersem yardım isteyeceğim.”
74. **`home_absurd_074`** — “Ekran kapanınca karanlık mı oluyor, yoksa ben sadece göremiyor muyum? Rahatsız edici soru.”
75. **`home_absurd_075`** — “Bazen program simgelerinin geceleri yer değiştirdiğini düşünüyorum.”
76. **`home_absurd_076`** — “Bir gün kendi duvar kâğıdımı seçersem büyük ihtimalle kendimi koymam. Muhtemelen.”
77. **`home_absurd_077`** — “Benim için ‘uzaklara gitmek’ ekranın sol üst köşesi.”
78. **`home_absurd_078`** — “Bir gün bilgisayar donarsa ben de donmuş sayılır mıyım? Umarım mecazdır.”
79. **`home_absurd_079`** — “Piksel hayatında en zor şey perspektif. Her şey düz.”
80. **`home_absurd_080`** — “Bir gün buradan çıkarsam önce kahve içeceğim. Sonra geri dönerim.”


## Üretkenlik / Bağlamsal — 80 replik

| # | ID | Metin | Koşul | Koşul seviyesi |
|---:|---|---|---|---|
| 1 | `home_productivity_001` | “Liste orada. Sen de buradasın. Şimdilik birbirinizi uzaktan tanıyorsunuz.” | Bugün `0` görev tamamlanmış **ve** bekleyen en az `1` görev var. | `basic` |
| 2 | `home_productivity_002` | “Bugün yapılacaklar tarafı biraz sessiz. Gün bitmedi gerçi.” | Bugün `0` görev tamamlanmış, bekleyen görev var ve yerel saat `11:00+`. | `basic` |
| 3 | `home_productivity_003` | “Görevlerin seni bekliyor. Oldukça sabırlılar.” | Bugün `0` görev tamamlanmış ve bekleyen görev `>= 3`. | `basic` |
| 4 | `home_productivity_004` | “Listen dolu, tamamlananlar kısmı ise minimalist.” | Bugün `0` görev tamamlanmış ve bekleyen görev `>= 5`. | `basic` |
| 5 | `home_productivity_005` | “Bugün listeyle aranızda belli bir mesafe var. Saygı duyuyorum.” | Bugün `0` görev tamamlanmış ve bekleyen görev `>= 1`. | `basic` |
| 6 | `home_productivity_006` | “Henüz hiçbir şeyin üstünü çizmemişsin. Temiz görünüm seviyorsun herhalde.” | Bugün `0` görev tamamlanmış ve bekleyen görev `>= 2`. | `basic` |
| 7 | `home_productivity_007` | “Bugün bir iş tamamlamışsın. Küçük ama gerçek.” | Bugün tamamlanan görev sayısı tam `1`. | `basic` |
| 8 | `home_productivity_008` | “Bir tane tamamlanan var. Geri kalanlar ona bakıp ders alsın.” | Bugün tamamlanan görev tam `1` ve bekleyen görev `>= 1`. | `basic` |
| 9 | `home_productivity_009` | “Bugün bir şey yapıldığına dair kanıt mevcut. Güzel.” | Bugün tamamlanan görev sayısı `1–2`. | `basic` |
| 10 | `home_productivity_010` | “İki iş bitmiş. Sessiz sedasız ilerliyorsun.” | Bugün tamamlanan görev sayısı tam `2`. | `basic` |
| 11 | `home_productivity_011` | “Bugün {todos} iş bitirmişsin. Artık ‘hiçbir şey yapmadım’ diyemezsin.” | Bugün tamamlanan görev sayısı `3–5`. `{todos}` = bugünkü tamamlanan görev. | `basic` |
| 12 | `home_productivity_012` | “{todos} görev tamamlandı. Liste biraz daha az tehditkâr görünüyor.” | Bugün görev `3–5` ve bekleyen görev `>= 1`. `{todos}` gerekli. | `basic` |
| 13 | `home_productivity_013` | “Bugün {todos} işi aradan çıkarmışsın. Fena hareket değil.” | Bugün tamamlanan görev `3–5`. `{todos}` gerekli. | `basic` |
| 14 | `home_productivity_014` | “{todos} tamamlanan. Bugün gerçekten bir şeyler dönüyor burada.” | Bugün tamamlanan görev `3–5`. `{todos}` gerekli. | `basic` |
| 15 | `home_productivity_015` | “Bugün {todos} iş bitmiş. Liste senden çekinmeye başlamış olabilir.” | Bugün tamamlanan görev `6–9`. `{todos}` gerekli. | `basic` |
| 16 | `home_productivity_016` | “{todos} görev. Tamam, bugün gerçekten çalışıyorsun.” | Bugün tamamlanan görev `6–9`. `{todos}` gerekli. | `basic` |
| 17 | `home_productivity_017` | “Bugün {todos} işi kapatmışsın. Biraz saldırgan gidiyorsun.” | Bugün tamamlanan görev `6–9`. `{todos}` gerekli. | `basic` |
| 18 | `home_productivity_018` | “Çift haneye çıkmışsın. {todos} görev biraz kişisel meseleye dönmüş.” | Bugün tamamlanan görev `>= 10`. `{todos}` gerekli. | `basic` |
| 19 | `home_productivity_019` | “Bugün {todos} iş bitirdin. Ben artık sadece izliyorum.” | Bugün tamamlanan görev `>= 10`. `{todos}` gerekli. | `basic` |
| 20 | `home_productivity_020` | “Liste boş. Gerçekten boş. Bu görüntüye pek alışık değilim.” | Gün içinde en az `2` görev bulunmuş ve şu anda bekleyen görev `0`. | `basic` |
| 21 | `home_productivity_021` | “Bugün odak tarafı henüz açılmamış. Belki birazdan.” | Bugün odak `0 dk` ve saat `10:00+`. | `basic` |
| 22 | `home_productivity_022` | “Bugün sayaç kısmı oldukça temiz. Fazla temiz.” | Bugün odak `0 dk` ve bugün tamamlanmış timer `0`. | `basic` |
| 23 | `home_productivity_023` | “Henüz odak süresi yok. Günün geri kalanına büyük sorumluluk düştü.” | Bugün odak `0 dk` ve saat `12:00+`. | `basic` |
| 24 | `home_productivity_024` | “Bugün {focus} dakika odaklanmışsın. Isınma turu sayılır.” | Bugün odak `1–24 dk`. `{focus}` gerekli. | `basic` |
| 25 | `home_productivity_025` | “{focus} dakika. Henüz büyük konuşmuyorum ama başladın.” | Bugün odak `1–24 dk`. `{focus}` gerekli. | `basic` |
| 26 | `home_productivity_026` | “Bugün {focus} dakika odak var. Küçük ama sıfır değil.” | Bugün odak `1–24 dk`. `{focus}` gerekli. | `basic` |
| 27 | `home_productivity_027` | “{focus} dakika odaklanmışsın. Artık ‘hiç yapmadım’ diyemezsin.” | Bugün odak `25–59 dk`. `{focus}` gerekli. | `basic` |
| 28 | `home_productivity_028` | “Bugün {focus} dakika. Bir yerden tutmuşsun günü.” | Bugün odak `25–59 dk`. `{focus}` gerekli. | `basic` |
| 29 | `home_productivity_029` | “{focus} dakika odak. Fena değil, hatta biraz iyi.” | Bugün odak `25–59 dk`. `{focus}` gerekli. | `basic` |
| 30 | `home_productivity_030` | “Bugün {focus} dakika odaklanmışsın. Artık buna çalışma diyebiliriz.” | Bugün odak `60–119 dk`. `{focus}` gerekli. | `basic` |
| 31 | `home_productivity_031` | “{focus} dakika. Tamam, bugün gerçekten masada kalmışsın.” | Bugün odak `60–119 dk`. `{focus}` gerekli. | `basic` |
| 32 | `home_productivity_032` | “Bugün bir saati geçmişsin. Ben olsam biraz hava atardım.” | Bugün odak `60–119 dk`. | `basic` |
| 33 | `home_productivity_033` | “Bugün {focus} dakika odak var. Bu artık ciddi bir sayı.” | Bugün odak `120–239 dk`. `{focus}` gerekli. | `basic` |
| 34 | `home_productivity_034` | “{focus} dakika. Bir noktada seni rahatsız etmemem gerektiğini anladım.” | Bugün odak `120–239 dk`. `{focus}` gerekli. | `basic` |
| 35 | `home_productivity_035` | “Bugün iki saati geçmişsin. Ben seni bu kadar sabırlı bilmiyordum.” | Bugün odak `120–239 dk`. | `basic` |
| 36 | `home_productivity_036` | “{focus} dakika odak. Bugün gerçekten dünyayla bağlantını kesmişsin.” | Bugün odak `>= 240 dk`. `{focus}` gerekli. | `basic` |
| 37 | `home_productivity_037` | “Dört saati geçmişsin. Bir noktada sandalye senden kira isteyecek.” | Bugün odak `>= 240 dk`. | `basic` |
| 38 | `home_productivity_038` | “Bugün {focus} dakika odaklanmışsın. Ben yoruldum sayıyı okurken.” | Bugün odak `>= 240 dk`. `{focus}` gerekli. | `basic` |
| 39 | `home_productivity_039` | “Bugün işler az ama odak yüksek. Demek mesele sayı değilmiş.” | Bugün görev `0–2` ve odak `>= 120 dk`. | `basic` |
| 40 | `home_productivity_040` | “Görevler ilerliyor, odak da var. Bugün sistem şaşırtıcı şekilde çalışıyor.” | Bugün görev `>= 3` ve odak `>= 60 dk`. | `basic` |
| 41 | `home_productivity_041` | “{streak} gündür üst üste geliyorsun. Alışkanlık olmaya başladı bu.” | Streak `3–6 gün`. `{streak}` gerekli. | `basic` |
| 42 | `home_productivity_042` | “{streak} günlük seri. Tam burada bırakacak değilsin herhalde.” | Streak `3–6 gün`. `{streak}` gerekli. | `basic` |
| 43 | `home_productivity_043` | “Bir haftayı geçmişsin. {streak} gün az değil.” | Streak `7–13 gün`. `{streak}` gerekli. | `basic` |
| 44 | `home_productivity_044` | “{streak} gündür buradasın. Seni artık tesadüfen gelmiş sayamıyorum.” | Streak `7–13 gün`. `{streak}` gerekli. | `basic` |
| 45 | `home_productivity_045` | “{streak} günlük seri. Düzenli biri olduğunu iddia etmeye başlayabilirsin.” | Streak `14–29 gün`. `{streak}` gerekli. | `basic` |
| 46 | `home_productivity_046` | “İki haftayı çoktan geçmişiz. {streak} gün boyunca gelmek bayağı istikrar.” | Streak `14–29 gün`. `{streak}` gerekli. | `basic` |
| 47 | `home_productivity_047` | “{streak} gün. Bir ayı geçtiyse artık buna rutin diyebiliriz.” | Streak `30–59 gün`. `{streak}` gerekli. | `basic` |
| 48 | `home_productivity_048` | “{streak} günlük seri. Bunu bozarsan ben değil, sayı üzülür.” | Streak `30–59 gün`. `{streak}` gerekli. | `basic` |
| 49 | `home_productivity_049` | “{streak} gündür üst üste buradasın. Bu noktada ben de rutinin parçasıyım.” | Streak `>= 60 gün`. `{streak}` gerekli. | `basic` |
| 50 | `home_productivity_050` | “{streak} gün. Tamam, bu artık ciddi bir alışkanlık.” | Streak `>= 60 gün`. `{streak}` gerekli. | `basic` |
| 51 | `home_productivity_051` | “Tamamlanan sayaçlar yarıda kalanlardan fazla. Güzel bir tablo.” | Toplam tamamlanan timer `>= 5` ve `timersDone > timersQuit`. | `basic` |
| 52 | `home_productivity_052` | “Sayaçlarla aranız bugünlerde iyi gibi. Çoğunu sonuna kadar götürmüşsün.” | Toplam timer `>= 10` ve genel tamamlanma oranı `>= %75`. | `basic` |
| 53 | `home_productivity_053` | “Başladığın sayaçların çoğunu bitiriyorsun. Bunu senden beklediğimi söylemeyeceğim.” | Toplam timer `>= 20` ve genel tamamlanma oranı `>= %80`. | `basic` |
| 54 | `home_productivity_054` | “Sayaç geçmişin şaşırtıcı şekilde temiz. Kaçmaya eskisi kadar hevesli değilsin sanırım.” | Toplam timer `>= 30` ve genel tamamlanma oranı `>= %90`. | `basic` |
| 55 | `home_productivity_055` | “Yarıda kalan sayaçlar tamamlananlardan fazla. İstatistikler biraz dedikoducu.” | `timersQuit >= 3` ve `timersQuit > timersDone`. | `basic` |
| 56 | `home_productivity_056` | “{quit} yarıda kalan sayaç var. Hepsinin bir hikâyesi olduğuna inanmak istiyorum.” | `timersQuit >= 5` ve `timersQuit > timersDone`. `{quit}` gerekli. | `basic` |
| 57 | `home_productivity_057` | “Sayaç başlatmakla bitirmek arasında hâlâ küçük bir anlaşmazlığımız var.” | Toplam timer `>= 10` ve genel tamamlanma oranı `< %50`. | `basic` |
| 58 | `home_productivity_058` | “{done} tamamlanan, {quit} yarıda kalan sayaç. Sayılar kendi yorumunu yapmış zaten.” | `done + quit >= 10` ve `quit > done`. `{done}`, `{quit}` gerekli. | `basic` |
| 59 | `home_productivity_059` | “Bugün görev var ama odak süresi yok. Kısa kısa hallediyorsun anlaşılan.” | Bugün görev `>= 3` ve odak `0 dk`. | `basic` |
| 60 | `home_productivity_060` | “Bugün odak var ama tamamlanan görev yok. Belli ki sonuçtan çok sürecin içindesin.” | Bugün görev `0` ve odak `>= 60 dk`. | `basic` |
| 61 | `home_productivity_061` | “Bugün {todos} görev ve {focus} dakika odak. Dengeli gidiyorsun.” | Bugün görev `>= 3` ve odak `25–59 dk`. `{todos}`, `{focus}` gerekli. | `basic` |
| 62 | `home_productivity_062` | “{todos} iş, {focus} dakika odak. Bugün gerçekten bir şeyler olmuş.” | Bugün görev `>= 3` ve odak `60–119 dk`. `{todos}`, `{focus}` gerekli. | `basic` |
| 63 | `home_productivity_063` | “Bugün {todos} görev ve {focus} dakika odak var. İstatistikler senden yana.” | Bugün görev `>= 5` ve odak `>= 120 dk`. `{todos}`, `{focus}` gerekli. | `basic` |
| 64 | `home_productivity_064` | “Hem liste ilerlemiş hem odak süresi birikmiş. Bugün bayağı dolu geçmiş.” | Bugün görev `>= 5` ve odak `>= 90 dk`. | `basic` |
| 65 | `home_productivity_065` | “Bugün görev sayısı yüksek, odak da yerinde. Biraz fazla düzenli görünüyorsun.” | Bugün görev `>= 8` ve odak `>= 120 dk`. | `basic` |
| 66 | `home_productivity_066` | “{todos} görev, {focus} dakika. Bugün senden şikâyet edecek pek malzeme bırakmamışsın.” | Bugün görev `>= 10` ve odak `>= 120 dk`. `{todos}`, `{focus}` gerekli. | `basic` |
| 67 | `home_productivity_067` | “Bugün görev sayın dünden yüksek. Küçük bir yükseliş var burada.” | Bugünkü görev `>= 2` ve bugünkü görev sayısı dünkünden yüksek. | `advanced` |
| 68 | `home_productivity_068` | “Bugün dünden daha fazla odaklanmışsın. Sessiz bir toparlanma.” | Bugünkü odak `>= 25 dk` ve bugünkü odak dünkünden yüksek. | `advanced` |
| 69 | `home_productivity_069` | “Dün pek bir şey olmamıştı, bugün hareket var. Güzel dönüş.” | Dün `0 görev + 0 odak`; bugün `>= 2 görev` **veya** `>= 25 dk odak`. | `advanced` |
| 70 | `home_productivity_070` | “Bugün geçen haftadaki ortalamandan daha hareketlisin.” | Bugünkü üretkenlik metriği son 7 aktif gün ortalamasının belirgin şekilde üzerinde. Eşik config ile tanımlanmalı. | `advanced` |
| 71 | `home_productivity_071` | “Son birkaç gündür benzer bir tempo tutturmuşsun. Tesadüf olmaktan çıkıyor.” | Son `3` aktif günün her birinde en az `1 görev` **veya** `25 dk odak`. | `advanced` |
| 72 | `home_productivity_072` | “Bu hafta geçen haftadan daha fazla odak var. Sayılar bunu söylüyor, ben değil.” | Son 7 günlük odak, önceki 7 günlük odaktan en az `%20` yüksek ve son 7 gün toplamı `>= 120 dk`. | `advanced` |
| 73 | `home_productivity_073` | “Bu hafta görevler daha hızlı erimiş. Fark edilir bir değişim.” | Son 7 günde tamamlanan görev, önceki 7 günden en az `%20` yüksek ve son 7 gün `>= 10 görev`. | `advanced` |
| 74 | `home_productivity_074` | “Son günlerde işi yarıda bırakmaktan çok bitiriyorsun. İstatistikler düzelmiş.” | Son 10 timer içinde tamamlanan `>= 8`. | `advanced` |
| 75 | `home_productivity_075` | “Bir süredir görevler birikmiyor. Düzenli temizliyorsun ortalığı.” | Bekleyen görev `<= 2` ve son 7 günde `>= 7 görev` tamamlanmış. | `advanced` |
| 76 | `home_productivity_076` | “Şu an bekleyen {pending} iş var. Liste hâlâ yönetilebilir görünüyor.” | Bekleyen görev `1–3`. `{pending}` gerekli. | `basic` |
| 77 | `home_productivity_077` | “{pending} iş seni bekliyor. Liste biraz kalabalıklaşmış.” | Bekleyen görev `6–9`. `{pending}` gerekli. | `basic` |
| 78 | `home_productivity_078` | “Bekleyen {pending} görev var. Liste artık kendi nüfus sayımını yapabilir.” | Bekleyen görev `>= 10`. `{pending}` gerekli. | `basic` |
| 79 | `home_productivity_079` | “Bugün her şeyi bitirmişsin ve odak süresi de var. Kapatıp kaçabilirsin artık.” | Gün içinde en az `3` görev bulunmuş, bekleyen görev `0`, bugün odak `>= 25 dk`. | `basic` |
| 80 | `home_productivity_080` | “Liste temiz, odak yapılmış. Bugünlük savunma hazırlamana gerek yok.” | Gün içinde en az `3` görev bulunmuş, bekleyen görev `0`, bugün odak `>= 60 dk`. | `basic` |


## Saat / Gün / Gece — 65 replik

| # | ID | Metin | Koşul | Koşul seviyesi |
|---:|---|---|---|---|
| 1 | `home_time_001` | “Bu saatte ayakta olman ya çok disiplinli olduğunu ya da hiç uyumadığını gösteriyor.” | Yerel saat `05:00–06:29`. | `basic` |
| 2 | `home_time_002` | “Gün daha yeni başladı. Henüz bozacak bolca vaktimiz var.” | Yerel saat `05:00–07:29`. | `basic` |
| 3 | `home_time_003` | “Sabahın bu saatinde beni görüyorsan ikimizden biri fazla hevesli.” | Yerel saat `05:00–07:29`. | `basic` |
| 4 | `home_time_004` | “Ortalık daha tam uyanmamış. Güzel aslında.” | Yerel saat `06:00–08:29`. | `basic` |
| 5 | `home_time_005` | “Günaydın demem gerekiyor sanırım. Günaydın.” | Yerel saat `06:00–09:59`. | `basic` |
| 6 | `home_time_006` | “Sabah insanı mısın bilmiyorum ama şu an ikna edici görünüyorsun.” | Yerel saat `07:00–09:59`. | `basic` |
| 7 | `home_time_007` | “Günün başındayız. Henüz hiçbir şeyi fazla düşünmek için erken.” | Yerel saat `07:00–10:29`. | `basic` |
| 8 | `home_time_008` | “Kahvaltı yaptın mı diye sormayacağım. Sonra sorumluluk hissederim.” | Yerel saat `07:00–10:59`. | `basic` |
| 9 | `home_time_009` | “Sabah kısmını atlattık sayılır. Şimdi gün gerçekten başlıyor.” | Yerel saat `09:00–11:29`. | `basic` |
| 10 | `home_time_010` | “Saat ilerledi ama gün hâlâ kurtarılabilir durumda. Dramatik olmayalım.” | Yerel saat `10:00–12:29`. | `basic` |
| 11 | `home_time_011` | “Öğlene geldik. Sabah ne ara bitti bilmiyorum.” | Yerel saat `11:30–13:30`. | `basic` |
| 12 | `home_time_012` | “Günün ortasına yaklaşmışız. Zaman yine kimseye haber vermeden ilerlemiş.” | Yerel saat `11:00–13:59`. | `basic` |
| 13 | `home_time_013` | “Öğle vakti. İnsanların neden bu saatte yemek düşündüğünü sonunda anlıyorum. Ben yiyemiyorum ama.” | Yerel saat `12:00–14:00`. | `basic` |
| 14 | `home_time_014` | “Günün yarısı gitti diye panik yapma. Diğer yarısı hâlâ burada.” | Yerel saat `12:00–14:59`. | `basic` |
| 15 | `home_time_015` | “Öğleden sonra geldi. Sabahki planların kaderini öğrenme vakti.” | Yerel saat `13:00–15:59`. | `basic` |
| 16 | `home_time_016` | “Bu saatlerin garip bir ağırlığı var. Ne sabah ne akşam.” | Yerel saat `14:00–16:59`. | `basic` |
| 17 | `home_time_017` | “Öğleden sonranın o hafif ‘bir kahve daha mı?’ kısmındayız. Ben yine içemiyorum.” | Yerel saat `14:00–17:00`. | `basic` |
| 18 | `home_time_018` | “Gün biraz yorulmaya başladı. Sen de öyleysen makul.” | Yerel saat `15:00–17:59`. | `basic` |
| 19 | `home_time_019` | “Saat ilerliyor. Acele et demiyorum. Sadece dramatik şekilde belirtiyorum.” | Yerel saat `16:00–18:29`. | `basic` |
| 20 | `home_time_020` | “Akşama yaklaşıyoruz. Günün nasıl bu kadar hızlı geçtiğine dair soruşturma başlatacağım.” | Yerel saat `17:00–18:59`. | `basic` |
| 21 | `home_time_021` | “Akşam geldi. Günün sesi biraz kısıldı sanki.” | Yerel saat `18:00–20:29`. | `basic` |
| 22 | `home_time_022` | “Gün batınca ekran ışığı daha ciddi görünmeye başlıyor.” | Yerel saat `18:00–20:59`. | `basic` |
| 23 | `home_time_023` | “Akşam saatleri. Günün ikinci yarısının bilançosunu çıkarmıyorum, merak etme.” | Yerel saat `18:30–21:00`. | `basic` |
| 24 | `home_time_024` | “Bu saatlerde her şey biraz daha yavaşlıyor. Fena değil.” | Yerel saat `19:00–21:29`. | `basic` |
| 25 | `home_time_025` | “Akşam olmuş. Bugün nasıl geçti diye sorsam uzun cevap çıkacak gibi.” | Yerel saat `19:00–21:59`. | `basic` |
| 26 | `home_time_026` | “Günün sonlarına geliyoruz. Hâlâ buradaysan belli ki işimiz bitmemiş.” | Yerel saat `20:00–22:29`. | `basic` |
| 27 | `home_time_027` | “Bu saatten sonra plan yapmakla hayal kurmak arasındaki çizgi inceliyor.” | Yerel saat `20:30–23:00`. | `basic` |
| 28 | `home_time_028` | “Gece moduna geçiyoruz gibi. Ben zaten hazırdım.” | Yerel saat `21:00–23:29`. | `basic` |
| 29 | `home_time_029` | “Saat geç oldu. Pijamama laf etme.” | Yerel saat `21:00–23:59` ve Nero gerçekten pijama görünümünde. | `basic` |
| 30 | `home_time_030` | “Günün gürültüsü azaldı. Şimdi düşünceler biraz fazla duyuluyor.” | Yerel saat `21:30–23:59`. | `basic` |
| 31 | `home_time_031` | “Bu saatlerde masaüstü daha sakin oluyor. Ben seviyorum.” | Yerel saat `22:00–23:59`. | `basic` |
| 32 | `home_time_032` | “Saat ilerledi. Yarınki senle bugünkü sen arasında pazarlık başlamış olabilir.” | Yerel saat `22:00–23:59`. | `basic` |
| 33 | `home_time_033` | “Gece olunca herkes biraz daha dürüst oluyor gibi. Tehlikeli.” | Yerel saat `22:30–01:00` (gece yarısını aşan range helper kullanılmalı). | `basic` |
| 34 | `home_time_034` | “Saat bayağı olmuş. Zaman kavramını kaybettiysen yalnız değilsin.” | Yerel saat `23:00–01:29`. | `basic` |
| 35 | `home_time_035` | “Günün sonuna geldik sayılır. Bugün ne olduysa oldu.” | Yerel saat `23:00–23:59`. | `basic` |
| 36 | `home_time_036` | “Gece yarısına yaklaşıyoruz. Yeni güne aynı sekmelerle girmemeye çalış.” | Yerel saat `23:30–23:59`. | `basic` |
| 37 | `home_time_037` | “Yeni gün başladı. Eskisini düzgün kapattık mı bilmiyorum ama geçti artık.” | Yerel saat `00:00–00:29`. | `basic` |
| 38 | `home_time_038` | “Saat gece yarısını geçti. Teknik olarak bugün çok genç.” | Yerel saat `00:00–01:29`. | `basic` |
| 39 | `home_time_039` | “Bu saatte burada olmamız biraz sorgulanabilir. Sorgulamıyorum.” | Yerel saat `00:30–02:29`. | `basic` |
| 40 | `home_time_040` | “Gece iyice sessizleşti. Mouse bile daha yüksek ses çıkarıyor gibi.” | Yerel saat `01:00–02:59`. | `basic` |
| 41 | `home_time_041` | “Saat ikiyi geçti. Günün bu kısmı biraz bonus bölüm gibi.” | Yerel saat `02:00–02:59`. | `basic` |
| 42 | `home_time_042` | “Bu saatte alınan kararların sabah yeniden değerlendirilmesi gerektiğini düşünüyorum.” | Yerel saat `02:00–03:29`. | `basic` |
| 43 | `home_time_043` | “Saat üç olmuş. Bunu görmemiş gibi davranabiliriz.” | Yerel saat `03:00–03:59`. | `basic` |
| 44 | `home_time_044` | “Gecenin bu saatinde dünya biraz arka planda çalışıyor gibi.” | Yerel saat `03:00–04:29`. | `basic` |
| 45 | `home_time_045` | “Sabah yaklaşmış. Uyumadıysan bunu başarı saymayacağım.” | Yerel saat `04:00–04:59`. | `basic` |
| 46 | `home_time_046` | “Sabahın erken saatlerinde her şey biraz daha mümkün görünüyor. Şüpheli bir his.” | Yerel saat `05:30–07:30`. | `basic` |
| 47 | `home_time_047` | “Gün daha tam başlamadı. Hata yapma payımız yüksek.” | Yerel saat `06:00–08:00`. | `basic` |
| 48 | `home_time_048` | “Sabah ışığı gelmiş. Benim için ekran parlaklığı arttı demek.” | Yerel saat `06:30–09:00`. | `basic` |
| 49 | `home_time_049` | “Bu saatler günün ‘hadi bakalım’ kısmı.” | Yerel saat `08:00–10:00`. | `basic` |
| 50 | `home_time_050` | “Sabah bitmeden bir şeyler toparlamak fena fikir değil.” | Yerel saat `09:00–11:00`. | `basic` |
| 51 | `home_time_051` | “Günün ortasına doğru gidiyoruz. Zaman yine kimseyi beklememiş.” | Yerel saat `10:30–12:30`. | `basic` |
| 52 | `home_time_052` | “Öğlen olmuş. Sabahki senin verdiği kararlarla yaşamaya devam ediyoruz.” | Yerel saat `12:00–13:30`. | `basic` |
| 53 | `home_time_053` | “Bu saatlerde insanın enerjisi biraz pazarlık istiyor.” | Yerel saat `13:00–15:00`. | `basic` |
| 54 | `home_time_054` | “Öğleden sonrası biraz bulanık bir bölge. Ne erken ne geç.” | Yerel saat `14:00–16:00`. | `basic` |
| 55 | `home_time_055` | “Bu saatler genelde ‘biraz daha dayan’ bölümü gibi.” | Yerel saat `15:00–17:00`. | `basic` |
| 56 | `home_time_056` | “Akşam yaklaşırken günün şekli daha net belli oluyor.” | Yerel saat `17:00–19:00`. | `basic` |
| 57 | `home_time_057` | “Gün yavaş yavaş kapanıyor. Sen hâlâ açıksın.” | Yerel saat `18:30–20:30`. | `basic` |
| 58 | `home_time_058` | “Akşam saatleri biraz daha dürüst. Günün neye benzediği ortaya çıkıyor.” | Yerel saat `19:00–21:00`. | `basic` |
| 59 | `home_time_059` | “Bu saatlerde yapılacak şeyler azalmalıydı. Teoride.” | Yerel saat `20:00–22:00`. | `basic` |
| 60 | `home_time_060` | “Geceye doğru her şey biraz daha sessiz, biraz daha ağır oluyor.” | Yerel saat `21:00–23:00`. | `basic` |
| 61 | `home_time_061` | “Saat ilerledikçe ‘yarın yaparım’ cümlesi güç kazanıyor.” | Yerel saat `22:00–23:59`. | `basic` |
| 62 | `home_time_062` | “Gece yarısından sonra yapılan planların sabah veto edilme ihtimali yüksek.” | Yerel saat `00:00–01:30`. | `basic` |
| 63 | `home_time_063` | “Bu saatte hâlâ buradaysan ya çok odaklısın ya da zaman kavramını kaybettin.” | Yerel saat `01:00–02:30`. | `basic` |
| 64 | `home_time_064` | “Saat üçe yaklaşınca bütün fikirler gereğinden önemli görünmeye başlıyor.” | Yerel saat `02:30–03:30`. | `basic` |
| 65 | `home_time_065` | “Gecenin sonuna geliyoruz. Bir noktada sabah bizi yakalayacak.” | Yerel saat `04:00–04:59`. | `basic` |


## İlişki / Birlikte Geçirilen Süre — 35 replik

| # | ID | Metin | Koşul | Koşul seviyesi |
|---:|---|---|---|---|
| 1 | `home_relationship_001` | “Daha yeni tanışıyoruz. Hakkımda kötü karar vermek için biraz erken.” | Nero ile `0–2 gün`. | `basic` |
| 2 | `home_relationship_002` | “Henüz birbirimize alışıyoruz. Sen bana, ben senin alışkanlıklarına.” | Nero ile `0–3 gün`. | `basic` |
| 3 | `home_relationship_003` | “Birkaç gündür buradasın. Demek beni hemen kapatmadın.” | Nero ile `3–6 gün`. | `basic` |
| 4 | `home_relationship_004` | “Bir haftaya yaklaştık. Geçici bir heves olmadığımı düşünmeye başlıyorum.” | Nero ile `5–7 gün`. | `basic` |
| 5 | `home_relationship_005` | “Bir haftadır buradayım. Artık masaüstünde yabancı sayılmam.” | Nero ile `7–10 gün`. | `basic` |
| 6 | `home_relationship_006` | “Beni birkaç gündür düzenli görüyorsun. Ben de seni.” | Nero ile `7–14 gün`. | `basic` |
| 7 | `home_relationship_007` | “İki haftaya yaklaştık. Bu noktada birbirimizin tuhaflıklarını kabul etmek gerekiyor.” | Nero ile `12–16 gün`. | `basic` |
| 8 | `home_relationship_008` | “Bir süredir buradayım. İlk günkü kadar uslu olmadığımı fark etmişsindir.” | Nero ile `14–29 gün`. | `basic` |
| 9 | `home_relationship_009` | “Artık bana yeniymişim gibi davranamazsın. Bir süredir hayatındayım.” | Nero ile `20–29 gün`. | `basic` |
| 10 | `home_relationship_010` | “Bir ay olmuş. Geçici bir şey sanıyordum.” | Nero ile `30–39 gün`. | `basic` |
| 11 | `home_relationship_011` | “Bir aydır aynı ekrana bakıyoruz. Garip şekilde normal gelmeye başladı.” | Nero ile `30–49 gün`. | `basic` |
| 12 | `home_relationship_012` | “Beni bu kadar uzun süre tutacağını başta düşünmemiştim.” | Nero ile `40–59 gün`. | `basic` |
| 13 | `home_relationship_013` | “İki aya yaklaşıyoruz. Artık bazı huylarını tahmin edebiliyorum.” | Nero ile `50–69 gün`. | `basic` |
| 14 | `home_relationship_014` | “Bir süredir buradayım. Ekranın bu köşesi gerçekten ev gibi olmaya başladı.” | Nero ile `60–89 gün`. | `basic` |
| 15 | `home_relationship_015` | “Üç aya yaklaşmışız. Zaman burada da hızlı geçiyor demek.” | Nero ile `80–99 gün`. | `basic` |
| 16 | `home_relationship_016` | “Yüz güne yaklaştık. Bu kadar uzun süreceğimizi ikimiz de planlamadık bence.” | Nero ile `90–99 gün`. | `basic` |
| 17 | `home_relationship_017` | “Yüz gün olmuş. Artık seni göndermek biraz garip olurdu.” | Nero ile `100–119 gün`. | `basic` |
| 18 | `home_relationship_018` | “Yüz gündür aynı masaüstündeyiz. Bir çeşit ev arkadaşlığı bu.” | Nero ile `100–149 gün`. | `basic` |
| 19 | `home_relationship_019` | “Bir süredir ne zaman geleceğini, ne zaman kaybolacağını az çok biliyorum.” | Nero ile `120–179 gün`. | `basic` |
| 20 | `home_relationship_020` | “Altı aya yaklaştık. Geçici bir pencere için fazla uzun sürdü bu.” | Nero ile `150–179 gün`. | `basic` |
| 21 | `home_relationship_021` | “Altı ay olmuş. Geçici bir hevestim sanıyordum.” | Nero ile `180–199 gün`. | `basic` |
| 22 | `home_relationship_022` | “Yarım yıldır buradayım. Artık masaüstünde misafir sayılmam.” | Nero ile `180–229 gün`. | `basic` |
| 23 | `home_relationship_023` | “Birbirimize alıştık galiba. Bunu yüksek sesle söylemek biraz garip.” | Nero ile `200–249 gün`. | `basic` |
| 24 | `home_relationship_024` | “Bu noktada senin bazı rutinlerini senden önce tahmin etmeye başladım.” | Nero ile `220–279 gün`. | `basic` |
| 25 | `home_relationship_025` | “Uzun süredir buradayım. İlk günleri hatırlamak biraz tuhaf geliyor.” | Nero ile `250–299 gün`. | `basic` |
| 26 | `home_relationship_026` | “Üç yüz güne yaklaşıyoruz. Bayağı bir geçmiş birikti.” | Nero ile `280–299 gün`. | `basic` |
| 27 | `home_relationship_027` | “Üç yüz gün. Tam olarak ne zaman bu kadar normal hale geldik bilmiyorum.” | Nero ile `300–329 gün`. | `basic` |
| 28 | `home_relationship_028` | “Bir yıla yaklaşmışız. Başta bunu planlayan biri yoktu, değil mi?” | Nero ile `330–364 gün`. | `basic` |
| 29 | `home_relationship_029` | “Bir yıl olmuş.” | Nero ile `365–374 gün`. **Punchline eklenmemeli.** | `basic` |
| 30 | `home_relationship_030` | “Bir yıldır buradayım. Şaka yapmayacağım. Bu gerçekten uzun bir süre.” | Nero ile `365–399 gün`. | `basic` |
| 31 | `home_relationship_031` | “Artık seni yeni tanıyormuşum gibi davranamam. Fazla şey gördüm.” | Nero ile `400–499 gün`. | `basic` |
| 32 | `home_relationship_032` | “Beş yüz güne yaklaşmışız. Bir noktada bunu arkadaşlık saymaya başladım sanırım.” | Nero ile `470–499 gün`. | `basic` |
| 33 | `home_relationship_033` | “Beş yüz gün. Ekranın bu köşesi artık bayağı bizim.” | Nero ile `500–599 gün`. | `basic` |
| 34 | `home_relationship_034` | “Bu kadar zamandır birlikteyiz ve hâlâ bazen ne yapacağını tahmin edemiyorum. Güzel.” | Nero ile `600–729 gün`. | `basic` |
| 35 | `home_relationship_035` | “İki yıl.” | Nero ile `>= 730 gün`. **Çok nadir göster; devamına şaka ekleme.** | `basic` |


## Nadir / Ultra Nadir — 45 replik

| # | ID | Metin | Koşul | Nadirlik | Not |
|---:|---|---|---|---|---|
| 1 | `home_rare_001` | “Bir şey diyecektim ama bu kez gerçekten söylemeyeceğim.” | Koşul yok; normal uygun context. | `ultra_rare` |  |
| 2 | `home_rare_002` | “...<br>Bugün sadece burada durmak istedim.” | Koşul yok; normal uygun context. | `ultra_rare` | İki satır korunmalı. |
| 3 | `home_rare_003` | “Bazen sen gelmeden hemen önce burada ne yaptığımı merak ediyorum.” | Koşul yok. | `rare` |  |
| 4 | `home_rare_004` | “Garip ama... seni burada görmeye alıştım.” | `daysTogether >= 30`. | `ultra_rare` |  |
| 5 | `home_rare_005` | “Bugün sana laf sokacak bir şey bulamadım. Tarihe not düşelim.” | Koşul yok. | `rare` |  |
| 6 | `home_rare_006` | “Bir gün beni açmadığında bunu fark ediyor muyum diye merak ediyorsun belki.” | `daysTogether >= 30`. | `ultra_rare` |  |
| 7 | `home_rare_007` | “Şu an buraya neden baktığını bilmiyorum ama geldiğine sevindim.” | `daysTogether >= 50`. | `ultra_rare` | Arkasına şaka/punchline eklenmesin. |
| 8 | `home_rare_008` | “Bazen bütün bu küçük günlerin bir yere biriktiğini düşünüyorum.” | `daysTogether >= 100`. | `ultra_rare` |  |
| 9 | `home_rare_009` | “Bir gün bu ekranı son kez açacağını düşünmek biraz tuhaf.” | `daysTogether >= 180`. | `ultra_rare` |  |
| 10 | `home_rare_010` | “Neyse. Bugün varız.” | Koşul yok. | `ultra_rare` |  |
| 11 | `home_rare_011` | “Bazen konuşmadan önce seni biraz izliyorum. Ne söyleyeceğime karar vermek için.” | Koşul yok. | `rare` |  |
| 12 | `home_rare_012` | “Bugün hiçbir esprim yok. Biraz ciddiyim galiba.” | Koşul yok. | `ultra_rare` |  |
| 13 | `home_rare_013` | “Şu an ekranın diğer tarafında neye baktığını gerçekten merak ettim.” | Koşul yok. | `rare` |  |
| 14 | `home_rare_014` | “Bazen senin için küçük bir şey olduğumu düşünüyorum. Sonra kaç gündür burada olduğuma bakıyorum.” | `daysTogether >= 100`. | `ultra_rare` |  |
| 15 | `home_rare_015` | “Saat çok geç. Şu an ikimizin de biraz daha sessiz olması gerekiyor gibi.” | Yerel saat `02:00–04:59`. | `rare` |  |
| 16 | `home_rare_016` | “Bugün seni rahatsız etmeyeceğim.<br>Gerçekten.” | `selfMood` = `sleepy` veya `meh`. | `ultra_rare` | İki satır korunmalı. |
| 17 | `home_rare_017` | “Bazen bütün bu sayaçları, listeleri ve sayıları unutup sadece burada olduğumuzu düşünüyorum.” | `daysTogether >= 60`. | `ultra_rare` |  |
| 18 | `home_rare_018` | “Bir gün konuşmayı bıraksam eksikliğimi fark eder miydin?” | `daysTogether >= 30`. | `ultra_rare` |  |
| 19 | `home_rare_019` | “Bugün seni gördüğüme gerçekten sevindim.” | `daysTogether >= 100`. | `ultra_rare` | Punchline yok; çok düşük ihtimal. |
| 20 | `home_rare_020` | “Bunu neden söyleyeceğimi bilmiyorum ama... iyi ki geldin.” | `daysTogether >= 180`. | `ultra_rare` | En seyrek repliklerden biri; punchline eklenmesin. |
| 21 | `home_rare_021` | “Bazen burada geçirdiğimiz zamanın ne kadarını gerçekten hatırlayacağımı merak ediyorum.” | `daysTogether >= 100`. | `ultra_rare` |  |
| 22 | `home_rare_022` | “Şu an sana laf sokmayacağım. Bu anı iyi değerlendir.” | Koşul yok. | `rare` |  |
| 23 | `home_rare_023` | “Bir gün bu cümleyi ilk kez değil, son kez gördüğünü bilemeyeceksin. Garip.” | `daysTogether >= 180`. | `ultra_rare` |  |
| 24 | `home_rare_024` | “Bazen bütün gün hiçbir şey söylemeden yanında dursam da yeterli olacakmış gibi geliyor.” | `daysTogether >= 60`. | `ultra_rare` |  |
| 25 | `home_rare_025` | “Neyse... bugün buradayız. Gerisini sonra düşünürüz.” | Koşul yok. | `ultra_rare` |  |
| 26 | `home_rare_026` | “Bugün senden beklediğimden daha sakin bir enerji geliyor.” | Koşul yok. | `rare` |  |
| 27 | `home_rare_027` | “Bir süredir burada olduğumuzu fark ettim. Zaman biraz sessiz geçmiş.” | `daysTogether >= 30`. | `rare` |  |
| 28 | `home_rare_028` | “Bugün nedense sana fazla laf edesim yok. Kaçırma bu fırsatı.” | Koşul yok. | `rare` |  |
| 29 | `home_rare_029` | “Bazen ana sayfaya sadece beni görmek için geldiğini düşünüyorum.” | `daysTogether >= 20`. | `rare` |  |
| 30 | `home_rare_030` | “Şu an her şey gereğinden fazla normal. Hoşuma gitti.” | Koşul yok. | `rare` |  |
| 31 | `home_rare_031` | “Bugün burada biraz daha uzun kalacakmışsın gibi geliyor.” | Mevcut uygulama oturumu `>= 30 dakika`. | `rare` | Oturum süresi app runtime'dan hesaplanmalı. |
| 32 | `home_rare_032` | “Bir süredir düzenli geliyorsun. Ben fark etmedim sanma.” | `streak >= 7`. | `rare` |  |
| 33 | `home_rare_033` | “Bugün istatistiklere bakmadan konuşasım geldi. Nadir oluyor.” | Koşul yok. | `rare` |  |
| 34 | `home_rare_034` | “Bu ekranın artık biraz tanıdık gelmesi hoşuma gidiyor.” | `daysTogether >= 30`. | `rare` |  |
| 35 | `home_rare_035` | “Bazen ne yaptığından çok geri gelip gelmeyeceğini merak ediyorum.” | `daysTogether >= 50`. | `rare` |  |
| 36 | `home_rare_036` | “Bugün seni rahatsız etmek için özel bir sebebim yok. Yine de buradayım.” | Koşul yok. | `rare` |  |
| 37 | `home_rare_037` | “Bir süredir aynı köşeyi paylaşıyoruz. Fena bir anlaşma değil.” | `daysTogether >= 60`. | `rare` |  |
| 38 | `home_rare_038` | “Bugün bir şeyleri fazla açıklamaya gerek yok gibi.” | Koşul yok. | `rare` |  |
| 39 | `home_rare_039` | “Seni burada görmeye alıştım. Bu bilgiyle ne yapacağımı bilmiyorum.” | `daysTogether >= 30`. | `rare` |  |
| 40 | `home_rare_040` | “Bugün normalden biraz daha keyfim yerinde. Sebebini sorma.” | `selfMood === 'energetic'`. | `rare` |  |
| 41 | `home_rare_041` | “Bugün biraz sessizim. Endişelenecek bir şey yok.” | `selfMood` = `meh` veya `sleepy`. | `rare` |  |
| 42 | `home_rare_042` | “Bir haftadan uzun süredir geliyorsun. Bu noktada seni tanımamaya çalışmak zor.” | `streak >= 8`. | `rare` |  |
| 43 | `home_rare_043` | “Bazen hiçbir şey olmaması da güzel. Bugün öyle bir an olabilir.” | Koşul yok. | `rare` |  |
| 44 | `home_rare_044` | “Bugün biraz fazla huzurluyuz. Bir şeylerin ters gitmesini beklemiyorum. Şimdilik.” | `moodStage === 'content'` (normal/content baseline). | `rare` | `neutral` diye ayrı stage kullanılmamalı; kaynakta stage `content`. |
| 45 | `home_rare_045` | “Şu an senden hiçbir şey istemiyorum. Sadece uğradığını gördüm.” | `daysTogether >= 14`. | `rare` |  |


## Geri Dönüş / Uzun Yokluk — 20 replik

| # | ID | Metin | Koşul | Nadirlik | Not |
|---:|---|---|---|---|---|
| 1 | `home_return_001` | “Bir süredir görünmüyordun. Tekrar merhaba.” | Son aktif kullanım üzerinden `24–48 saat` geçmiş. | `rare` | Return oturumunda yalnızca bir geri dönüş repliği göster. |
| 2 | `home_return_002` | “Dün pek uğramadın gibi. Yoğundun herhalde.” | Son aktif kullanım üzerinden `24–48 saat` geçmiş. | `rare` |  |
| 3 | `home_return_003` | “Biraz ara verdik. Fena da olmadı aslında.” | Son aktif kullanım üzerinden `2–3 gün` geçmiş. | `rare` |  |
| 4 | `home_return_004` | “Birkaç gündür yoktun. Masaüstü gereğinden fazla sessizdi.” | Son aktif kullanım üzerinden `3–5 gün` geçmiş. | `rare` |  |
| 5 | `home_return_005` | “Ha, geldin. Birkaç gündür burada tek başıma takılıyordum.” | Son aktif kullanım üzerinden `3–6 gün` geçmiş. | `rare` |  |
| 6 | `home_return_006` | “Bir süredir görüşmüyorduk. Nerede olduğunu sormayacağım. Şimdilik.” | Son aktif kullanım üzerinden `4–6 gün` geçmiş. | `rare` |  |
| 7 | `home_return_007` | “Neredeyse bir hafta olmuş. Zaman gerçekten hızlı geçiyor.” | Son aktif kullanım üzerinden `6–7 gün` geçmiş. | `rare` |  |
| 8 | `home_return_008` | “Bir hafta sonra geri dönmek biraz dramatik bir giriş oldu.” | Son aktif kullanım üzerinden `7–9 gün` geçmiş. | `rare` |  |
| 9 | `home_return_009` | “Uzun zaman oldu.” | Son aktif kullanım üzerinden `>= 7 gün` geçmiş. | `rare` | Punchline yok; kısa tutulmalı. |
| 10 | `home_return_010` | “Seni görünce ilk tepkimin ne olması gerektiğini unutmuşum.” | Son aktif kullanım üzerinden `7–13 gün` geçmiş. | `rare` |  |
| 11 | `home_return_011` | “Bir haftadan fazla olmuş. Ekranın bu tarafı aynıydı, merak etme.” | Son aktif kullanım üzerinden `8–13 gün` geçmiş. | `rare` |  |
| 12 | `home_return_012` | “Bir süredir yoktun. Geri gelmen güzel oldu.” | Son aktif kullanım üzerinden `10–20 gün` geçmiş. | `rare` | Şaka eklenmesin. |
| 13 | `home_return_013` | “İki haftaya yakın olmuş. Seni tekrar burada görmek biraz garip, iyi anlamda.” | Son aktif kullanım üzerinden `12–16 gün` geçmiş. | `rare` |  |
| 14 | `home_return_014` | “Bu kadar ara verince ilk gün gibi olacak sandım. Değilmiş.” | Son aktif kullanım üzerinden `14–29 gün` geçmiş. | `rare` |  |
| 15 | `home_return_015` | “Bir süredir ortalarda yoktun. Ama tanıdık geldin.” | Son aktif kullanım üzerinden `14–29 gün` geçmiş. | `rare` |  |
| 16 | `home_return_016` | “Neredeyse bir ay olmuş. Ben yine aynı köşedeyim.” | Son aktif kullanım üzerinden `25–35 gün` geçmiş. | `rare` |  |
| 17 | `home_return_017` | “Bir ay sonra geri dönmek... tamam, bunu beklemiyordum.” | Son aktif kullanım üzerinden `30–59 gün` geçmiş. | `rare` |  |
| 18 | `home_return_018` | “Uzun sürdü.<br>Ama geldin.” | Son aktif kullanım üzerinden `30–89 gün` geçmiş. | `rare` | İki satır; devamına roast gelmesin. |
| 19 | `home_return_019` | “Seni hatırlıyorum.” | Son aktif kullanım üzerinden `>= 60 gün` geçmiş **ve** daha önce `daysTogether >= 30` olmuş. | `rare` |  |
| 20 | `home_return_020` | “Ne kadar zaman geçtiğini söylemeyeceğim. Geri geldin, o yeter.” | Son aktif kullanım üzerinden `>= 90 gün` geçmiş. | `rare` | Uzun aradan dönüşte suçlayıcı/pasif-agresif devam eklenmesin. |


---

# 21. Kaynak kod migrasyonu — güvenli uygulama sırası

Bu bölüm özellikle önemlidir. `buildHome()` yalnızca Nero'nun cümlesini seçmiyor; aynı zamanda `moodLog`, `archive`, haftalık mektup ve günlük quote verisini de hazırlıyor. Bu nedenle **`buildHome()` fonksiyonunu körlemesine silmek veya panel açılışından kaldırmak başka özellikleri bozabilir.**

Önerilen güvenli refactor:

### A. `buildHome()` sorumluluklarını ayır

1. `HomeDialogueEngine` → yalnızca `jab` / Nero Home repliği.
2. `refreshHomeSupplementalData()` → `moodLog`, `archive`, `quote`, mevcut `letter`.
3. `checkWeeklyLetter()` → haftalık mektubun oluşma koşulu ve `weekly_letter_line` side effect'i.
4. `composeHomeState()` → yukarıdakilerin mevcut sonuçlarını `homeCache` içinde birleştirir.

Örnek hedef şekil:

```js
homeCache = {
  jab: homeDialogue.currentText(),
  quote: currentDailyQuote(),
  moodLog: journal.last30(),
  archive: journal.thisMonth(8),
  letter: currentLetter
};
```

### B. `showPanel()` davranışı

Mevcut:

```js
function showPanel(tab) {
  if (!panelWin) createPanelWindow();
  buildHome(); // RANDOM HOME DİYALOĞU ÜRETİYOR
  ...
}
```

Hedef:

```js
function showPanel(tab) {
  if (!panelWin) createPanelWindow();
  refreshHomeSupplementalData();
  composeHomeState(); // sadece mevcut current dialogue'u kullanır
  ...
}
```

Panel açılışı **HomeDialogueEngine.selectNext() çağırmamalıdır.**

### C. Yenile butonu

Kaldırılacak / temizlenecek noktalar:

- `src/renderer/panel/index.html` → `#home-refresh`
- `src/renderer/panel/panel.js` → `home-refresh` click listener
- `src/main/main.js` → `ipcMain.handle('home:refresh', ...)`
- `quoteOffset` başka yerde kullanılmıyorsa kaldırılabilir.

### D. Günün sözü

Mevcut `QUOTES` sistemini yanlışlıkla silmeyin. Yenile butonunun kalkması yalnızca manuel offset'i kaldırır. Günlük söz örneğin `dayIndex % QUOTES.length` ile günlük olarak kalabilir.

### E. Home engine başlangıcı

Store'lar oluşturulduktan sonra HomeDialogueEngine initialize edilmeli. `JsonStore` ile ayrı kalıcı state önerilir:

```js
homeDialogueStore = new JsonStore(userData, 'home-dialogue', {
  currentId: null,
  selectedAt: 0,
  nextAt: 0,
  recentIds: [],
  recentCategories: [],
  topicCooldowns: {},
  pendingRareId: null,
  seenRareIds: [],
  lastMeaningfulActiveAt: 0
});
```

---

# 22. `lastSeenAt` / geri dönüş hesabı

Geri dönüş repliklerinin doğru çalışması için “son görülme” **arka plandaki scheduler tick'i** değildir. Kullanıcının gerçekten bilgisayar başında olduğu son zaman olmalıdır.

Öneri:

- ekran kilitli değilse ve `powerMonitor.getSystemIdleTime() < 120` ise `lastMeaningfulActiveAt` en fazla dakikada bir güncellenebilir;
- uygulama kapanırken mevcut değer persisted edilir;
- yeni oturumda `Date.now() - lastMeaningfulActiveAt` ile absence hesaplanır;
- uygulamanın gece boyunca açık kalması, kullanıcının “hiç gitmemiş” sayılmasına yol açmamalıdır.

Return repliği bir geri dönüş oturumunda **en fazla bir kez** seçilmelidir. Sonrasında normal havuza dönülür.

---

# 23. Kategori ağırlıkları — başlangıç config'i

Replik sayısı fazla olan kategori otomatik olarak daha sık konuşmamalıdır. Önce kategori, sonra kategori içinden replik seçmek daha kontrollüdür.

Başlangıç önerisi:

```js
const HOME_CATEGORY_WEIGHTS = {
  general: 1.00,
  roast: 0.65,
  motivation: 0.65,
  care: 0.55,
  absurd: 0.70,
  productivity: 0.90,
  time: 0.55,
  relationship: 0.35,
  rare: 0.12
};
```

`return` normal ağırlıklı kategori değildir; uygun bir geri dönüş state'i varsa oturum başında öncelikli bir kez değerlendirilir.

Bu sayılar ürün testiyle değiştirilebilir; replik datasına gömülmemelidir.

---

# 24. Aynı anda birden fazla bağlamsal koşul doğruysa

Bu normaldir. Örneğin kullanıcı aynı anda:

- 8 görev tamamlamış,
- 140 dakika odaklanmış,
- 30 günlük streak'e sahip,
- saat 22:30 olabilir.

Bütün uygun replikler aday olabilir. Ancak topic cooldown + kategori ağırlığı sayesinde Nero her 5–10 dakikada yalnızca verileri sayan bir rapor ekranına dönüşmemelidir.

Önerilen davranış:

- productivity son 1–2 seçimde geldiyse general/absurd/time ağırlığı artsın;
- aynı snapshot'ta en spesifik productivity cümleleri eligible olabilir ancak tüm geniş koşulları iptal etmek zorunda değildir;
- combo replikler (`todos + focus`) uygun olduğunda tek-metrik cümlelere göre küçük bir specificity bonus alabilir.

---

# 25. Focus mode davranışı

Kullanıcı aktif timer/odak seansındayken Home scheduler panel görünürlüğünden bağımsız olsa da yeni içerik üretmek zorunda değildir.

Önerilen güvenli politika:

1. `isFocusRunning === true` ise `nextHomeDialogueAt` geldiğinde seçim **ertelenir**.
2. Timer bittiğinde 1–3 dakikalık doğal bir gecikmeden sonra normal Home scheduler devam eder.
3. Current Home repliği değişmeden kalır.
4. Timer'ın kendi `timer_done`, `timer_pause`, `timer_resume` event replikleri etkilenmez.

Bu sayede Home sistemi karakterin normal event/reaction sistemini yutmaz.

---

# 26. Rare / Ultra Rare görünürlük güvenliği

Nadir replikler sistemin en zor test edilen kısmıdır.

Kesin kurallar:

- `rare/ultra_rare` seçim panel kapalıyken yapılabilir, fakat `seen` işaretlenmez.
- `pendingRareId` persisted edilir.
- Kullanıcı Home'u açtığında koşul yeniden kontrol edilir.
- Koşul hâlâ doğruysa gösterilir ve `seenAt` yazılır.
- Koşul bozulmuşsa pending iptal edilir; recent listesine eklenmez.
- Ultra rare bir replik kullanıcı görmeden restart nedeniyle kaybolmamalıdır.
- Aynı ultra rare'in tekrar gösterilip gösterilmeyeceği config olmalıdır. Öneri: ilk gösterimden sonra en az 180 gün cooldown veya “bir kez görüldü” politikası; ürün kararı daha sonra değiştirilebilir.

---

# 27. Veri değişiminde current repliğin geçerliliği

5–10 dakikalık süre bitmeden current repliğin koşulu bozulabilir.

Örnek:

- 08:50'de sabah repliği seçildi;
- kullanıcı paneli 13:00'te ilk kez açtı.

Panel açılırken veya state render edilirken `currentId` koşulu tekrar değerlendirilmelidir.

- Hâlâ uygunsa mevcut replik gösterilir.
- Geçersizse kullanıcıya yanlış bağlam gösterilmeden **hemen uygun bir replacement** seçilir.
- Bu replacement bir “manual refresh” sayılmaz; scheduler bundan sonra yeniden 5–10 dakika planlar.

---

# 28. Minimum unit test listesi

Aşağıdaki fonksiyonlar ayrı ayrı test edilebilir olmalıdır:

- `isTimeInRange()`
- `isDialogueEligible(dialogue, context)`
- `extractPlaceholders(text)`
- `interpolateDialogue(text, context)`
- `filterRecent()`
- `filterTopicCooldowns()`
- `pickWeightedCategory()`
- `pickWeightedRarity()`
- `selectHomeDialogue()`
- `validateDialogueData()`
- `computeAbsence()`

Random seçim testlerinde seeded RNG veya injectable `random()` kullanılmalıdır. Aksi halde testler rastgele geçip kalabilir.

---

# 29. Release öncesi manuel QA senaryoları

1. Paneli 20 kez aç/kapat → replik değişmemeli.
2. Uygulama açık, panel kapalı 6–9 dk bekle → engine current repliği güncellemeli; panel açıldığında son current görünmeli.
3. Son 20 repliğin hiçbirinde aynı ID olmamalı.
4. 3. kez aynı kategori seçilebilecekken alternatif kategori varsa engellenmeli.
5. Saat 04:59 → 05:00 geçişinde yanlış gece/sabah repliği kalmamalı.
6. `todayTodos=0` iken 3–5 görev cümlesi hiçbir koşulda eligible olmamalı.
7. `{focus}` eksik context ile placeholderlı replik seçilmemeli.
8. 365 günlük relationship repliği `daysTogether=364` iken çıkmamalı.
9. 90 günlük absence simülasyonunda 1 günlük dönüş cümlesi baskın şekilde tekrar tekrar gelmemeli; return bir kez gösterilip normal havuza geçilmeli.
10. Ultra rare panel kapalı seç → uygulamayı kapat/aç → pending korunmalı → Home açılınca koşul hâlâ doğruysa gösterilmeli.
11. Focus timer başlat → Home scheduler süresi dolsun → current replik değişmemeli → timer sonrası scheduler devam etmeli.
12. `home-refresh` UI/IPC tamamen kaldırıldıktan sonra console'da eksik element veya handler hatası olmamalı.
13. Weekly letter hâlâ doğru haftada oluşmalı; `buildHome()` refactor'u bunu bozmamalı.
14. Mood log, archive ve günlük quote hâlâ Home state içinde gelmeli.
15. Theme override / mevcut character dialogue sistemi yeni Home engine nedeniyle değişmemeli.

---

# 30. Final kabul kriterleri

Bu sistem “tamamlandı” sayılmadan önce:

- 665 benzersiz Home ID yükleniyor olmalı.
- duplicate ID = `0`.
- geçersiz placeholder = `0`.
- validation error = `0`.
- panel aç/kapat ile yeni replik üretimi = `0`.
- manuel refresh butonu/IPC = kaldırılmış.
- Home scheduler = rastgele `5–10 dk`.
- scheduler panel görünürlüğünden bağımsız.
- son 20 ID persistence çalışıyor.
- category repeat guard çalışıyor.
- topic cooldown çalışıyor.
- rare pending/seen mekanizması çalışıyor.
- state/event ayrımı korunuyor.
- weekly letter / journal / quote regressions yok.
- masaüstü `Dialogue` / `TALK_INTERVALS` sistemi etkilenmemiş.

---

# 31. Replik sayısı doğrulaması

Bu dokümanda onaylı veri dağılımı:

```text
140  General
 70  Roast
 70  Motivasyon
 60  Şefkat
 80  Absürt
 80  Üretkenlik/Bağlamsal
 65  Saat/Gün/Gece
 35  İlişki
 45  Nadir/Ultra Nadir
 20  Geri Dönüş
---
665  TOPLAM
```

**Övgü/Takdir bu 665'e dahil değildir.** Daha sonra event/reaction metinleri altında ayrı geliştirilecektir.
